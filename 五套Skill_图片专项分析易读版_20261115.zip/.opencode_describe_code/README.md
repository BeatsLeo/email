# 图片整体问题解释补充

Skill：multimodal-issue-term-extractor-described-code。对代码变更截图执行本套具体的读图及整体分析要求；仅用这些类别的证据形成补充，后续提取仍读取全部原图。

部署本目录agents和skills到项目.opencode。主Agent依次完成原文/图片备份、统一分类、逐图证据读取、冻结、整体分析和业务提取。Python 3.9+，GIF需要Pillow。

只将必要的整体问题解释追加到新副本，不追加逐图报告；每单JSON，再批次Excel。各套逐图及整体Prompt不同，不跨套复用逐图记录或冻结目录，旧版记录也须重新准备。分类Prompt相同，来源一致时可按workflow仅沿用分类结果。原有业务配置工作台保持。
