# 代码变更重点提取

将本目录的agents和skills复制到项目.opencode下即可部署；本包可单独执行，不依赖其他同类包。

Skill名称：multimodal-issue-term-extractor-code。阅读规则：代码变更截图。所有原始图片及GIF帧始终可读；业务字段、因子依赖、复核及JSON/Excel流程按配置执行。

类型条件和阅读要求直接保存在各业务prompts/*.md的判断规则中，运行时不传阅读范围参数。分类脚本只追加本Skill范围内的图片索引与类别提示。使用同一个Qwen-VL subagent完成分类和原子提取任务，各次调用独立。

Python 3.9+；处理GIF时需要Pillow。可双击Skill内打开业务配置入口；页面已有终端软工、GTS和常规默认配置。
