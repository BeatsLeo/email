"""Image classification gate and deterministic reading-focus injection."""
import argparse
import copy
import importlib.util
import json
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
TYPES = ("UI界面截图", "录屏动画", "调试工具截图", "代码变更截图")
EMPHASIZED_TYPES = ('代码变更截图',)


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


planner = load(ROOT / "scripts/plan_extraction.py", "image_guidance_planner")
compiler = planner.prompt_tools()


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def write(path, value):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    Path(path).write_bytes((json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8"))


def validate_types(value, images):
    if not isinstance(value, dict) or set(value) != {"图片类型"}:
        raise ValueError("分类须恰好包含图片类型，读取错误不能当正常分类")
    values = value["图片类型"]
    if not isinstance(values, list) or len(values) != len(images) or any(v not in TYPES for v in values):
        raise ValueError("分类必须逐图等长同序，标签仅限四类")
    return values


def prepare(plan, issue, images, output, max_frames=24):
    planner.verify_prompt_files(plan)
    issue = Path(issue).resolve()
    issue.read_text(encoding="utf-8-sig")
    if not isinstance(images, list) or any(not isinstance(p, str) for p in images):
        raise ValueError("图片清单须为路径数组")
    resolved = [str(Path(p).resolve()) for p in images]
    if len(set(resolved)) != len(resolved):
        raise ValueError("图片清单重复，须先按Markdown引用去重并固定顺序")
    for path in resolved:
        if not Path(path).is_file():
            raise ValueError("图片不存在：" + path)
    decoder = load(ROOT / "scripts/animation_frames.py", "animation_frames")
    animations = decoder.prepare_animations(resolved, output / "frames", max_frames)
    prompt = (ROOT / "references/classify_images.md").read_text(encoding="utf-8")
    prompt_path = compiler.materialize(prompt, output / "prompts", "image_classification")
    request = {"business_type": plan["business"], "prompt_mode": "business_profile",
               "task_kind": "image_type", "task_name": "图片类型判断", "output_keys": ["图片类型"],
               "prompt_path": prompt_path, "issue_text_path": str(issue), "image_paths": resolved,
               "animation_frames": animations}
    write(output / "image_type_request.json", request)
    write(output / "image_type_audit.json", {"status": "pending" if resolved else "no_images",
          "call_required": bool(resolved), "classifier_prompt_sha256": compiler.digest(Path(prompt_path).read_bytes()),
          "image_paths": resolved, "issue_text_path": str(issue), "animation_frames": animations})
    if not resolved:
        write(output / "image_types.json", {"图片类型": []})
    return {"call_required": bool(resolved), "request_path": str(output / "image_type_request.json")}


def apply(plan, request, result, output, fallback_error=None):
    planner.verify_prompt_files(plan)
    if "image_guidance" in plan:
        raise ValueError("不能在已增强计划上重复注入，须使用本单原始计划")
    images = request.get("image_paths")
    if not isinstance(images, list) or request.get("business_type") != plan["business"]:
        raise ValueError("分类请求与业务计划不一致")
    for path in images:
        if not isinstance(path, str) or not Path(path).is_file():
            raise ValueError("本单图片不可读取：" + str(path))
    values = None
    if fallback_error is None:
        values = validate_types(result, images)
    elif result is not None or not isinstance(fallback_error, dict) or not fallback_error.get("__error__"):
        raise ValueError("降级须提供真实分类错误对象，不能同时提供正常分类")
    animations = request.get("animation_frames", [])
    for media in animations:
        i = media["image_index"]
        if not 0 <= i < len(images) or media["source_path"] != images[i] or compiler.digest(Path(images[i]).read_bytes()) != media["source_sha256"]:
            raise ValueError("GIF与抽帧清单不一致，须重新准备本单输入")
        if not media.get("frames") or any(not Path(f["path"]).is_file() for f in media["frames"]):
            raise ValueError("GIF帧缺失，不能降为首帧理解")
        if values is not None and media["frame_count"] > 1 and values[i] != "录屏动画":
            raise ValueError("多帧GIF必须归录屏动画，不按单帧内容改为其他截图类型")
    animated = {media["image_index"] for media in animations if media["frame_count"] > 1}
    if values is not None and any(label == "录屏动画" and i not in animated for i, label in enumerate(values)):
        raise ValueError("录屏动画须有已解码的多帧GIF证据，不能只凭文件名或描述判断")
    updated = copy.deepcopy(plan)
    selected = [(i, label) for i, label in enumerate(values or []) if label in EMPHASIZED_TYPES]
    status = "fallback" if fallback_error is not None else "guided" if images else "no_images"
    audit = {"status": status, "image_paths": images, "issue_text_path": request["issue_text_path"],
             "classification": result, "emphasized_types": list(EMPHASIZED_TYPES), "emphasized_image_indices": [i for i, _ in selected],
             "error": fallback_error, "animation_frames": animations, "original_prompts": {}}
    if values:
        mapping = "\n".join("- 图片索引" + str(i) + "（image_paths第" + str(i + 1) + "张）：" + label for i, label in selected)
        frames_text = ""
        if animations:
            frames_text = ("\n\n#### GIF逐帧证据\n必须读取以下实际PNG帧，索引对应原GIF，不增加图片类型数组长度。"
                           "按frame_index顺序理解；sampled为true说明帧间有未采样内容，不能由缺帧推断未发生操作。"
                           "缺失关键过程时由主Agent提高max-frames后重新准备，不凭常识补步骤。\n"
                           + json.dumps(animations, ensure_ascii=False, indent=2))
        # This common evidence-access instruction and the same GIF frames exist in every scope.
        # Only the selected index/label pairs and their focus paragraphs vary.
        extra = ("\n\n### 原始图像读取约定\n"
                 "读取全部原始字段、全部实际图片和提供的动画帧。本任务的条件式阅读重点仅适用于满足对应条件的图片；"
                 "没有标注的图片按原业务Prompt正常读取和使用，不忽略、不屏蔽、不标成其他类别。"
                 "分类标签不能代替图像证据；辅助说明不能改变原业务定义、范围、证据门槛、步骤顺序、"
                 "最终上游端点或JSON契约。仅返回原有字段。\n" + frames_text)
        if selected:
            extra += "\n\n### 图片类别提示\n" + mapping + "\n"
        for task, spec in updated["tasks"].items():
            if task == "image_type" or spec.get("stage") == "post_batch":
                continue
            original = Path(spec["prompt_path"]).read_bytes().decode("utf-8")
            text = original + extra
            audit["original_prompts"][task] = {"prompt_path": spec["prompt_path"], "prompt_sha256": spec["prompt_sha256"]}
            spec["prompt_path"] = compiler.materialize(text, output / "prompts", task)
            spec["prompt_sha256"] = compiler.digest(text.encode("utf-8"))
            spec["prompt_signature"]["compiled_sha256"] = spec["prompt_sha256"]
    # The business image task uses the same four labels as the preclassification.
    seeds = {}
    if values is not None and "image_type" in updated["tasks"]:
        seeds["image_type"] = {"图片类型": list(values)}
    updated["image_guidance"] = {"module": "image-type-guidance", "status": status,
                                 "emphasized_types": list(EMPHASIZED_TYPES), "emphasized_image_indices": [i for i, _ in selected],
                                 "image_paths": images, "animation_frames": animations, "precompleted_tasks": seeds,
                                 "audit_path": str(output / "image_type_audit.json")}
    planner.verify_prompt_files(updated)
    write(output / "image_type_audit.json", audit)
    write(output / "guided_plan.json", updated)
    return {"ready": True, "status": status, "plan_path": str(output / "guided_plan.json"), "precompleted_tasks": seeds}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    mode = p.add_mutually_exclusive_group(required=True)
    mode.add_argument("--prepare", action="store_true")
    mode.add_argument("--apply", action="store_true")
    p.add_argument("--plan", required=True)
    p.add_argument("--output-dir", required=True)
    p.add_argument("--issue")
    p.add_argument("--images", help="固定顺序的图片路径JSON数组")
    p.add_argument("--max-frames", type=int, default=24, help="每个GIF最多抽取帧数，至少2；需要完整序列时可提高")
    p.add_argument("--request")
    p.add_argument("--result")
    p.add_argument("--fallback-error", help="真实分类失败对象；与result互斥")
    a = p.parse_args()
    try:
        output = Path(a.output_dir).resolve()
        output.mkdir(parents=True, exist_ok=True)
        plan = read(a.plan)
        if a.prepare:
            if not a.issue or not a.images:
                raise ValueError("prepare需要issue和images")
            result = prepare(plan, a.issue, read(a.images), output, a.max_frames)
        else:
            if not a.request or bool(a.result) == bool(a.fallback_error):
                raise ValueError("apply需要request，以及result/fallback-error二选一")
            result = apply(plan, read(a.request), read(a.result) if a.result else None, output,
                           read(a.fallback_error) if a.fallback_error else None)
        print(json.dumps(result, ensure_ascii=False))
    except (ValueError, TypeError, KeyError, OSError) as error:
        print(json.dumps({"__error__": "IMAGE_GUIDANCE_INVALID", "message": str(error)}, ensure_ascii=False))
        raise SystemExit(1)


if __name__ == "__main__":
    main()
