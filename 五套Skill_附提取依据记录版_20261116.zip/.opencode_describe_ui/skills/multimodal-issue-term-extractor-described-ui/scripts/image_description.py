"""Snapshot inputs, request image descriptions, freeze evidence and build an enriched copy."""
import argparse, copy, hashlib, importlib.util, json, shutil
from pathlib import Path

ROOT=Path(__file__).resolve().parent.parent
TYPES=('UI界面截图','录屏动画','调试工具截图','代码变更截图')
INCLUDED_TYPES=('UI界面截图',)  # Bound once in each independently deployed Skill.

def load(path,name):
    s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
planner=load(ROOT/'scripts/plan_extraction.py','description_planner')
compiler=planner.prompt_tools()
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def write(p,value):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    p.write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))
def fresh(path):
    path=Path(path).resolve()
    if path.exists():raise ValueError('目标已存在，不覆盖运行或原始材料：'+str(path))
    path.mkdir(parents=True);return path
def fingerprints(plan):
    planner.verify_prompt_files(plan)
    return {'business':plan['business'],'output_fields':plan['output_fields'],
            'tasks':{k:{'sha256':v['prompt_sha256'],'dependencies':v['dependencies'],
                        'output_keys':v['output_keys'],'allowed_relations':v.get('allowed_relations')} for k,v in plan['tasks'].items()},
            'review':plan['recheck']['prompt_sha256']}
def check_snapshot(folder):
    folder=Path(folder).resolve();m=read(folder/'source.json')
    if m.get('format_version')!='4.0':raise ValueError('需要当前逐图证据与整体分析版本；旧的逐图分析报告不能复用')
    for f in [m['markdown'],*m['images']]:
        if digest(f['snapshot_path'])!=f['sha256']:raise ValueError('备份材料校验失败')
        original=Path(f['source_path'])
        if original.exists() and digest(original)!=f['sha256']:raise ValueError('原始材料已变化，请使用新运行目录重新准备')
    for k in ['classify','describe','synthesize']:
        if digest(m['prompts'][k]['path'])!=m['prompts'][k]['sha256']:raise ValueError('准备阶段Prompt发生变化')
    for media in m['animation_frames']:
        for f in media['frames']:
            if digest(f['path'])!=f['sha256']:raise ValueError('动画帧校验失败')
    return m

def prepare(plan,issue,images,output,max_frames=24):
    fp=fingerprints(plan);issue=Path(issue).resolve();body=issue.read_bytes();body.decode('utf-8-sig')
    if not isinstance(images,list) or any(not isinstance(x,str) for x in images):raise ValueError('图片清单须为有序路径数组')
    paths=[Path(x).resolve() for x in images]
    if len(set(paths))!=len(paths) or any(not p.is_file() for p in paths):raise ValueError('图片缺失或重复')
    output=Path(output).resolve()
    if output==issue.parent or issue.parent in output.parents:raise ValueError('准备目录须位于原始问题单文件夹之外')
    for p in paths:
        if p==issue:raise ValueError('Markdown不能作为图片')
    output=fresh(output);snapshot=output/'source_snapshot';snapshot.mkdir()
    raw=snapshot/issue.name;raw.write_bytes(body)
    records=[]
    for i,p in enumerate(paths):
        # Preserve ordinary Markdown-relative image paths, including nested images/.
        rel=p.relative_to(issue.parent) if issue.parent in p.parents else Path('__external_images')/(str(i)+p.suffix)
        target=snapshot/rel
        if target.exists():raise ValueError('图片备份路径冲突')
        target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
        records.append({'image_index':i,'source_path':str(p),'snapshot_path':str(target),'relative_path':rel.as_posix(),'sha256':digest(target)})
    animations=load(ROOT/'scripts/animation_frames.py','description_frames').prepare_animations([x['snapshot_path'] for x in records],output/'frames',max_frames)
    for media in animations:
        for f in media['frames']:f['sha256']=digest(f['path'])
    prompts={}
    for key,file in [('classify','classify_images.md'),('describe','describe_image.md'),('synthesize','synthesize_images.md')]:
        text=(ROOT/'references'/file).read_text(encoding='utf-8')
        path=compiler.materialize(text,output/'prompts',key)
        prompts[key]={'path':path,'sha256':digest(path)}
    m={'format_version':'4.0','markdown':{'source_path':str(issue),'snapshot_path':str(raw),'sha256':digest(raw)},'images':records,'animation_frames':animations,'prompts':prompts,'extraction_fingerprints':fp}
    write(output/'source.json',m)
    request={'business_type':plan['business'],'prompt_mode':'business_profile','task_kind':'image_type','task_name':'图片类型判断','output_keys':['图片类型'],'prompt_path':prompts['classify']['path'],'issue_text_path':str(raw),'image_paths':[x['snapshot_path'] for x in records],'animation_frames':animations}
    write(output/'classification_request.json',request)
    if not records:write(output/'image_types.json',{'图片类型':[]})
    return {'prepared_dir':str(output),'call_required':bool(records),'request_path':str(output/'classification_request.json')}

def check_types(value,m):
    if not isinstance(value,dict) or set(value)!={'图片类型'}:raise ValueError('分类结果不是成功的四类结构')
    values=value['图片类型']
    if not isinstance(values,list) or len(values)!=len(m['images']) or any(x not in TYPES for x in values):raise ValueError('分类数量、顺序或类别不合法')
    animated={x['image_index'] for x in m['animation_frames'] if x['frame_count']>1}
    if any((label=='录屏动画')!=(i in animated) for i,label in enumerate(values)):raise ValueError('动画分类与真实GIF解码不符')
    return values

def describe(folder,types_path):
    folder=Path(folder).resolve();m=check_snapshot(folder)
    if (folder/'frozen.json').exists():raise ValueError('已冻结，不能重写请求')
    labels=check_types(read(types_path),m);requests=[]
    for i,image in enumerate(m['images']):
        frames=[copy.deepcopy(x) for x in m['animation_frames'] if x['image_index']==i]
        # The description call reads a single image; local index is 0, returned index stays global.
        for media in frames:media['image_index']=0
        req={'business_type':m['extraction_fingerprints']['business'],'prompt_mode':'business_profile','task_kind':'image_description','task_name':'逐图读取证据','output_keys':['图片索引','图片类型','关键事实','定位信息','时序记录','信息不足'],'prompt_path':m['prompts']['describe']['path'],'issue_text_path':m['markdown']['snapshot_path'],'original_image_index':i,'image_type':labels[i],'image_paths':[image['snapshot_path']],'animation_frames':frames,'result_path':str(folder/'descriptions'/(str(i)+'.json'))}
        path=folder/'description_requests'/(str(i)+'.json')
        if path.exists():raise ValueError('请求已生成，直接复用；补帧须创建新准备目录')
        write(path,req);requests.append(str(path))
    write(folder/'confirmed_types.json',{'图片类型':labels})
    return {'request_paths':requests,'descriptions_dir':str(folder/'descriptions')}

def validate_caption(value,i,label,m):
    keys={'图片索引','图片类型','关键事实','定位信息','时序记录','信息不足'}
    if not isinstance(value,dict) or set(value)!=keys:raise ValueError('图片说明缺字段或为错误返回：'+str(i))
    if type(value['图片索引']) is not int or value['图片索引']!=i or value['图片类型']!=label:raise ValueError('图片说明索引或类型不符')
    def nonempty(s):return isinstance(s,str) and bool(s.strip())
    for key in ['关键事实','定位信息','信息不足']:
        if not isinstance(value[key],list) or any(not nonempty(x) for x in value[key]):raise ValueError('图片说明列表不合法')
    timeline=value['时序记录'];media=next((x for x in m['animation_frames'] if x['image_index']==i),None)
    if not isinstance(timeline,list):raise ValueError('时序记录不是数组')
    if label!='录屏动画':
        if timeline:raise ValueError('静态截图不能制造帧序')
    else:
        valid={f['frame_index'] for f in media['frames']};indices=[]
        for item in timeline:
            if not isinstance(item,dict) or set(item)!={'帧索引','说明'} or type(item['帧索引']) is not int or item['帧索引'] not in valid or not nonempty(item['说明']):raise ValueError('动画时序未绑定可见帧')
            indices.append(item['帧索引'])
        if indices!=sorted(set(indices)) or not indices or indices[0]!=min(valid) or indices[-1]!=max(valid):raise ValueError('动画时序须按顺序覆盖首尾帧')
    return value

def freeze(folder):
    folder=Path(folder).resolve();m=check_snapshot(folder)
    if (folder/'frozen.json').exists():raise ValueError('已冻结，直接复用该目录')
    labels=check_types(read(folder/'confirmed_types.json'),m);captions=[];hashes={}
    for i,label in enumerate(labels):
        path=folder/'descriptions'/(str(i)+'.json');captions.append(validate_caption(read(path),i,label,m));hashes[str(i)]=digest(path)
    frozen={'source_sha256':digest(folder/'source.json'),'types_sha256':digest(folder/'confirmed_types.json'),'description_sha256':hashes,'captions':captions}
    write(folder/'frozen.json',frozen)
    return {'ready':True,'prepared_dir':str(folder),'images':len(labels),'frozen_sha256':digest(folder/'frozen.json')}

def checked_evidence(plan,folder,expected_issue,expected_images):
    folder=Path(folder).resolve();m=check_snapshot(folder);frozen=read(folder/'frozen.json')
    if str(Path(expected_issue).resolve())!=m['markdown']['source_path'] or digest(expected_issue)!=m['markdown']['sha256']:
        raise ValueError('冻结准备目录不属于本次原始问题单')
    if not isinstance(expected_images,list) or [str(Path(p).resolve()) for p in expected_images]!=[x['source_path'] for x in m['images']]:
        raise ValueError('本次图片清单或顺序与冻结材料不一致')
    if fingerprints(plan)!=m['extraction_fingerprints']:raise ValueError('复用的业务或提取Prompt与本次不一致')
    for k,file in [('classify','classify_images.md'),('describe','describe_image.md'),('synthesize','synthesize_images.md')]:
        if digest(ROOT/'references'/file)!=m['prompts'][k]['sha256']:raise ValueError('复用材料的分类/转写Prompt版本不同')
    if digest(folder/'source.json')!=frozen['source_sha256'] or digest(folder/'confirmed_types.json')!=frozen['types_sha256']:raise ValueError('冻结来源或分类被修改')
    labels=check_types(read(folder/'confirmed_types.json'),m)
    for i,label in enumerate(labels):
        path=folder/'descriptions'/(str(i)+'.json')
        if digest(path)!=frozen['description_sha256'][str(i)] or validate_caption(read(path),i,label,m)!=frozen['captions'][i]:raise ValueError('冻结说明被修改')
    return m,frozen

def outside_output(output,folder,m):
    output=Path(output).resolve();folder=Path(folder).resolve()
    if output==folder or folder in output.parents:raise ValueError('补充副本不能写入冻结准备目录')
    source_parent=Path(m['markdown']['source_path']).parent
    if output==source_parent or source_parent in output.parents:raise ValueError('补充副本须在原始问题单文件夹之外')
    return fresh(output)

def synthesis_media(m,selected):
    indices=[c['图片索引'] for c in selected]
    paths=[m['images'][i]['snapshot_path'] for i in indices]
    frames=[]
    for local,original in enumerate(indices):
        for media in m['animation_frames']:
            if media['image_index']==original:
                item=copy.deepcopy(media);item['image_index']=local;item['original_image_index']=original;frames.append(item)
    return {'image_paths':paths,'original_image_indices':indices,'animation_frames':frames}

def synthesize(plan,folder,output,expected_issue,expected_images):
    folder=Path(folder).resolve();m,frozen=checked_evidence(plan,folder,expected_issue,expected_images)
    output=outside_output(output,folder,m)
    selected=[copy.deepcopy(c) for c in frozen['captions'] if c['图片类型'] in INCLUDED_TYPES]
    evidence=output/'selected_evidence.json';write(evidence,selected)
    request={'business_type':plan['business'],'prompt_mode':'business_profile','task_kind':'image_synthesis','task_name':'整体图片问题解释','output_keys':['问题主线','图片联系','根因判断','补充文本'],'prompt_path':m['prompts']['synthesize']['path'],'issue_text_path':m['markdown']['snapshot_path'],'evidence_path':str(evidence),**synthesis_media(m,selected),'result_path':str(output/'synthesis_result.json')}
    path=output/'synthesis_request.json';write(path,request)
    write(output/'synthesis_binding.json',{'frozen_sha256':digest(folder/'frozen.json'),'request_sha256':digest(path),'evidence_sha256':digest(evidence),'selected_image_indices':[c['图片索引'] for c in selected],'included_types':list(INCLUDED_TYPES)})
    if not selected:
        write(request['result_path'],{'问题主线':'当前范围没有可补充图片。','图片联系':[],'根因判断':{'状态':'尚不能确定','说明':'没有所选类别证据。','图片索引':[]},'补充文本':''})
    return {'call_required':bool(selected),'request_path':str(path),'result_path':request['result_path']}

def validate_synthesis(value,allowed):
    if not isinstance(value,dict) or set(value)!={'问题主线','图片联系','根因判断','补充文本'}:raise ValueError('整体分析字段不合法或为失败返回')
    if not isinstance(value['问题主线'],str) or not value['问题主线'].strip() or not isinstance(value['补充文本'],str):raise ValueError('问题主线/补充文本类型不符')
    def indices(xs,nonempty=False):
        if not isinstance(xs,list) or (nonempty and not xs) or any(type(x) is not int or x not in allowed for x in xs) or len(set(xs))!=len(xs):raise ValueError('整体分析引用了未选图片或重复索引')
    links=value['图片联系']
    if not isinstance(links,list):raise ValueError('图片联系不是数组')
    refs=[]
    for link in links:
        if not isinstance(link,dict) or set(link)!={'图片索引','说明'} or not isinstance(link['说明'],str) or not link['说明'].strip():raise ValueError('图片联系结构不符')
        indices(link['图片索引'],True);refs+=link['图片索引']
    cause=value['根因判断']
    if not isinstance(cause,dict) or set(cause)!={'状态','说明','图片索引'} or cause['状态'] not in ('有直接依据','尚不能确定') or not isinstance(cause['说明'],str) or not cause['说明'].strip():raise ValueError('根因判断结构不符')
    indices(cause['图片索引'],cause['状态']=='有直接依据');refs+=cause['图片索引']
    if value['补充文本'].strip() and not refs:raise ValueError('非空补充文本必须有图片依据')
    if not allowed and value['补充文本'].strip():raise ValueError('没有目标类别不能生成补充')
    return value

def assemble(plan,folder,output,expected_issue,expected_images,synthesis_request,synthesis_result):
    folder=Path(folder).resolve();m,frozen=checked_evidence(plan,folder,expected_issue,expected_images)
    labels=check_types(read(folder/'confirmed_types.json'),m)
    selected=[copy.deepcopy(c) for c in frozen['captions'] if c['图片类型'] in INCLUDED_TYPES]
    path=Path(synthesis_request).resolve();request=read(path);binding=read(path.parent/'synthesis_binding.json')
    allowed=[c['图片索引'] for c in selected]
    if binding!={'frozen_sha256':digest(folder/'frozen.json'),'request_sha256':digest(path),'evidence_sha256':digest(request['evidence_path']),'selected_image_indices':allowed,'included_types':list(INCLUDED_TYPES)}:raise ValueError('整体分析请求与当前冻结证据/范围不一致')
    if read(request['evidence_path'])!=selected or request['task_kind']!='image_synthesis' or request['issue_text_path']!=m['markdown']['snapshot_path'] or request['prompt_path']!=m['prompts']['synthesize']['path'] or any(request.get(k)!=v for k,v in synthesis_media(m,selected).items()):raise ValueError('整体分析使用了其他材料')
    if Path(synthesis_result).resolve()!=Path(request['result_path']).resolve():raise ValueError('整体分析返回须保存到本请求指定路径，不能混用其他请求返回')
    explanation=validate_synthesis(read(synthesis_result),allowed);supplement=explanation['补充文本'].strip()
    output=outside_output(output,folder,m);copied=output/'issue';shutil.copytree(folder/'source_snapshot',copied)
    issue=copied/Path(m['markdown']['snapshot_path']).name
    images=[str(copied/x['relative_path']) for x in m['images']]
    appendix=('\n\n---\n\n## 图片整体含义补充（辅助解释，非原始正文）\n\n'+supplement+'\n') if supplement else ''
    raw=Path(m['markdown']['snapshot_path']).read_bytes();issue.write_bytes(raw+appendix.encode('utf-8'))
    frames=copy.deepcopy(m['animation_frames'])
    for media in frames:media['source_path']=images[media['image_index']]
    seeds={'image_type':{'图片类型':labels}} if 'image_type' in plan['tasks'] else {}
    write(output/'synthesis_audit.json',explanation)
    descriptor={'included_types':list(INCLUDED_TYPES),'selected_image_indices':allowed,'selected_count':len(selected),'coverage_status':('augmented' if supplement else 'no_increment') if selected else 'no_matching_images','supplement_characters':len(supplement),'synthesis_result_sha256':digest(synthesis_result),'synthesis_request_sha256':digest(path),'synthesis_audit_path':str(output/'synthesis_audit.json'),'prepared_dir':str(folder),'synthesis_mode':'joint_selected_images_root_cause','frozen_sha256':digest(folder/'frozen.json'),'issue_text_path':str(issue),'original_issue_sha256':m['markdown']['sha256'],'enriched_issue_sha256':digest(issue),'image_paths':images,'animation_frames':frames,'precompleted_tasks':seeds}
    updated=copy.deepcopy(plan)
    # Common access/provenance instructions only; no type-specific extraction rules or extra labels.
    extra=('\n\n### 图片整体含义补充读取\n完整读取本次issue_text_path；末尾可能含所选图片共同反映的问题解释。'
           '这是帮助理解图片联系的辅助文字，不是新增需求、原始规范或标注答案；仍读取image_paths全部原图。'
           '按原业务定义判断要素，不因补充文字而把新名词全部加入，不据此虚构流程、正确标准或未证实原因。'
           '从不同图片得到的事实必须核对同一对象、操作和时序后才能建立联系；不因相邻说明就推断先后或因果。'
           '相对图片引用按提供的image_paths及原始索引定位，外部引用的备份映射已在输入上下文中给出。'
           'GIF必须读取animation_frames中的实际帧，采样缺口不证明未发生事件；关键过程缺失先补帧。'
           '业务定义、上游依赖、关系端点和输出格式保持当前任务要求。\n')
    for task,spec in updated['tasks'].items():
        if task=='image_type' or spec.get('stage')=='post_batch':continue
        text=Path(spec['prompt_path']).read_text(encoding='utf-8')+extra+load(ROOT/'scripts/extraction_audit.py','extraction_evidence_contract').contract(spec['output_keys'])
        spec['prompt_path']=compiler.materialize(text,output/'prompts',task)
        spec['prompt_sha256']=digest(spec['prompt_path']);spec['prompt_signature']['compiled_sha256']=spec['prompt_sha256']
    updated['extraction_audit']={'version':'1.0','tasks':[task for task,spec in updated['tasks'].items() if task!='image_type' and spec.get('stage')!='post_batch']}
    updated['image_description']=descriptor;planner.verify_prompt_files(updated)
    write(output/'enriched_plan.json',updated);write(output/'enrichment_manifest.json',descriptor)
    write(output/'image_paths.json',images)
    return {'ready':True,'plan_path':str(output/'enriched_plan.json'),**descriptor}

def main():
    parser=argparse.ArgumentParser(description=__doc__);modes=parser.add_mutually_exclusive_group(required=True)
    for mode in ['prepare','describe','freeze','synthesize','assemble']:modes.add_argument('--'+mode,action='store_true')
    for arg in ['plan','issue','images','output-dir','prepared','types','synthesis-request','synthesis-result']:parser.add_argument('--'+arg)
    parser.add_argument('--max-frames',type=int,default=24);a=parser.parse_args()
    try:
        if a.prepare:
            if not all([a.plan,a.issue,a.images,a.output_dir]):raise ValueError('prepare需要plan/issue/images/output-dir')
            result=prepare(read(a.plan),a.issue,read(a.images),a.output_dir,a.max_frames)
        elif a.describe:
            if not a.prepared or not a.types:raise ValueError('describe需要prepared/types')
            result=describe(a.prepared,a.types)
        elif a.freeze:
            if not a.prepared:raise ValueError('freeze需要prepared')
            result=freeze(a.prepared)
        elif a.synthesize:
            if not all([a.plan,a.prepared,a.output_dir,a.issue,a.images]):raise ValueError('synthesize需要plan/prepared/output-dir/issue/images')
            result=synthesize(read(a.plan),a.prepared,a.output_dir,a.issue,read(a.images))
        else:
            if not all([a.plan,a.prepared,a.output_dir,a.issue,a.images]):raise ValueError('assemble需要plan/prepared/output-dir/issue/images')
            if not a.synthesis_request or not a.synthesis_result:raise ValueError('assemble需要整体分析的真实请求与返回，不能直接拼接逐图记录')
            result=assemble(read(a.plan),a.prepared,a.output_dir,a.issue,read(a.images),a.synthesis_request,a.synthesis_result)
        print(json.dumps(result,ensure_ascii=False))
    except (OSError,ValueError,TypeError,KeyError,UnicodeError) as error:
        print(json.dumps({'__error__':'IMAGE_DESCRIPTION_INVALID','message':str(error)},ensure_ascii=False));raise SystemExit(1)
if __name__=='__main__':main()
