# GTS 4.2.8 同步修改

下列差异以本次同步前的当前All目录为基准。所有GTS提取Prompt原文均未修改；仅同步工厂模板、版本和校验值。

| 文件 | 内容 |
|---|---|
| `README.md` | 仅同步版本号 |
| `skills/multimodal-issue-term-extractor-described-all/SKILL.md` | 仅同步GTS版本号 |
| `skills/multimodal-issue-term-extractor-described-all/businesses/gts/business.json` | 更新版本说明与实际对象Prompt哈希 |
| `skills/multimodal-issue-term-extractor-described-all/configurator/templates/multimodal-gts.json` | 同步HTML内置业务配置 |
| `skills/multimodal-issue-term-extractor-described-all/configurator/templates/multimodal-gts/prompts/object.md` | 逐字同步用户当前对象Prompt到HTML默认模板 |

````diff
diff --git a/.opencode/README.md b/.opencode/README.md
--- a/.opencode/README.md
+++ b/.opencode/README.md
@@ -14,4 +14,4 @@
 
 ## 当前GTS发布版本
 
-GTS 4.2.5以businesses/gts/prompts中的当前业务文件为准，保留用户选定的对象提取规则及已修改的动作/数据因子、预期等Prompt。HTML内置GTS模板、版本与SHA-256已同步；其他业务和模型配置保持原样。部署本目录的agents与skills到项目.opencode，启动新的运行目录生成本次完整Prompt及执行计划。已有自定义业务或旧Prompt快照不会自动更新；内置GTS从本次目录读取。
+GTS 4.2.8以businesses/gts/prompts中的当前业务文件为准，保留用户选定的对象提取规则及已修改的动作/数据因子、预期等Prompt。HTML内置GTS模板、版本与SHA-256已同步；其他业务和模型配置保持原样。部署本目录的agents与skills到项目.opencode，启动新的运行目录生成本次完整Prompt及执行计划。已有自定义业务或旧Prompt快照不会自动更新；内置GTS从本次目录读取。
diff --git a/.opencode/skills/multimodal-issue-term-extractor-described-all/SKILL.md b/.opencode/skills/multimodal-issue-term-extractor-described-all/SKILL.md
--- a/.opencode/skills/multimodal-issue-term-extractor-described-all/SKILL.md
+++ b/.opencode/skills/multimodal-issue-term-extractor-described-all/SKILL.md
@@ -308,4 +308,4 @@
 
 ## GTS先验维护
 
-GTS 4.2.5优先原有业务目标与流程。有限先验只补缺失的工具结果到答案衔接职责、明确授权的白盒/内部资源生命周期检查、验收不可缺少的调试观测前提；不能以代码或F12可见触发新增项。其他业务不应用。因子修正后重新生成预期和关系，依据记录引用实际授权事实。工厂模板与业务包同步维护。
+GTS 4.2.8优先原有业务目标与流程。有限先验只补缺失的工具结果到答案衔接职责、明确授权的白盒/内部资源生命周期检查、验收不可缺少的调试观测前提；不能以代码或F12可见触发新增项。其他业务不应用。因子修正后重新生成预期和关系，依据记录引用实际授权事实。工厂模板与业务包同步维护。
diff --git a/.opencode/skills/multimodal-issue-term-extractor-described-all/businesses/gts/business.json b/.opencode/skills/multimodal-issue-term-extractor-described-all/businesses/gts/business.json
--- a/.opencode/skills/multimodal-issue-term-extractor-described-all/businesses/gts/business.json
+++ b/.opencode/skills/multimodal-issue-term-extractor-described-all/businesses/gts/business.json
@@ -1,8 +1,8 @@
 {
   "format_version": "3.0",
   "name": "GTS",
-  "version": "4.2.5",
-  "description": "保留当前GTS对象规则及用户确认的因子、预期等Prompt；同步HTML内置模板和内容校验，按验证目标组织预期。",
+  "version": "4.2.8",
+  "description": "保留用户当前确认的GTS对象、因子及预期等提取规则；同步HTML内置模板、版本与实际内容校验。",
   "template": "gts",
   "object_tree_path": null,
   "selection": {
@@ -24,7 +24,7 @@
         "测试对象"
       ],
       "dependencies": [],
-      "sha256": "ce37d9f8e33a648160807213c654f4f5a91c961e22c744fcc22f3a83e9ce2ec1",
+      "sha256": "753de2d9706f1bc9d6ac6700895d57f3cae44951ffb86c1fbbdb3c9d8f978322",
       "template_ref": "object",
       "source_path": "prompts/object.md"
     },
diff --git a/.opencode/skills/multimodal-issue-term-extractor-described-all/configurator/templates/multimodal-gts.json b/.opencode/skills/multimodal-issue-term-extractor-described-all/configurator/templates/multimodal-gts.json
--- a/.opencode/skills/multimodal-issue-term-extractor-described-all/configurator/templates/multimodal-gts.json
+++ b/.opencode/skills/multimodal-issue-term-extractor-described-all/configurator/templates/multimodal-gts.json
@@ -4,8 +4,8 @@
   "business": {
     "format_version": "3.0",
     "name": "GTS",
-    "version": "4.2.5",
-    "description": "保留当前GTS对象规则及用户确认的因子、预期等Prompt；同步HTML内置模板和内容校验，按验证目标组织预期。",
+    "version": "4.2.8",
+    "description": "保留用户当前确认的GTS对象、因子及预期等提取规则；同步HTML内置模板、版本与实际内容校验。",
     "template": "gts",
     "object_tree_path": null,
     "selection": {
@@ -27,7 +27,7 @@
           "测试对象"
         ],
         "dependencies": [],
-        "sha256": "ce37d9f8e33a648160807213c654f4f5a91c961e22c744fcc22f3a83e9ce2ec1",
+        "sha256": "753de2d9706f1bc9d6ac6700895d57f3cae44951ffb86c1fbbdb3c9d8f978322",
         "template_ref": "object",
         "source_path": "prompts/object.md"
       },
diff --git a/.opencode/skills/multimodal-issue-term-extractor-described-all/configurator/templates/multimodal-gts/prompts/object.md b/.opencode/skills/multimodal-issue-term-extractor-described-all/configurator/templates/multimodal-gts/prompts/object.md
--- a/.opencode/skills/multimodal-issue-term-extractor-described-all/configurator/templates/multimodal-gts/prompts/object.md
+++ b/.opencode/skills/multimodal-issue-term-extractor-described-all/configurator/templates/multimodal-gts/prompts/object.md
@@ -14,7 +14,7 @@
 - 文本和图片一致时，使用能够被两者共同支持的具体名称。
 - 文本使用“按钮”“页面”等泛称，而图片清晰显示具体名称时，可以用图片补全名称。
 - 图片中的相关页面、控件和检查内容可按本业务范围分别纳入；仅可见但与当前测试目标无关的背景元素不纳入。
-- 图片模糊、文字不可辨认或只能显示结果状态时，不得猜测对象名称。
+- 图片模糊、文字不可辨认或只能显示结果状态时，不猜图中未知名称；文本已给出名称的候选仍须按被测角色证据核对，不能把名称清楚等同于确实被测。缺少某对象的截图不等于图文冲突，只有同一事实的明确矛盾才按冲突处理。
 - 文本和图片冲突时，优先采用原始正文中明确表达的业务事实；原因分析中的推测不能覆盖清晰的直接证据，也不要静默用图片覆盖文本。
 
 仅依据当前问题单材料及下述明确限定的工具结果衔接先验判断，不从其他问题单、产品常识或示例中补写缺失的账号、操作、接口、预期和数据。示例只用于说明规则。
@@ -32,6 +32,12 @@
 #### 1. 测试相关实体完整性
 先回答本单实际验证什么，再检查输入内容、输出内容、被测功能或制品是否各有明确角色。例如一次查询的“用户查询内容”和“查询答案”不能被笼统的“查询系统”替代；具体查询语句属于数据，不把它另立为一个对象。
 
+**文本有而截图未覆盖的候选，先核对角色，再决定保留。** 必须能从本单原文确定实体指称，并找到以下至少一种直接依据：
+1. 该实体自身的功能、内容或状态正在被检查，或本单故障/正确要求直接指向它。
+2. 文本明确把当前被测控件的问题或核验范围定位到该产品业务界面，即该界面确实承载本次受检控件；不要求界面另有独立故障，但不能只凭常见布局或所属系统推测。
+ 
+内部逐项核对“候选对象—本单具体故障或检查—原文依据”能否对应。只出现名称、作为登录入口或导航经过、背景提及、关联应用、修复引用、外部观测手段，都不能据此通过。界面有控件的泛泛常识也不能代替该单的直接关联。通过上述核对后，即使没有该界面截图也保留；未通过时不以防止漏提为由补入，也不猜测未知界面。第1a节的有限职责归纳仍按其原有专门条件处理，不能借缺图规则扩大归纳范围。
+
 明确提供的原始用例和补充观察点可以扩大检查范围，但必须确实存在于本次输入中；仅有用例编号时不还原未知用例。
 
 #### 1a. 只补缺失的工具结果衔接职责
@@ -47,10 +53,12 @@
 
 #### 2. 对象层级与辨识粒度
 先保留业务对象，再条件性纳入扩展对象：
-- 界面功能、布局、可用性或控件比较问题：覆盖原文明确比较的控件，以及承载该检查的相关页面；不遍历所有可见控件。
+- 界面功能、布局、可用性或控件比较问题：保留被测控件，以及材料明确承载这些控件、发生该问题的产品业务界面。例如文本说明A页和B页上的两个按钮存在样式问题，即使截图只有B页，也保留A页、B页及这两个按钮。该关联来自文本对控件所在界面的明确说明，不扩展为所有祖先应用、任意打开的页面或未知界面。
 - 接口字段、资源指标或业务机制本身有明确检查目标/约束时：保留对应实体；存在独立意义的异常字段不能缩为“响应信息”。
 - 调试面板、监控平台和测试工具只是采证手段时，不因可见或被使用就自动加入；只有原始测试清单明确把它们列为检查对象，或其自身行为被验证时才纳入。
 - 类、函数、配置变量、事件内部实现仅解释根因时，用来理解机制，不逐项立对象；若原始材料明确验证某处理机制，优先使用稳定机制名，不展开它涉及的所有代码符号。
+
+两类界面按测试角色区分：控件的样式或交互发生在被测产品业务界面上，该界面与控件共同构成检查范围；外部观测工具只呈现服务、资源或数据的状态，它的界面不因承载曲线或结果而成为被测业务界面。逐项问“本单要判断它自身是否正确，还是借它查看另一个实体？”不能把前者的界面保留规则套到后者，也不能因排除观测工具而漏掉真正的服务或资源。
 
 报告类默认以报告整体为对象，语言、数据、章节及图表作为同一测试点中的关联检查内容，不分别生成测试点。用于校对报告的接口、参数和调试工具不因此自动成为对象；只有原始材料明确另行验证这些实体自身的行为/契约时才独立纳入。该规则优先于“允许父子层级分别保留”。根因补充中出现的接口、参数或代码名称只是候选线索，不自动构成独立验证要求。逐项问“本单是否单独验证它的行为/契约”：仅为解释报告异常或取证的依赖删去，不能因能画出技术链就把链上节点全列入。
 
@@ -66,7 +74,7 @@
 ## 片段：输出前检查
 
 ### 内部检查
-即使结果非空也先保留原文明确的实体与输入输出，避免新增泛模块挤掉具体机制；资源不能仅用其使用率替代，明确的隐私声明/用户协议等独立目标不笼统合成一个弹窗。再逐项核对：每个对象的证据和测试角色是什么；输入与输出是否被笼统系统名替代；是否漏掉明确比较项或异常字段；报告是否被接口/参数/工具扩散；仅解释原因的代码符号是否误入对象。按上述边界纠正候选，不输出检查过程，不为了贴合示例补实体。
+即使结果非空，也先核对候选是否确有被测角色，只保留角色有据的实体与输入输出，避免把提及名称误当被测证据，或让新增泛模块挤掉具体机制；资源不能仅用其使用率替代，明确的隐私声明/用户协议等独立目标不笼统合成一个弹窗。再逐项核对：每个对象的证据和测试角色是什么；输入与输出是否被笼统系统名替代；文本有而截图未覆盖的候选是否有具体被测角色依据，是否误把名称出现当入选理由；已通过角色核对的界面或控件是否反而因缺图被删除；是否把外部观测工具误当被测界面；是否漏掉明确比较项或异常字段；报告是否被接口/参数/工具扩散；仅解释原因的代码符号是否误入对象。按上述边界纠正候选，不输出检查过程，不为了贴合示例补实体。
 
 ## 片段：提取示例
 
@@ -74,25 +82,27 @@
 
 以下4例均为虚构合成场景，只说明本任务的提取边界。示例的字段名、数量和排布不限制真实输入；当前.md全部原始字段均须读取。图片信息是示例说明；真实任务须读取实际图片，不得把示例当成当前问题单的事实。
 
-#### Example 1：相关父页面与比较控件完整保留
+#### Example 1：文本明确两个承载界面，截图只覆盖其中一个
 
 问题单文本：
 
-【简要描述】在工单审批页点击加签按钮，再点击转交按钮，发现两按钮的键盘焦点框宽度不同。
-【开发测试报告】在工单审批页点击加签按钮，再点击转交按钮，发现两按钮的键盘焦点框宽度不同。规范明确同组操作按钮的焦点框均为2px，审批页和两个控件均在本次检查范围。
+【简要描述】工单审批页和批量审批页中的加签、转交按钮存在键盘焦点框宽度不一致的问题。
+【开发测试报告】分别核对工单审批页和批量审批页上的加签按钮、转交按钮。两个页面均承载这两个控件，规范明确同组按钮焦点框均为2px；本次只附了批量审批页截图。
 【原因分析】同组按钮使用了不同的焦点样式。
+【操作背景】从首页进入审批菜单；帮助页仅用于查阅操作说明，本单没有检查首页或帮助页自身的行为。
 【运行条件】预演环境；使用审批客户端；账号持有临时审批凭证但未绑定员工身份。
 【测试用例编号】SYN-G-01
 
-图片信息：显示工单审批页、加签按钮和转交按钮，浏览器收藏栏与任务栏也可见。
-
-判断要点：保留相关父页面及两个比较控件，不只提第一个异常按钮；收藏栏和任务栏不是检查实体。
+图片信息：只显示批量审批页上的加签按钮和转交按钮，浏览器收藏栏与任务栏也可见；没有工单审批页截图。
+ 
+判断要点：原文把两页上的按钮样式均列入检查范围，故两页有直接承载依据，即使只拍到一页也保留。首页、帮助页同样出现在文本且没有对应截图，但只有入口或背景角色，不纳入；审批客户端也不因是上级载体而加入。保留两页及两个按钮，不为每页重复生成同名按钮；收藏栏和任务栏不是检查实体。
 
 输出：
 
 {
   "测试对象": [
     "工单审批页",
+    "批量审批页",
     "加签按钮",
     "转交按钮"
   ]
````
