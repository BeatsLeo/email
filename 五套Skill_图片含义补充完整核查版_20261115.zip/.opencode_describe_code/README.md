# 图片问题含义补充提取

Skill：multimodal-issue-term-extractor-described-code。仅补入代码变更截图说明；始终读取全部原文与全部图片。

部署本目录的agents与skills到项目.opencode，指定业务后执行。Python 3.9+，GIF需要Pillow。主Agent自动调用内置脚本与Qwen-VL完成备份、分类、结合问题单逐图分析问题含义、补充副本及原业务提取。已有冻结准备目录可直接指定复用，避免重复转写。

每单完整JSON，再整批汇总Excel；图片说明与来源仅作运行审计。配置页面保持终端软工、GTS和常规原业务默认值。

图片分析侧重故障环节、关键矛盾和机制，区分图文依据与推测；不是OCR复述。旧版画面转写缓存不兼容，需用当前版本重新准备。
