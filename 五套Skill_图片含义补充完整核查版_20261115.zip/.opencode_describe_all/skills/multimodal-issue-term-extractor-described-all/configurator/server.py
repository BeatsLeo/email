"""Local business configuration workbench. Python 3.9+, no third-party packages."""
import argparse
import copy
import hashlib
import importlib.util
import json
import os
from pathlib import Path, PureWindowsPath
import re
import secrets
import tempfile
import threading
from datetime import datetime, timezone, timedelta
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlsplit
from urllib.request import urlopen
import webbrowser
import shutil
from contextlib import contextmanager


@contextmanager
def disk_lock(folder):
    """Serialize commits across separate launcher processes as well as browser tabs."""
    folder.mkdir(parents=True, exist_ok=True)
    stream = (folder / ".save.lock").open("a+b")
    if stream.tell() == 0:
        stream.write(b"0")
        stream.flush()
    stream.seek(0)
    try:
        if os.name == "nt":
            import msvcrt
            msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
        else:
            import fcntl
            fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
    except OSError:
        stream.close()
        raise ConfigError("另一个页面正在保存，请稍后重试。当前草稿仍保留。", "SAVE_BUSY", 409)
    try:
        yield
    finally:
        stream.seek(0)
        if os.name == "nt":
            msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
        else:
            fcntl.flock(stream.fileno(), fcntl.LOCK_UN)
        stream.close()

ASSETS = Path(__file__).resolve().parent
MAX_BODY = 4 * 1024 * 1024
TASK_NAMES = {"object": "测试对象", "test_point": "测试点", "action": "测试动作", "condition": "测试条件", "expectation": "预期结果", "factor_pair": "测试因子", "factor_names": "因子名称", "relation": "关联关系", "object_relation": "测试对象与测试对象关系", "factor_relation": "测试动作因子之间关系", "root_cause": "问题根因", "image_type": "图片类型", "object_tree": "对象树归属", "empty_recheck": "空结果复核"}


class ConfigError(Exception):
    def __init__(self, message, code="INVALID_CONFIG", status=422, **details):
        super().__init__(message)
        self.data = {"message": message, "code": code, **details}
        self.status = status


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + "\n").encode("utf-8")


def digest(data):
    return hashlib.sha256(data).hexdigest()


def service_build_id():
    files = [Path(__file__).resolve(), ASSETS / "app.js", ASSETS / "editor-core.js",
             ASSETS.parent / "scripts" / "plan_extraction.py", ASSETS.parent / "scripts" / "validate_result.py", ASSETS.parent / "scripts" / "prompt_compiler.py"]
    return digest(b"".join(p.name.encode() + b"\0" + p.read_bytes() + b"\0" for p in files))


def outside_lines(text):
    fence, offset = None, 0
    for line in text.splitlines(keepends=True):
        boundary = re.match(r"\s*(`{3,}|~{3,})([^\r\n]*)", line)
        if boundary:
            if not fence:
                fence = (boundary[1][0], len(boundary[1]))
            elif fence[0] == boundary[1][0] and len(boundary[1]) >= fence[1] and not boundary[2].strip():
                fence = None
        elif not fence:
            yield line, offset, offset + len(line)
        offset += len(line)


def prompt_sections(text):
    matches = []
    for line, start, end in outside_lines(text):
        heading = re.match(r"^### ([^\n]+)\n$", line)
        if heading:
            matches.append((heading[1].strip(), start, end))
    return [(heading, text[end:matches[i + 1][1] if i + 1 < len(matches) else len(text)]) for i, (heading, _start, end) in enumerate(matches)]


def example_records(text):
    section = next((body for heading, body in prompt_sections(text) if heading in ("Examples", "Example")), "")
    if not section:
        return []
    heads = [(start, end) for line, start, end in outside_lines(section) if re.match(r"^#### Example [^\n]*\n$", line)]
    parts = [section[end:heads[i + 1][0] if i + 1 < len(heads) else len(section)] for i, (_start, end) in enumerate(heads)]
    if not parts and "输出：" in section:
        parts = [section]
    values = []
    for body in parts:
        markers = [(start, end) for line, start, end in outside_lines(body) if re.match(r"^输出：[ \t]*(?:\r?\n|$)", line)]
        if not markers:
            raise ConfigError("示例缺少独立一行的“输出：”标记。")
        start, end = markers[-1]
        raw = body[end:].strip()
        raw = re.sub(r"^```(?:json)?\s*|\s*```$", "", raw)
        try:
            values.append((body[:start], json.loads(raw)))
        except (ValueError, TypeError):
            raise ConfigError("示例的期望输出不是合法JSON，请检查该示例。")
    return values


def examples(text):
    return [result for _context, result in example_records(text)]


def upstream_nodes(context):
    """Only structured upstream arrays are endpoints; surrounding prose is evidence, not nodes."""
    nodes, decoder, offset = {}, json.JSONDecoder(), 0
    keys = {"测试对象", "测试点", "测试动作", "测试条件", "预期结果", "测试动作因子", "测试数据因子"}
    def collect(value):
        if not isinstance(value, dict):
            return
        for key, array in value.items():
            if key in keys:
                if key in nodes and nodes[key] != array:
                    raise ConfigError("同一示例的上游字段重复且不一致：" + key)
                nodes[key] = array
            elif key in {"extracted_factors", "extracted_test_factors"}:
                collect(array)
    while True:
        start = context.find("{", offset)
        if start < 0:
            break
        try:
            value, length = decoder.raw_decode(context[start:])
        except ValueError:
            offset = start + 1
            continue
        collect(value)
        offset = start + length
    return nodes


def validate_pair(actions, data, prefix):
    scalar = lambda v: v is None or isinstance(v, str) and bool(v.strip())
    if not isinstance(actions, list) or not isinstance(data, list) or len(actions) != len(data):
        raise ConfigError(prefix + "第一阶段两个因子数组须等长。")
    for action, value in zip(actions, data):
        if not isinstance(action, str) or not action.strip():
            raise ConfigError(prefix + "动作因子不能为空。")
        n = action.count("<*>")
        if (n == 0 and value is not None) or (n == 1 and not scalar(value)) or (n > 1 and (not isinstance(value, list) or len(value) != n or not all(scalar(v) for v in value))):
            raise ConfigError(prefix + "数据槽与<*>参数数量或类型不一致。")


def validate_tree_example(context, items, prefix):
    nodes, stack, ids = {}, [], set()
    for line in context.splitlines():
        match = re.match(r"^([ \t]*)[-*+]\s+(.+?)\s+\[(category|object)\]\s+(\S+)\s*$", line)
        if not match:
            continue
        indent, name, kind, identity = len(match[1].expandtabs(4)), match[2].strip().strip("*"), match[3], match[4]
        while stack and stack[-1][0] >= indent:
            stack.pop()
        path = (stack[-1][1] if stack else "root") + "->" + name
        if path in nodes or identity in ids or "->" in name:
            raise ConfigError(prefix + "示例树包含重复路径、重复ID或不明确的节点名。")
        nodes[path] = (kind, identity)
        ids.add(identity)
        stack.append((indent, path))
    objects = upstream_nodes(context).get("测试对象")
    if objects is None:
        marker = re.search(r"输入测试对象[：:]\s*", context)
        if marker:
            try:
                objects, _ = json.JSONDecoder().raw_decode(context[marker.end():].lstrip())
            except ValueError:
                pass
    if not isinstance(objects, list) or any(not isinstance(v, str) or not v.strip() for v in objects):
        raise ConfigError(prefix + "示例输入须包含完整的测试对象数组。")
    if len(items) != len(objects):
        raise ConfigError(prefix + "归类数量须与输入测试对象一致。")
    for obj, item in zip(objects, items):
        if not isinstance(item, dict) or set(item) != {"测试对象", "归类方式", "归属路径", "目标节点类型", "目标节点ID", "新节点"}:
            raise ConfigError(prefix + "对象树结果结构不完整。")
        if item["测试对象"] != obj:
            raise ConfigError(prefix + "对象名称及顺序须与输入一致。")
        if item["归类方式"] == "existing":
            node = nodes.get(item["归属路径"]) if isinstance(item["归属路径"], str) else None
            if not node or node != (item["目标节点类型"], item["目标节点ID"]) or item["新节点"] is not None:
                raise ConfigError(prefix + "已有节点的路径、类型和ID须与示例树一致，新节点须为null。")
        elif item["归类方式"] == "new":
            new = item["新节点"]
            if item["目标节点类型"] != "category" or item["目标节点ID"] is not None or not isinstance(new, dict) or set(new) != {"父节点路径", "节点名称", "节点类型"}:
                raise ConfigError(prefix + "新分类节点结构无效。")
            parent, name = new["父节点路径"], new["节点名称"]
            if not isinstance(parent, str) or parent not in nodes or nodes[parent][0] != "category" or not isinstance(name, str) or not name.strip() or "->" in name or new["节点类型"] != "category" or item["归属路径"] != parent + "->" + name or item["归属路径"] in nodes:
                raise ConfigError(prefix + "新节点必须位于真实分类父节点下，且名称与输出路径一致。")
        else:
            raise ConfigError(prefix + "归类方式只能是existing或new。")


def validate_examples(task, text, keys, relations, task_spec=None):
    def scalar(v):
        return v is None or isinstance(v, str) and bool(v.strip())
    scope = (task_spec or {}).get("relation_types")
    relation_specs = {r["name"]: r for r in relations if scope is None or r["name"] in scope}
    for i, (context, result) in enumerate(example_records(text), 1):
        prefix = TASK_NAMES[task] + "示例" + str(i) + "："
        if not isinstance(result, dict) or set(result) != set(keys):
            raise ConfigError(prefix + "输出字段须为" + "、".join(keys))
        if task == "root_cause":
            if not isinstance(result[keys[0]], str):
                raise ConfigError(prefix + "根因须为文本，证据不足可为空字符串。")
            continue
        if any(not isinstance(result[k], list) for k in keys):
            raise ConfigError(prefix + "要素输出须为数组。")
        if task == "test_point" and (len(result[keys[0]]) != 1 or not isinstance(result[keys[0]][0], str) or not result[keys[0]][0].strip()):
            raise ConfigError(prefix + "测试点必须且只能是一个非空测试点描述。")
        if task == "expectation" and (task_spec or {}).get("expectation_alignment") == "factor_steps":
            nodes = upstream_nodes(context)
            validator_path = ASSETS.parent / "scripts" / "validate_result.py"
            module_spec = importlib.util.spec_from_file_location("step_expectation_validator", validator_path)
            validator = importlib.util.module_from_spec(module_spec)
            module_spec.loader.exec_module(validator)
            try:
                validator.step_expectations(result[keys[0]], {k: nodes.get(k) for k in ("测试动作因子", "测试数据因子")})
            except ValueError as error:
                raise ConfigError(prefix + str(error))
        if task in ("factor_pair", "factor_names"):
            a, b = (result[k] for k in keys)
            if len(a) != len(b) or any(not isinstance(x, str) or not x.strip() for x in a):
                raise ConfigError(prefix + "两列须等长，动作或名称不能为空。")
            if task == "factor_pair":
                validate_pair(a, b, prefix)
            else:
                nodes = upstream_nodes(context)
                f, d = nodes.get("测试动作因子"), nodes.get("测试数据因子")
                validate_pair(f, d, prefix)
                if len(a) != len(f):
                    raise ConfigError(prefix + "名称数组与示例输入的因子槽位不等长。")
                if any("<*>" in name for name in a):
                    raise ConfigError(prefix + "动作名称不能包含参数标记。")
                for action, data, names in zip(f, d, b):
                    n = action.count("<*>")
                    if n == 0 and names is not None:
                        raise ConfigError(prefix + "无参数槽位的数据名称须为null。")
                    if n == 1 and (not scalar(names) or data is not None and names is None):
                        raise ConfigError(prefix + "已知数据必须有对应名称。")
                    if n > 1:
                        if not isinstance(names, list) or len(names) != n or not all(scalar(v) for v in names):
                            raise ConfigError(prefix + "多参数名称须与上游参数等长同序。")
                        if any(value is not None and name is None for value, name in zip(data, names)):
                            raise ConfigError(prefix + "已知数据必须有对应名称。")
                    if any(isinstance(name, str) and "<*>" in name for name in (names if isinstance(names, list) else [names])):
                        raise ConfigError(prefix + "数据名称不能包含参数标记。")
            for action, data in zip(a, b):
                if not scalar(data) and not (isinstance(data, list) and len(data) >= 2 and all(scalar(v) for v in data)):
                    raise ConfigError(prefix + "数据须为文本/null或有序参数子数组。")
                if task == "factor_pair":
                    n = action.count("<*>")
                    if (n == 0 and data is not None) or (n == 1 and not scalar(data)) or (n > 1 and (not isinstance(data, list) or len(data) != n)):
                        raise ConfigError(prefix + "数据槽与<*>参数数量不一致。")
        elif task == "relation" or (task_spec or {}).get("task_kind") == "relation":
            nodes = upstream_nodes(context)
            factor_only_scope = bool(scope) and bool(relation_specs) and all(spec["head"] == spec["tail"] == "测试动作因子" for spec in relation_specs.values())
            if "测试动作因子" in nodes or factor_only_scope:
                validate_pair(nodes.get("测试动作因子"), nodes.get("测试数据因子"), prefix)
            # Validate upstream cardinality even when this example has no edges.
            if "测试点" in nodes and (not isinstance(nodes["测试点"], list) or len(nodes["测试点"]) != 1 or not isinstance(nodes["测试点"][0], str) or not nodes["测试点"][0].strip()):
                raise ConfigError(prefix + "上游测试点须为唯一非空测试点描述。")
            seen = set()
            for item in result[keys[0]]:
                if not isinstance(item, dict) or set(item) != {"头实体", "关系", "尾实体"} or any(not isinstance(v, str) or not v.strip() for v in item.values()):
                    raise ConfigError(prefix + "每条关系应包含头实体、关系、尾实体。")
                if item["关系"] not in relation_specs:
                    raise ConfigError(prefix + "关系类型不在本模板支持范围中。")
                spec = relation_specs[item["关系"]]
                for endpoint, category in (("头实体", spec["head"]), ("尾实体", spec["tail"])):
                    array = nodes.get(category)
                    if not isinstance(array, list) or any(not isinstance(v, str) for v in array) or item[endpoint] not in array:
                        raise ConfigError(prefix + endpoint + "必须逐字来自示例输入的“" + category + "”数组。")
                if spec["head"] == spec["tail"] and item["头实体"] == item["尾实体"]:
                    raise ConfigError(prefix + "同类节点不能自环。")
                endpoints = (item["头实体"], item["尾实体"])
                if item["关系"] == "因子并列因子":
                    endpoints = tuple(sorted(endpoints))
                edge = (item["关系"],) + endpoints
                if edge in seen:
                    raise ConfigError(prefix + "关系重复或并列关系反向重复。")
                seen.add(edge)
        elif task == "object_tree":
            validate_tree_example(context, result[keys[0]], prefix)
        else:
            if any(not isinstance(v, str) or not v.strip() for v in result[keys[0]]):
                raise ConfigError(prefix + "每项应为非空文本。")
            if task == "image_type" and any(v not in ["UI界面截图", "录屏动画", "调试工具截图", "代码变更截图"] for v in result[keys[0]]):
                raise ConfigError(prefix + "请使用固定的四类图片类型。")


class Workbench:
    def __init__(self, skill_root=None):
        root = Path(skill_root or ASSETS.parent).resolve()
        self.roots = {"multimodal": root}
        self.lock = threading.RLock()
        self.token = secrets.token_urlsafe(32)
        # Keep the loaded build fixed: a running service must not impersonate code installed later.
        self.build_id = service_build_id()

    def root(self, mode):
        if not isinstance(mode, str) or mode not in self.roots:
            raise ConfigError("该提取模式未安装。", status=404)
        return self.roots[mode]

    def compiler(self, mode):
        path = self.root(mode) / "scripts" / "prompt_compiler.py"
        spec = importlib.util.spec_from_file_location("workbench_prompt_compiler", path)
        module = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(module)
        return module

    def template(self, mode, key):
        self.root(mode)
        if key not in ("terminal", "gts", "default"):
            raise ConfigError("请选择终端软工、GTS或常规模板。")
        template = read_json(ASSETS / "templates" / (mode + "-" + key + ".json"))
        if "prompt_dir" in template:
            compiler = self.compiler(mode)
            template["prompts"] = {}
            factory_root = (ASSETS / "templates").resolve()
            folder = (factory_root / template.pop("prompt_dir")).resolve()
            if not folder.is_relative_to(factory_root):
                raise ConfigError("默认模板目录无效。")
            for task, spec in {**template["business"]["prompts"], "empty_recheck": template["business"]["recheck"]}.items():
                path = (folder / compiler.source_path(spec)).resolve()
                if not path.is_relative_to(folder) or digest(path.read_bytes()) != spec.get("sha256"):
                    raise ConfigError("默认业务Markdown与配置校验不一致：" + task)
                layout, _signature = compiler.library(self.root(mode), task)
                template["prompts"][task] = compiler.render_fragment(path.read_text(encoding="utf-8-sig"), layout, template["business"]["name"])
        # Editable selection is a view of the single stored business configuration.
        template["selection"] = template["business"]["selection"]
        return template

    def registry(self, mode):
        return read_json(self.root(mode) / "config" / "business_registry.json")

    def destination(self, mode, relative):
        if not isinstance(relative, str) or not relative.strip():
            raise ConfigError("请填写保存目录，例如businesses/交付验证。", field="path")
        value = relative.replace("\\", "/")
        if PureWindowsPath(value).is_absolute() or PureWindowsPath(value).drive or value.startswith("/"):
            raise ConfigError("保存目录请使用相对Skill的路径。", field="path")
        parts = value.split("/")
        if any(p in ("", ".", "..") or re.search(r'[<>:"|?*\x00-\x1f]', p) or p.endswith((".", " ")) or re.fullmatch(r"(?i)(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\..*)?", p) for p in parts):
            raise ConfigError("保存目录含无效名称或越界片段，请使用businesses/业务名称。", field="path")
        if parts[0].lower() in {"config", "scripts", "references", "configurator", "agents", "prompt_templates", "skill.md"}:
            raise ConfigError("请使用业务目录，不能覆盖Skill程序或系统配置目录。", field="path")
        root = self.root(mode)
        target = (root / value).resolve()
        if target == root or not target.is_relative_to(root):
            raise ConfigError("保存目录不能超出当前Skill。", field="path")
        if target.is_symlink() or any(p.is_symlink() for p in (root / value, *(root / value).parents) if p != root.parent):
            raise ConfigError("保存目录不能通过符号链接指向其他位置。", field="path")
        return target, value

    def fingerprint(self, mode, folder=None, registry_entry=None):
        data = bytearray(json_bytes(registry_entry) if registry_entry is not None else (self.root(mode) / "config" / "business_registry.json").read_bytes())
        public_index = self.root(mode) / "prompt_templates" / "index.json"
        if public_index.is_file():
            data.extend(public_index.read_bytes())
        if folder and folder.is_dir():
            for p in sorted(folder.rglob("*")):
                if p.is_symlink():
                    raise ConfigError("业务目录包含符号链接，无法安全保存。")
                if p.is_file():
                    data.extend(p.relative_to(folder).as_posix().encode())
                    data.extend(p.read_bytes())
        return digest(data)

    def bootstrap(self):
        return {"token": self.token, "build_id": self.build_id, "service_current": self.is_current(), "task_names": TASK_NAMES, "modes": [{"id": mode, "title": "图文问题单" if mode == "multimodal" else "文本问题单", "root": str(root), "businesses": [{"name": name, "path": entry["bundle_dir"]} for name, entry in self.registry(mode)["businesses"].items()]} for mode, root in self.roots.items()], "templates": [{"key": k, "title": t} for k, t in [("terminal", "终端软工"), ("gts", "GTS"), ("default", "常规")]]}

    def is_current(self):
        return self.build_id == service_build_id()

    def health(self):
        return {"ready": True, "workspace": digest(str(self.root("multimodal")).encode()), "build_id": self.build_id}

    def can_reuse(self, health):
        return isinstance(health, dict) and health.get("ready") is True and health.get("workspace") == self.health()["workspace"] and health.get("build_id") == self.build_id

    def load(self, mode, name):
        entry = self.registry(mode)["businesses"].get(name)
        if not entry:
            raise ConfigError("该业务尚未配置。", status=404)
        folder, relative = self.destination(mode, entry["bundle_dir"])
        manifest = read_json(folder / "business.json")
        if manifest.get("format_version") != "3.0" or manifest.get("name") != name:
            raise ConfigError("业务配置格式或注册名称不一致。")
        key = manifest["template"]
        compiler = self.compiler(mode)
        prompts = {task: compiler.read_prompt(folder, spec, name)[0] for task, spec in manifest["prompts"].items()}
        prompts["empty_recheck"] = compiler.read_prompt(folder, manifest["recheck"], name)[0]
        selection = manifest["selection"]
        return {"mode": mode, "name": name, "description": manifest.get("description", ""), "aliases": entry.get("aliases", [name]), "path": relative, "tree_path": manifest.get("object_tree_path") or "", "template": key, "selection": selection, "prompts": prompts, "prompt_base_business": name, "source_name": name, "revision": self.fingerprint(mode, folder, entry)}

    def validate_document(self, doc):
        if not isinstance(doc, dict):
            raise ConfigError("配置内容无效。")
        mode, name = doc.get("mode"), doc.get("name", "")
        self.root(mode)
        if not isinstance(name, str) or not name.strip() or name != name.strip() or len(name) > 60 or re.search(r'[<>:"/\\|?*\x00-\x1f]', name) or name.endswith((".", " ")) or re.fullmatch(r"(?i)(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\..*)?", name) or name in (".", "..", "__proto__"):
            raise ConfigError("请填写有效业务名称，例如“交付验证”，不含路径符号。", field="name")
        target, relative = self.destination(mode, doc.get("path"))
        base = self.template(mode, doc.get("template"))
        aliases = doc.get("aliases", [])
        if not isinstance(aliases, list) or any(not isinstance(a, str) or not a.strip() or len(a) > 80 for a in aliases):
            raise ConfigError("业务别名请每行填写一个名称。", field="aliases")
        aliases = list(dict.fromkeys([name] + [a.strip() for a in aliases]))
        normalized = {a.lower() for a in aliases}
        registry = self.registry(mode)
        for other_name, entry in registry["businesses"].items():
            if other_name == name:
                continue
            if normalized.intersection(a.strip().lower() for a in [other_name] + entry.get("aliases", [])):
                raise ConfigError("业务名称或别名与“" + other_name + "”冲突，请换一个名称。", field="aliases")
            other, _ = self.destination(mode, entry["bundle_dir"])
            if target == other or target.is_relative_to(other) or other.is_relative_to(target):
                raise ConfigError("保存目录与“" + other_name + "”的目录重叠，请使用独立目录。", field="path")
        if target.exists() and (not target.is_dir() or any(target.iterdir()) and not (target / "business.json").is_file()):
            raise ConfigError("该位置不是业务配置目录，请选择新的空目录。", field="path")
        for key in ("description", "tree_path"):
            if not isinstance(doc.get(key, ""), str) or len(doc.get(key, "")) > 12000:
                raise ConfigError("业务说明或对象树路径内容无效。", field=key)
        expected_tasks = set(base["prompts"])
        prompts = doc.get("prompts")
        if not isinstance(prompts, dict) or set(prompts) != expected_tasks:
            raise ConfigError("任务内容不完整，请恢复模板或重新载入业务。")
        for task, text in prompts.items():
            if not isinstance(text, str) or not text.strip() or len(text) > 150000:
                raise ConfigError(TASK_NAMES[task] + "规则为空或过长。", task=task)
            original = prompt_sections(base["prompts"][task])
            current = prompt_sections(text)
            if [h for h, _ in original] != [h for h, _ in current]:
                raise ConfigError(TASK_NAMES[task] + "章节结构已改变，请只修改章节内的内容。", task=task)
            for (h, body), (_, new_body) in zip(original, current):
                if ("输入" in h or "输出格式" in h or h == "执行边界") and body.strip() != new_body.strip():
                    raise ConfigError(TASK_NAMES[task] + "的系统输入/输出约定不可修改，请恢复后再保存。", task=task)
            if task != "empty_recheck":
                spec = base["business"]["prompts"][task]
                try:
                    validate_examples(task, text, spec["output_keys"], base["business"]["relations"], spec)
                except ConfigError as error:
                    error.data["task"] = task
                    raise
        selection = doc.get("selection")
        if not isinstance(selection, dict):
            raise ConfigError("请选择至少一项需要提取的内容。", field="selection")
        return base, target, relative, aliases, registry

    def compile(self, doc, stage):
        base, target, relative, aliases, registry = self.validate_document(doc)
        manifest = copy.deepcopy(base["business"])
        name = doc["name"]
        version = base["business"]["version"].split("-", 1)[0] + "-" + datetime.now(timezone(timedelta(hours=8))).strftime("%Y%m%d%H%M%S%f")
        files = {}
        compiler = self.compiler(doc["mode"])
        for task, spec in manifest["prompts"].items():
            layout, _signature = compiler.library(self.root(doc["mode"]), task)
            fragment = compiler.pack_fragment(doc["prompts"][task], layout, name, doc.get("prompt_base_business", base["business"]["name"]))
            value = fragment.encode("utf-8")
            files[compiler.source_path(spec)] = value
            spec["sha256"] = digest(value)
        layout, _signature = compiler.library(self.root(doc["mode"]), "empty_recheck")
        review = compiler.pack_fragment(doc["prompts"]["empty_recheck"], layout, name, doc.get("prompt_base_business", base["business"]["name"])).encode("utf-8")
        files[compiler.source_path(manifest["recheck"])] = review
        manifest.update(name=name, version=version, description=doc.get("description", ""), template=doc["template"], selection=copy.deepcopy(doc["selection"]), object_tree_path=doc.get("tree_path") or None)
        manifest["recheck"]["sha256"] = digest(review)
        files["business.json"] = json_bytes(manifest)
        for relative_file, data in files.items():
            path = stage / relative_file
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
        # Execute the same deterministic planner used by OpenCode, not a second policy engine.
        planner_path = self.root(doc["mode"]) / "scripts" / "plan_extraction.py"
        module_spec = importlib.util.spec_from_file_location("configured_extraction_plan", planner_path)
        module = importlib.util.module_from_spec(module_spec)
        module_spec.loader.exec_module(module)
        try:
            plan = module.build_plan(stage)
        except (ValueError, KeyError, TypeError, OSError) as error:
            raise ConfigError("提取清单检查未通过：" + str(error), field="selection")
        return files, plan, target, relative, aliases, registry

    def process(self, doc, save=False, overwrite=False, confirmation_revision=None):
        if not self.is_current():
            raise ConfigError("配置程序已升级，请重新打开Skill中的业务配置入口后再保存。当前草稿仍保留。", "SERVICE_OUTDATED", 409)
        if not isinstance(doc, dict):
            raise ConfigError("配置内容须为有效对象。")
        with self.lock, disk_lock(self.root(doc.get("mode")) / "configurator"):
            return self._process(doc, save, overwrite, confirmation_revision)

    def _process(self, doc, save=False, overwrite=False, confirmation_revision=None):
        with self.lock:
            root = self.root(doc.get("mode"))
            work = root / "configurator" / ".transactions"
            work.mkdir(parents=True, exist_ok=True)
            with tempfile.TemporaryDirectory(prefix="prepare-", dir=work) as tmp:
                stage = Path(tmp) / "bundle"
                stage.mkdir()
                files, plan, target, relative, aliases, registry = self.compile(doc, stage)
                source_name = doc.get("source_name")
                if source_name:
                    entry = registry["businesses"].get(source_name)
                    if not entry:
                        raise ConfigError("此业务已被其他操作修改，请重新载入。当前草稿仍保留。", "SOURCE_CHANGED", 409)
                    source, _ = self.destination(doc["mode"], entry["bundle_dir"])
                    if doc.get("revision") != self.fingerprint(doc["mode"], source, entry):
                        raise ConfigError("配置已在其他页面更新，请重新载入后再保存。当前草稿仍保留。", "SOURCE_CHANGED", 409)
                current_revision = self.fingerprint(doc["mode"], target)
                conflicts = []
                if doc["name"] in registry["businesses"]:
                    conflicts.append("已登记的“" + doc["name"] + "”业务")
                if target.exists():
                    conflicts.append(relative + "目录中的现有配置")
                result = {"fields": plan["output_fields"], "tasks": list(plan["tasks"]), "relations": plan["effective_relations"], "internal_fields": plan["internal_fields"], "object_tree_enabled": plan["object_tree_enabled"], "files": list(files), "path": relative, "warnings": [TASK_NAMES[t] + "未提供示例，将按规则提取。" for t, text in doc["prompts"].items() if t != "empty_recheck" and not examples(text)]}
                if not save:
                    return result
                if conflicts and (not overwrite or confirmation_revision != current_revision):
                    raise ConfigError("保存将覆盖以下配置，请确认。", "OVERWRITE_REQUIRED" if not overwrite else "TARGET_CHANGED", 409, conflicts=conflicts, confirmation_revision=current_revision, path=relative)
                registry["businesses"][doc["name"]] = {"aliases": aliases, "bundle_dir": relative}
                registry_path = root / "config" / "business_registry.json"
                backups = root / "configurator" / "backups"
                stamp = datetime.now(timezone(timedelta(hours=8))).strftime("%Y%m%d_%H%M%S") + "_" + secrets.token_hex(4)
                backup = backups / stamp
                backup.mkdir(parents=True)
                old_registry = registry_path.read_bytes()
                (backup / "business_registry.json").write_bytes(old_registry)
                moved_old = False
                installed = False
                target.parent.mkdir(parents=True, exist_ok=True)
                # The absolute targets have been resolved and checked within this Skill above.
                if target.exists():
                    # Preserve unrecognized user files instead of silently deleting them.
                    for p in target.rglob("*"):
                        if p.is_file() and p.relative_to(target).as_posix() not in files and p.relative_to(target).as_posix() not in {"manifest.json", "extraction_config.json"}:
                            dest = stage / p.relative_to(target)
                            dest.parent.mkdir(parents=True, exist_ok=True)
                            shutil.copy2(p, dest)
                try:
                    if target.exists():
                        os.replace(target, backup / "bundle")
                        moved_old = True
                    os.replace(stage, target)
                    installed = True
                    pending = backup / "registry.pending"
                    pending.write_bytes(json_bytes(registry))
                    os.replace(pending, registry_path)
                except OSError:
                    if installed:
                        os.replace(target, backup / "failed_new_bundle")
                    if moved_old:
                        os.replace(backup / "bundle", target)
                    # Registry replace is last; failure leaves the old registry intact.
                    raise ConfigError("文件被占用或没有写入权限，已恢复原配置；请关闭占用程序后重试。", "WRITE_FAILED", 500)
                result.update(message="已保存并生效，返回OpenCode即可使用。", backup=str(backup.relative_to(root)), document=self.load(doc["mode"], doc["name"]))
                return result


def make_handler(app):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *_args):
            pass

        def valid_host(self):
            return self.headers.get("Host") == "127.0.0.1:" + str(self.server.server_port)

        def response(self, value, status=200, content_type="application/json; charset=utf-8"):
            data = json_bytes(value) if content_type.startswith("application/json") else value
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(data)))
            self.send_header("Cache-Control", "no-store")
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("X-Frame-Options", "DENY")
            self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; connect-src 'self'; img-src 'self' data:; frame-ancestors 'none'; base-uri 'none'")
            self.end_headers()
            self.wfile.write(data)

        def do_GET(self):
            if not self.valid_host():
                return self.response({"message": "仅支持本机工作台地址。"}, 403)
            parts = urlsplit(self.path)
            query = {k: v[0] for k, v in parse_qs(parts.query).items()}
            try:
                if parts.path == "/api/bootstrap":
                    return self.response(app.bootstrap())
                if parts.path == "/api/document":
                    return self.response(app.load(query.get("mode"), query.get("name")))
                if parts.path == "/api/template":
                    return self.response(app.template(query.get("mode"), query.get("key")))
                if parts.path == "/api/health":
                    return self.response(app.health())
                assets = {"/": ("index.html", "text/html; charset=utf-8"), "/index.html": ("index.html", "text/html; charset=utf-8"), "/app.js": ("app.js", "application/javascript; charset=utf-8"), "/editor-core.js": ("editor-core.js", "application/javascript; charset=utf-8"), "/styles.css": ("styles.css", "text/css; charset=utf-8")}
                if parts.path not in assets:
                    return self.response({"message": "页面不存在。"}, 404)
                file, mime = assets[parts.path]
                return self.response((ASSETS / file).read_bytes(), content_type=mime)
            except ConfigError as error:
                self.response(error.data, error.status)
            except (OSError, ValueError, KeyError) as error:
                self.response({"message": "配置读取失败：" + str(error), "code": "READ_FAILED"}, 500)

        def do_POST(self):
            origin = "http://127.0.0.1:" + str(self.server.server_port)
            if not self.valid_host() or self.headers.get("Origin") != origin or not secrets.compare_digest(self.headers.get("X-Config-Token", ""), app.token):
                return self.response({"message": "请从本机配置工作台重新打开后保存。"}, 403)
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if not 0 < length <= MAX_BODY:
                    raise ConfigError("配置内容过大或为空。")
                body = json.loads(self.rfile.read(length))
                if not isinstance(body, dict):
                    raise ConfigError("请求内容须为有效配置对象。")
                if self.path not in ("/api/check", "/api/save"):
                    return self.response({"message": "接口不存在。"}, 404)
                result = app.process(body.get("document", {}), save=self.path == "/api/save", overwrite=body.get("overwrite") is True, confirmation_revision=body.get("confirmation_revision"))
                return self.response(result)
            except ConfigError as error:
                self.response(error.data, error.status)
            except (OSError, ValueError, KeyError, TypeError) as error:
                self.response({"message": "未能完成操作：" + str(error) + "。当前草稿仍保留。", "code": "OPERATION_FAILED"}, 500)
    return Handler


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--skill-root")
    parser.add_argument("--port", type=int, default=0)
    parser.add_argument("--no-browser", action="store_true")
    parser.add_argument("--mode", choices=["multimodal", "text"], default="multimodal")
    args = parser.parse_args()
    app = Workbench(args.skill_root)
    endpoint_file = app.root("multimodal") / "configurator" / ".service.json"
    if not args.no_browser and endpoint_file.is_file():
        try:
            endpoint = read_json(endpoint_file)
            known = "http://127.0.0.1:" + str(int(endpoint["port"]))
            with urlopen(known + "/api/health", timeout=1) as response:
                health = json.load(response)
            if app.can_reuse(health):
                webbrowser.open(known + ("/?mode=text" if args.mode == "text" else "/"))
                return
        except (OSError, ValueError, KeyError):
            pass
    server = ThreadingHTTPServer(("127.0.0.1", args.port), make_handler(app))
    url = "http://127.0.0.1:" + str(server.server_port) + ("/?mode=text" if args.mode == "text" else "/")
    endpoint_file.parent.mkdir(parents=True, exist_ok=True)
    endpoint_file.write_bytes(json_bytes({"port": server.server_port, "pid": os.getpid()}))
    try:
        print(url, flush=True)
    except (OSError, AttributeError):
        pass
    if not args.no_browser:
        webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
