(function () {
  'use strict';
  const C = window.PromptEditor, $ = id => document.getElementById(id);
  const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const state = {boot:null,doc:null,template:null,page:'setup',tab:'rules',dirty:false,modified:false,busy:false,pathManual:false,invalidRaw:{},draftStored:false,compatibility:[],legacyDraft:null,legacyDraftKey:null};
  const descriptions = {'测试对象':'被测试、被检查的实体，按业务口径确定范围。','测试点':'本单需要重点验证的内容。一条中可保留相关检查项和约束，必须非空。','测试动作':'测试人员实际执行的具体操作。','测试条件':'环境、账号、模式和数据准备等前提。','预期结果':'当前场景应得到的正确行为或状态。','测试动作因子':'按顺序排列的可复用操作或验证模板。','测试数据因子':'与动作因子逐槽对应的参数取值。','动作因子名称':'为第一阶段的动作因子概括稳定名称。','数据因子名称':'为数据参数概括用途或类别。','关联关系':'连接本次已选要素，保留方向与证据。','测试对象与测试对象关系':'独立提取对象之间的包含、依赖或明确处理先后，只等待测试对象。','测试动作因子之间关系':'独立提取动作因子之间的直接先后或明确并列，只等待完整因子对。','问题根因':'有直接证据支持的底层错误机制。','测试对象树归属':'提取完成后，使用GLM5.1归入已有对象树。','图片类型':'通常只作根因任务内部依赖，可按需导出。'};
  const stepwiseExpectation = () => state.template?.business.prompts.expectation?.expectation_alignment === 'factor_steps';
  const fieldDescription = key => stepwiseExpectation() ? ({'测试点':'简洁概括本单核心验证主题，保留必要条件，不展开完整流程。','测试动作因子':'按顺序保留完整的准备、操作和检查流程，可变数据写为<*>。','测试数据因子':'逐步绑定<*>的实际取值，没有参数时为null。','预期结果':'先提取因子，再按原步骤号给出预期；每步最多一条，无明确预期可省略。'}[key] || descriptions[key]) : descriptions[key];
  const hints = {name:'例如：GTS交付验证。之后在OpenCode中报这个名称即可。',description:'例如：覆盖交付验收中的页面、接口和服务资源检查。简要说明业务用途即可。',aliases:'例如：交付测试、GTS交付；每行一个。不需要其他叫法时保留默认值。',path:'例如：businesses/交付验证。系统已自动填写；有指定目录时再改。',tree_path:'例如：C:/测试资料/对象树.md。也可以留空，执行提取任务时再提供。'};
  const isRelationTask = task => task==='relation'||state.template?.business.prompts[task]?.task_kind==='relation';
  const relationTypes = task => state.template.business.relations.filter(r=>(state.template.business.prompts[task].relation_types??state.template.business.relations.map(x=>x.name)).includes(r.name));
  const activeRelationTypes = () => state.template.business.relations.filter(r=>Object.entries(state.template.business.prompts).some(([task,spec])=>isRelationTask(task)&&spec.output_keys.some(k=>state.doc.selection['提取内容'].includes(k))&&relationTypes(task).some(x=>x.name===r.name)));
  const taskTitle = task => state.boot.task_names[task] || task;
  const modeInfo = () => state.boot.modes.find(m => m.id === state.doc.mode);
  const plan = () => C.plan(state.doc,state.template.business);
  const storageKey = () => 'issue-workbench-v3:' + modeInfo().root;
  const locked = p => C.isLocked(p.heading);
  function notice(text,warning=false) { $('message').textContent=text; $('message').classList.toggle('warning',warning); $('message').hidden=!text; }
  function error(message,field=null,task=null) {
    $('errors').textContent=message; $('errors').hidden=false;
    if(task) { state.page='task/'+task; render(); }
    const input = field && document.querySelector('[data-meta="'+field+'"]');
    if(input) { for(let parent=input.parentElement;parent;parent=parent.parentElement)if(parent.tagName==='DETAILS')parent.open=true;input.setAttribute('aria-invalid','true');input.focus(); } else $('errors').focus();
  }
  function clearErrors() { $('errors').hidden=true; document.querySelectorAll('[aria-invalid]').forEach(e=>e.removeAttribute('aria-invalid')); }
  async function api(path,body) {
    const response = await fetch(path,{method:body?'POST':'GET',headers:body?{'Content-Type':'application/json','X-Config-Token':state.boot.token}:{},body:body?JSON.stringify(body):undefined});
    const data = await response.json(); if(!response.ok) { const failure=Error(data.message||'操作未完成'); failure.data=data; throw failure; } return data;
  }
  function setBusy(value) { state.busy=value; $('editor').disabled=value; for(const id of ['save','preview','home-new-business','back-business','mode','business','template','reset-task']) $(id).disabled=value||id==='save'&&!!state.doc?.source_name&&!state.dirty; }
  function draft() {
    if(state.legacyDraft&&!preserveLegacyDraft(state.legacyDraft))return false;
    try { localStorage.setItem(storageKey(),JSON.stringify({doc:state.doc,page:state.page,modified:state.modified,invalidRaw:state.invalidRaw,sourcePath:state.sourcePath,sourceAliases:state.sourceAliases,pathManual:state.pathManual,aliasesManual:state.aliasesManual,savedAt:Date.now()})); state.draftStored=true;return true; } catch { state.draftStored=false;return false; }
  }
  function preserveLegacyDraft(stored) {
    const key=state.legacyDraftKey||storageKey(),raw=JSON.stringify(stored);
    try {localStorage.setItem(key+':previous:'+Date.now(),raw);if(localStorage.getItem(key)===raw)localStorage.removeItem(key);state.legacyDraft=null;state.legacyDraftKey=null;return true;}
    catch {state.legacyDraft=stored;state.legacyDraftKey=key;state.draftStored=false;return false;}
  }
  function markChanged() {
    state.dirty=true; state.modified=true; const stored=draft();
    $('save-state').textContent=stored?'草稿已暂存 · 尚未生效':'尚未保存 · 本机草稿存储不可用'; $('save-state').classList.add('dirty');
    $('save').textContent=state.doc.source_name?'保存修改':'保存并使用';
    $('save').disabled=state.busy;
    syncContext();
  }
  function syncSelects() {
    $('mode').innerHTML=state.boot.modes.map(m=>'<option value="'+m.id+'">'+esc(m.title)+'</option>').join(''); $('mode').value=state.doc.mode;
    const entries=modeInfo().businesses; $('business').innerHTML=entries.map(b=>'<option value="'+esc(b.name)+'">'+esc(b.name)+'</option>').join('') + (!state.doc.source_name?'<option value="__new__">'+esc(state.doc.name)+'（新建）</option>':'');
    $('business').value=state.doc.source_name||'__new__'; $('template').value=state.doc.template;
    syncContext();
  }
  function syncContext(){ $('active-business').textContent=state.doc.name;$('active-business-state').textContent=(state.doc.source_name?'已有业务 · ':'新建业务 · ')+(state.dirty?'尚未生效':'已保存');$('template-name').textContent=state.template.title; }
  function navigation() {
    $('navigation').innerHTML=[['setup','业务首页'],['scope','提取哪些内容'],['rules','调整提取规则']].map(([id,label])=>'<button class="nav-button" data-page="'+id+'"'+(state.page===id||id==='rules'&&state.page.startsWith('task/')?' aria-current="page"':'')+'>'+label+(id==='setup'?'':'<span class="nav-hint">可选</span>')+'</button>').join('');
  }
  function field(label,id,value,extra={}) {
    const attrs=' id="'+id+'" '+(extra.attrs||'')+' aria-describedby="'+id+'-help"';
    return '<div class="field"><label for="'+id+'">'+label+'</label>'+(extra.input?'<input type="text"'+attrs+' value="'+esc(value)+'"'+(extra.max?' maxlength="'+extra.max+'"':'')+'>':'<textarea'+attrs+' rows="'+(extra.rows||5)+'">'+esc(value)+'</textarea>')+'<small id="'+id+'-help">'+esc(extra.help||'默认内容已填好，可直接保留；只修改当前业务需要改变的部分。')+'</small></div>';
  }
  function panel(title,description,body,no='') { return '<section class="panel"><div class="panel-heading"><div><h2>'+title+'</h2><p>'+description+'</p></div>'+(no?'<span class="section-number">'+no+'</span>':'')+'</div>'+body+'</section>'; }
  function setupPage() {
    const d=state.doc,p=plan(),isNew=!d.source_name;
    const name=field('业务名称','business-name',d.name,{input:true,max:60,attrs:'data-meta="name"',help:hints.name});
    const metadata=(isNew?'':name)+field('业务说明','description',d.description,{rows:2,attrs:'data-meta="description"',help:hints.description})+'<details class="advanced"><summary>业务别名与保存位置</summary>'+field('业务别名','aliases',d.aliases.join('\n'),{rows:2,attrs:'data-meta="aliases"',help:hints.aliases})+field('配置保存目录','config-path',d.path,{input:true,attrs:'data-meta="path"',help:hints.path})+'<p class="field-note">自动识别的Skill位置</p><div class="path-preview">'+esc(modeInfo().root)+'</div></details>'+(p.tasks.includes('object_tree')?'<details class="advanced"><summary>对象树文件（也可执行时提供）</summary>'+field('对象树文件路径','tree-path',d.tree_path,{input:true,attrs:'data-meta="tree_path"',help:hints.tree_path})+'</details>':'');
    return (isNew?'<div class="new-business-name">'+name+'</div>':'')+
      '<section class="panel ready-panel"><div class="ready-heading"><div><span class="ready-label">'+(isNew?'默认设置已填好':'当前提取设置')+'</span><h2 id="ready-business-name">'+esc(isNew?state.template.title+'模板':d.name)+'</h2><p id="ready-description">'+esc(d.description)+'</p></div><span class="mode-label">'+esc(modeInfo().title)+'</span></div><div class="selection-heading"><h3>将提取这些内容</h3><button class="text-button" data-page="scope">调整提取内容 →</button></div><ul class="selected-fields">'+p.fields.filter(k=>k!=='问题单号').map(k=>'<li>'+esc(k)+'</li>').join('')+'</ul><div class="ready-bottom"><span>规则和示例已配置；运行时检查空结果，必要时复核一次。</span><button class="text-button" data-page="rules">有特殊提取要求？调整规则 →</button></div></section>'+
      '<details class="business-details" id="business-details"><summary>'+(isNew?'补充业务说明或修改保存位置（可选）':'修改业务信息或保存位置（可选）')+'</summary><div class="panel">'+metadata+'<p class="help">修改已有业务名称会另存为新业务，原业务仍保留。</p></div></details>'+
      '<div class="usage-note"><strong>接下来怎么用？</strong><p id="usage-guidance">'+usageText()+'</p></div>';
  }
  function usageText() { return (state.dirty?'保存后，':'这份设置已可使用。')+'返回OpenCode说：“业务是'+esc(state.doc.name)+'，请提取这个目录中的问题单”。'; }
  function rulesPage() {
    const p=plan(),specs=state.template.business.prompts;
    const rows=tasks=>tasks.map(task=>{const raw=state.doc.prompts[task],index=C.exampleIndex(raw),count=index<0?0:C.parseExamples(C.splitPrompt(raw).parts[index].body).items.length;return '<button class="rule-link" data-page="task/'+task+'"><span><strong>'+esc(taskTitle(task))+'</strong><small>'+ (count?count+'个示例 · ':'')+(raw===C.bindBusinessName(state.template.prompts[task],state.template.business.name,state.doc.name)?'沿用默认设置':'已修改')+'</small></span><span aria-hidden="true">→</span></button>';}).join('');
    const automatic=Object.keys(specs).filter(task=>p.tasks.includes(task)&&specs[task].output_keys.every(k=>!state.doc.selection['提取内容'].includes(k)));
    const direct=Object.keys(specs).filter(task=>p.tasks.includes(task)&&!automatic.includes(task));
    return panel('只改与你的业务不同的地方','先选一项，再修改现成的规则或示例。没有特殊要求，可以直接使用默认设置。','<div class="rule-links">'+rows(direct)+'</div>')+'<details class="business-details"><summary>自动处理规则（一般无需修改）</summary><div class="panel rule-links">'+rows([...new Set([...automatic,'empty_recheck'])])+'</div></details>';
  }
  function scopePage() {
    const selected=state.doc.selection['提取内容'], fields=[...new Set(Object.values(state.template.business.prompts).flatMap(s=>s.output_keys))], order=['测试对象','测试点','测试动作','测试条件','预期结果','测试动作因子','测试数据因子','动作因子名称','数据因子名称','关联关系','测试对象与测试对象关系','测试动作因子之间关系','问题根因','测试对象树归属','图片类型'];
    const rows=order.filter(k=>fields.includes(k)).map(k=>'<label class="scope-row"><input type="checkbox" data-field-choice="'+k+'"'+(selected.includes(k)?' checked':'')+'><span><strong>'+k+'</strong><small>'+fieldDescription(k)+'</small></span><span class="scope-meta">'+(selected.includes(k)?'将写入结果':'按需开启')+'</span></label>').join('');
    const p=plan();
    return panel('这次要提取哪些内容？','已按所选模板勾好。取消后不执行对应任务，也不产生空列；必要内部依赖由系统处理。',rows+'<div class="scope-preview"><strong>最终JSON与Excel字段</strong><div class="column-list">'+p.fields.map(k=>'<span>'+k+'</span>').join('')+'</div><p>问题单号自动保留。'+(stepwiseExpectation()?'选择预期结果会先完成完整因子对；只导出勾选字段。': '只选因子名称时，会自动提取所需因子，但不额外导出因子列。')+'</p></div>','01')+
      (Object.entries(state.template.business.prompts).some(([task,spec])=>(spec.task_kind==='relation'||task==='relation')&&spec.output_keys.some(k=>selected.includes(k)))?panel('需要哪些关联关系？','只连接本次选择的端点类别。范围不适用的类型会自动跳过。',activeRelationTypes().map(r=>{ const chosen=state.doc.selection['关系类型']??state.template.business.relations.map(x=>x.name), usable=selected.includes(r.head)&&selected.includes(r.tail); return '<label class="check-line relation-choice"><input type="checkbox" data-relation="'+esc(r.name)+'"'+(chosen.includes(r.name)?' checked':'')+'><span><strong>'+r.name+'</strong><small>'+r.head+' → '+r.tail+(usable?'':' · 对应要素未全部选择，本次不运行')+'</small></span></label>'; }).join(''),'02'):'');
  }
  function sectionHelp(heading,task) {
    if(task==='test_point')return stepwiseExpectation()?'例如：批量核验模式下batch_key非空约束。用简洁主题保留必要条件，不展开代码、操作和全部预期。':'例如：同一条中保留接口字段取值和非空要求，不压成“接口异常”。可以包含关联检查项，但数组只能一项且非空。';
    if(task==='expectation'&&stepwiseExpectation())return '例如：步骤3：导出记录数与查询结果一致。先使用完整因子对及其数据，再逐步确定正确结果；没有明确预期的步骤省略，原步骤号不重排。';
    if(heading.includes('定义'))return '例如：说明哪些实体属于测试对象，以及应保留到页面、控件还是字段。可以直接在默认定义中增删句子。';
    if(heading.includes('判断')||heading.includes('规则'))return '例如：先识别主验证目标，再检查相关控件；补充排除项、优先级或例外。保留与本业务一致的步骤即可。';
    if(heading.includes('检查'))return '例如：输出前检查是否遗漏具体字段、是否把状态或操作误当对象。';
    if(heading.includes('关系'))return '例如：写清关系含义、方向和成立条件。类型名称与端点结构由系统保持。';
    return '例如：将任务范围调整为本业务关注的实体或检查目标，保留原有输出约定。默认正文可以直接使用。';
  }
  function rulePage(task) {
    const raw=state.doc.prompts[task], model=C.splitPrompt(raw);
    if(!model.parts.length)return panel('完整复核规则','默认复核内容已经填好，可直接增删其中的要求。',field('复核正文','whole-prompt',raw,{rows:22,attrs:'data-whole-prompt="true"',help:'例如：优先复核账号的否定约束、原始用例和数据准备；保持原任务的字段和证据门槛。'}));
    const priority=h=>h.includes('定义')?0:h.includes('判断')?1:h.includes('检查')?3:['角色','任务'].includes(h)?9:2;
    const editable=model.parts.map((p,i)=>({p,i})).filter(({p})=>!locked(p)&&!['Examples','Example'].includes(p.heading)).sort((a,b)=>priority(a.p.heading)-priority(b.p.heading));
    return editable.map(({p,i},j)=>'<details class="rule-section"'+((p.heading.includes('定义')||task==='empty_recheck'&&j===0)?' open':'')+'><summary><strong>'+esc(p.heading)+'</strong><small>'+p.body.trim().length+' 字 · 已填默认内容</small></summary><div class="rule-body">'+field('直接修改本段规则','section-'+i,p.body.trim(),{rows:Math.min(16,Math.max(4,p.body.split('\n').length)),attrs:'data-section="'+i+'"',help:sectionHelp(p.heading,task)})+'</div></details>').join('')+
      '<details class="advanced"><summary>查看自动保留的输入和输出约定</summary><p class="help">这些内容保持输入、字段和JSON结构一致，无需业务人员填写。</p>'+model.parts.filter(locked).map(p=>'<h3 class="field-label">'+esc(p.heading)+'</h3><pre class="plain-pre">'+esc(p.body.trim())+'</pre>').join('')+'</details>';
  }
  function outputEditor(task,item,index) {
    const result=item.result;
    if(!result)return '<p class="error-summary">示例输出无法解析，请恢复本项模板或修正完整输出。</p>'+field('期望输出JSON','example-json-'+index,'{}',{attrs:'data-example="'+index+'" data-result-raw="true"'});
    const keys=Object.keys(result), value=result[keys[0]], empty=Array.isArray(value)?!value.length:!value;
    let body='<h3>期望提取结果</h3>';
    if(!['object_tree','test_point'].includes(task))body+='<label class="check-line"><input type="checkbox" data-empty="'+index+'"'+(empty?' checked':'')+'>此例没有可提取内容（保留合法空结果）</label>';
    if(empty&&!['object_tree','test_point'].includes(task))return '<div class="output-box">'+body+'<p class="help">这是一个边界示例。模型应按原任务返回空数组或空字符串，不猜测补充。</p></div>';
    if(task==='factor_pair'||task==='factor_names') {
      const a=result[keys[0]], b=result[keys[1]];
      body+=a.map((v,row)=>'<div class="output-pair">'+field(keys[0]+' · '+(row+1),'ex-'+index+'-a-'+row,v,{input:true,attrs:'data-example="'+index+'" data-pair-row="'+row+'" data-pair-column="0"',help:task==='factor_pair'?'例如：在搜索框输入<*>。':'例如：输入查询文本。'})+field(keys[1]+' · '+(row+1),'ex-'+index+'-b-'+row,C.slotText(b[row]),{rows:Array.isArray(b[row])?b[row].length:1,attrs:'data-example="'+index+'" data-pair-row="'+row+'" data-pair-column="1"',help:'无参数或未知留空；多个参数每行一个，未知参数保留空行。'})+'<button class="text-button danger-button" data-remove-step="'+index+'" data-row="'+row+'" aria-label="删除第'+(row+1)+'个槽位">移除</button></div>').join('')+'<button class="text-button" data-add-step="'+index+'">＋ 增加一个槽位</button>';
    } else if(isRelationTask(task)) {
      body+=value.map((r,row)=>'<div class="relation-output"><input type="text" value="'+esc(r.头实体)+'" data-example="'+index+'" data-relation-row="'+row+'" data-relation-key="头实体" aria-label="第'+(row+1)+'条关系头实体"><select data-example="'+index+'" data-relation-row="'+row+'" data-relation-key="关系" aria-label="第'+(row+1)+'条关系类型">'+relationTypes(task).map(x=>'<option'+(x.name===r.关系?' selected':'')+'>'+x.name+'</option>').join('')+'</select><input type="text" value="'+esc(r.尾实体)+'" data-example="'+index+'" data-relation-row="'+row+'" data-relation-key="尾实体" aria-label="第'+(row+1)+'条关系尾实体"><button class="text-button danger-button" data-remove-edge="'+index+'" data-row="'+row+'" aria-label="删除第'+(row+1)+'条关系">移除</button></div>').join('')+'<button class="text-button" data-add-edge="'+index+'">＋ 增加一条关系</button><p class="help">'+(task==='object_relation'?'例如：审批页 → 对象包含对象 → 加签按钮。':task==='factor_relation'?'例如：输入查询 → 因子先于因子 → 提交查询。':'例如：审批按钮焦点框样式一致性 → 测试点验证对象 → 审批按钮。')+'端点须逐字来自该任务对应的上游数组。</p>';
    } else if(task==='test_point') {
      const legacy=value.length!==1||typeof value[0]!=='string'||!value[0].trim();
      if(legacy)body+='<p class="notice warning">此示例不符合“一单一条非空验证内容”。原值如下，请保留必要检查项，重新整理为一条后填写；不会自动取第一项或拼接多项。</p><pre class="plain-pre">'+esc(JSON.stringify(value,null,2))+'</pre>';
      body+=field('本单测试点（验证内容）','output-'+index,legacy?'':value[0],{rows:3,attrs:'data-example="'+index+'" data-output="single-point" required',help:stepwiseExpectation()?'例如：配送日报语言与总量一致性。保留必要条件，省略操作、代码和详细预期；每单一个非空主题。':'例如：检查配送日报语言及总量与台账的一致性。可换行保留本问题的关联检查项和约束，整体仍保存为一个测试点；不写完整步骤，也不能留空。'});
    }
    else if(task==='object_tree') body+=field('对象归属结果（完整结构）','tree-output-'+index,state.invalidRaw[task+'/'+index]?.value??JSON.stringify(result,null,2),{rows:15,attrs:'data-example="'+index+'" data-result-raw="true"',help:'默认示例已包含完整路径和节点结构。仅在需要调整归类边界时修改，路径形如root->页面->控件。'});
    else body+=field(keys[0],'output-'+index,Array.isArray(value)?value.join('\n'):value,{rows:Math.min(8,Math.max(2,Array.isArray(value)?value.length:3)),attrs:'data-example="'+index+'" data-output="'+(Array.isArray(value)?'list':'text')+'"',help:task==='expectation'&&stepwiseExpectation()?'每行一条：步骤N：正确结果。N必须对应示例输入因子的原步骤号；可跳号，不能重复或越界，也不能超过步骤数。':Array.isArray(value)?'每行一个结果，例如：审批按钮。不要填写步骤号或JSON符号。':'例如：后端响应组装逻辑漏赋必需字段，导致接口返回缺值。证据不足可使用空结果。'});
    return '<div class="output-box">'+body+'</div>';
  }
  function examplesPage(task) {
    const model=C.splitPrompt(state.doc.prompts[task]), part=model.parts[C.exampleIndex(state.doc.prompts[task])];
    if(!part)return '<div class="empty-message">当前任务不单独配置示例，按完整复核规则执行。</div>';
    const data=C.parseExamples(part.body);
    return '<div class="tip">默认示例可直接保留。按本业务的容易出错之处修改，使用虚构场景，避免把评测集答案放进示例。</div>'+data.items.map((item,index)=>'<details class="example-card" data-example-card="'+index+'"'+(index===0?' open':'')+'><summary><span class="example-index">'+String(index+1).padStart(2,'0')+'</span><span><strong>'+esc(item.title)+'</strong><small>'+esc(C.outputSummary(item.result))+'</small></span><span class="example-chevron" aria-hidden="true">›</span></summary><div class="example-body">'+field('示例名称','example-title-'+index,item.title,{input:true,attrs:'data-example="'+index+'" data-example-field="title"',help:'例如：整体报告保留为对象，语言和总量作为同一测试问题的检查依据。'})+field('示例输入','example-context-'+index,item.context,{rows:9,attrs:'data-example="'+index+'" data-example-field="context"',help:state.doc.mode==='text'?'例如：问题单完整正文和本任务必要的已有因子或要素。字段不固定；逐步预期/命名/关系示例保留必要上游数组。':'例如：原始问题单正文、可辨认的图片信息，以及本任务必要的已有因子或要素。逐步预期/命名/关系示例保留必要上游数组。'})+outputEditor(task,item,index)+field('为什么这样提取','example-reason-'+index,item.reason,{rows:3,attrs:'data-example="'+index+'" data-example-field="reason"',help:task==='test_point'&&stepwiseExpectation()?'例如：保留字段非空的关键条件，其余流程和断言由因子及预期承接。':task==='expectation'&&stepwiseExpectation()?'例如：只对步骤3给出有依据的联合断言，步骤1和2没有明确标准则省略。':task==='test_point'?'例如：同一响应的取值与非空要求需要共同验证，所以保留在一条中，不缩写成“响应异常”。':'例如：颜色是明确要检查的维度，应作为参数值；具体正确值留在预期结果中。'})+'<div class="example-tools"><div><button class="text-button" data-duplicate-example="'+index+'">复制为新示例</button></div><button class="text-button danger-button" data-delete-example="'+index+'">删除此示例</button></div></div></details>').join('')+'<button class="add-example" data-add-example="true">＋ 添加示例（先填入一个完整模板，直接修改）</button><p class="help">保留3–5个有代表性的示例通常便于维护；允许按需增删。因子提取与命名示例应保持各自输入输出的槽位一致。</p>';
  }
  function taskPage(task) {
    const raw=state.doc.prompts[task], index=C.exampleIndex(raw), exampleCount=index>=0?C.parseExamples(C.splitPrompt(raw).parts[index].body).items.length:0;
    const tabs=index>=0?'<div class="tabs"><button class="tab" data-tab="rules" aria-pressed="'+(state.tab==='rules')+'">定义与判断规则</button><button class="tab" data-tab="examples" aria-pressed="'+(state.tab==='examples')+'">示例 <span>'+exampleCount+'</span></button></div>':'';
    return '<button class="text-button back-to-rules" data-page="rules">← 返回全部提取规则</button>'+tabs+(state.tab==='examples'&&index>=0?examplesPage(task):rulePage(task));
  }
  function reviewPage() {
    const p=plan();
    return panel('确认这次保存的内容','保存后可直接返回OpenCode，不需要导出或移动文件。','<table class="review-table"><tbody><tr><th>业务</th><td>'+esc(state.doc.name)+' · '+esc(modeInfo().title)+'</td></tr><tr><th>基于模板</th><td>'+esc(state.template.title)+'，所有规则与示例均已填入</td></tr><tr><th>保存目录</th><td class="path-preview">'+esc(state.doc.path)+'</td></tr><tr><th>提取内容</th><td>'+p.fields.join('、')+'</td></tr><tr><th>空结果检查</th><td>运行时必经；只对符合条件的合法空结果复核一次，未完成检查不能汇总。</td></tr><tr><th>对象树</th><td>'+ (p.tasks.includes('object_tree')?(state.doc.tree_path?esc(state.doc.tree_path):'已开启，路径可在执行任务时提供'):'关闭，不读取树、不调用归类')+'</td></tr><tr><th>关系范围</th><td>'+p.relations.length+'种当前可用关系，仅连接已选择的类别</td></tr></tbody></table><div class="example-tools"><button id="check-config" class="button secondary">检查配置</button><span class="help">按实际提取计划校验路径、依赖、示例和字段。</span></div>','01')+panel('完整规则与示例','未修改的项目使用模板原文。点击可继续编辑。','<table class="review-table"><thead><tr><th>提取任务</th><th>本次任务</th><th>示例</th><th>规则</th></tr></thead><tbody>'+Object.keys(state.template.business.prompts).map(task=>{const raw=state.doc.prompts[task],i=C.exampleIndex(raw),count=i<0?0:C.parseExamples(C.splitPrompt(raw).parts[i].body).items.length;return '<tr><td><button class="text-button" data-page="task/'+task+'">'+taskTitle(task)+'</button></td><td>'+ (p.tasks.includes(task)?'启用':'暂不执行')+'</td><td>'+count+'个</td><td class="review-status">'+(raw===C.bindBusinessName(state.template.prompts[task],state.template.business.name,state.doc.name)?'沿用模板':'已调整')+'</td></tr>';}).join('')+'</tbody></table>','02');
  }
  function render(focus=false) {
    if(!state.doc)return;
    if(state.compatibility.length){
      state.page='setup';$('page-title').textContent='这份业务设置需要更新';$('page-description').textContent='旧版字段或提示词约定与当前模板不一致，暂不保存或混用。';$('breadcrumb').textContent=modeInfo().title+' · 业务设置';
      $('field-count').hidden=true;$('business-picker').hidden=!state.doc.source_name;$('back-business').hidden=true;$('template-bar').hidden=true;
      $('editor').innerHTML=panel('按新版模板整理','业务名称、说明和保存位置会保留。旧规则不会自动与新规则拼接。','<ul>'+state.compatibility.map(x=>'<li>'+esc(x)+'</li>').join('')+'</ul><p class="help">整理后先检查规则和示例，再保存。保存前不会改原文件，覆盖时会确认并备份。</p><button class="button primary" data-upgrade-template="true">按新版模板整理</button>');
      $('footer-note').textContent='原配置保留，尚未写入修改。';$('save').disabled=true;$('save').textContent='请先整理旧版设置';$('save-state').textContent='旧版设置 · 待整理';navigation();syncSelects();return;
    }
    const task=state.page.startsWith('task/')?state.page.slice(5):null;
    const titles={setup:[state.doc.source_name?'选好业务，就能使用':'新建一个业务','默认内容已填好，只调整与你的业务不同的地方。'],scope:['提取哪些内容','已按业务选好。需要增加或减少时，再修改勾选。'],rules:['调整提取规则','这是可选项，不需要逐项填写。'],review:['保存详情与检查','保存时会自动检查。这里也可以提前查看和检查。']};
    const title=task?taskTitle(task):titles[state.page][0], description=task?(task==='empty_recheck'?'运行时先执行必经的empty_check；命中合法空结果后，才用本规则再次调用提取模型。配置页面不执行提取。':'直接修改现有正文和示例。公共内容由模板复用，修改会保存为当前业务的差异，无需学习模板语法。'):titles[state.page][1];
    $('page-title').textContent=title; $('page-description').textContent=description; $('breadcrumb').textContent=task?'调整提取规则':modeInfo().title+' · 业务设置'; $('field-count').textContent=state.doc.selection['提取内容'].length+' 项提取内容';$('field-count').hidden=state.page!=='scope';
    $('business-picker').hidden=state.page!=='setup'||!state.doc.source_name;
    $('back-business').hidden=state.page!=='setup'||!!state.doc.source_name||!modeInfo().businesses.length;
    $('template-bar').hidden=!(task||!state.doc.source_name&&state.page==='setup'); $('reset-task').hidden=!task;
    const choosingTemplate=!state.doc.source_name&&state.page==='setup';$('template-picker').hidden=!choosingTemplate;$('template-summary').hidden=choosingTemplate;
    $('template-help').textContent=choosingTemplate?'选最接近的即可，规则、示例和提取内容都会一起填好。':'仅修改当前业务，其他业务不受影响。';
    $('editor').innerHTML=task?taskPage(task):state.page==='setup'?setupPage():state.page==='scope'?scopePage():state.page==='rules'?rulesPage():reviewPage();
    $('footer-note').textContent=task?'只改当前业务；没有修改的部分保留原内容。':'设置直接保存到Skill，无需下载或移动文件。';
    $('save').textContent=state.dirty?(state.doc.source_name?'保存修改':'保存并使用'):'已保存，可直接使用';$('save').disabled=state.busy||!state.dirty&&!!state.doc.source_name;
    $('save-state').textContent=state.dirty?(state.draftStored?'草稿已暂存 · 尚未生效':'尚未保存 · 尚未生效'):'已生效 · 可直接用于提取'; $('save-state').classList.toggle('dirty',state.dirty);
    navigation(); syncSelects(); document.title=title+' · '+state.doc.name+' · 业务配置';
    if(focus) { $('main').focus({preventScroll:true}); window.scrollTo({top:0}); }
  }
  let confirmationQueue=Promise.resolve();
  function confirmAction(title,body,accept='确认',cancel='继续编辑') {
    const result=confirmationQueue.then(()=>new Promise(resolve=>{
      $('confirm-title').textContent=title; $('confirm-body').innerHTML=body; $('confirm-accept').textContent=accept; $('confirm-cancel').textContent=cancel;
      const dialog=$('confirm-dialog');dialog.returnValue='';
      dialog.addEventListener('close',()=>resolve(dialog.returnValue==='accept'),{once:true});dialog.showModal();
    }));
    confirmationQueue=result.then(()=>undefined,()=>undefined);return result;
  }
  async function guard() {
    if(!state.modified)return true;
    const accepted=await confirmAction('先保存当前修改？','<p>“'+esc(state.doc.name)+'”还有尚未生效的修改。先保存成功后再切换，避免误丢规则和示例。</p>','先保存并切换');
    return accepted?await saveDocument():false;
  }
  async function loadTemplate(mode,key) { return api('/api/template?mode='+mode+'&key='+key); }
  async function loadDocument(mode,name) {
    const doc=await api('/api/document?mode='+mode+'&name='+encodeURIComponent(name));
    const template=await loadTemplate(mode,doc.template); state.doc=doc; state.template=template;state.compatibility=C.compatibilityIssues(doc,template);state.dirty=false;state.modified=false;state.invalidRaw={};state.pathManual=false;state.aliasesManual=false;state.sourcePath=doc.path;state.sourceAliases=C.clone(doc.aliases);state.page='setup';state.tab='rules';clearErrors();notice('');render();
  }
  async function newBusiness(mode=state.doc.mode,key='default') {
    const template=await loadTemplate(mode,key), names=state.boot.modes.find(m=>m.id===mode).businesses.map(x=>x.name), base=key==='default'?'新业务':template.title+'新业务';let name=base,n=2;while(names.includes(name))name=base+n++;
    state.template=template; state.doc=C.fromTemplate(template,mode,name);state.compatibility=[];state.dirty=true;state.modified=false;state.invalidRaw={};state.pathManual=false;state.aliasesManual=false;state.sourcePath=state.doc.path;state.sourceAliases=C.clone(state.doc.aliases);state.page='setup';state.tab='rules';clearErrors();notice('');draft();render(true);
  }
  async function saveDocument() {
    if(state.busy)return false;
    if(state.compatibility.length){error('请先按新版模板整理此业务，再检查和保存。');return false;}
    const invalid=Object.values(state.invalidRaw)[0];
    if(invalid){error('示例输出JSON尚未填写完整，请先修正再保存。',null,invalid.task);return false;}
    clearErrors();setBusy(true);
    const document=C.clone(state.doc);
    try {
      let response, payload={document};
      for(let attempt=0;attempt<3;attempt++) {
        try {response=await api('/api/save',payload);break;}
        catch(e) {
          if(!['OVERWRITE_REQUIRED','TARGET_CHANGED'].includes(e.data?.code))throw e;
          setBusy(false);
          const accepted=await confirmAction(e.data.code==='TARGET_CHANGED'?'目标配置刚刚发生变化':'覆盖已有业务配置？','<p>将更新：</p><ul>'+e.data.conflicts.map(v=>'<li>'+esc(v)+'</li>').join('')+'</ul><p>原配置会自动备份，其他业务保持不变。</p>','覆盖并保存','取消保存');
          if(!accepted)return false;
          setBusy(true);payload={document,overwrite:true,confirmation_revision:e.data.confirmation_revision};
        }
      }
      if(!response)throw Error('该业务正在被其他页面连续修改，请稍后保存。');
      state.doc=response.document;state.dirty=false;state.modified=false;
      state.sourcePath=state.doc.path;state.sourceAliases=C.clone(state.doc.aliases);state.aliasesManual=false;state.pathManual=false;
      // The save has committed. A later read failure must not report it as unsaved.
      const entries=modeInfo().businesses,entry=entries.find(b=>b.name===state.doc.name);
      if(entry)entry.path=state.doc.path;else entries.push({name:state.doc.name,path:state.doc.path});
      if(!state.legacyDraft)try{localStorage.removeItem(storageKey());}catch{}
      let listRefreshFailed=false;try{state.boot=await api('/api/bootstrap');}catch{listRefreshFailed=true;}
      render();
      notice('已保存并生效。返回OpenCode，指定“'+state.doc.name+'”即可使用。原配置已自动备份。'+(listRefreshFailed?'业务列表暂时无法刷新，当前保存不受影响。':''));
      return true;
    } catch(e) {setBusy(false);error(e.message,e.data?.field,e.data?.task);return false;}
    finally {setBusy(false);}
  }
  function updateExample(index,mutate) {
    const task=state.page.slice(5);state.doc.prompts[task]=C.editExample(state.doc.prompts[task],index,(data,i)=>{const item=data.items[i];mutate(item,data,i);if(item)item.changed=true;});markChanged();
  }
  $('editor').addEventListener('input',event=>{
    const el=event.target;if(state.busy)return;
    if(el.dataset.meta) {
      const key=el.dataset.meta, value=el.value;
      if(key==='name') {state.doc.prompts=Object.fromEntries(Object.entries(state.doc.prompts).map(([task,raw])=>[task,C.bindBusinessName(raw,state.doc.prompt_base_business||state.doc.name,value)]));state.doc.prompt_base_business=value;state.doc.name=value;if(!state.pathManual)state.doc.path=state.doc.source_name===value?state.sourcePath:'businesses/'+value; if(!state.aliasesManual)state.doc.aliases=state.doc.source_name===value?C.clone(state.sourceAliases):[value];const path=$('config-path');if(path)path.value=state.doc.path;const aliases=$('aliases');if(aliases)aliases.value=state.doc.aliases.join('\n');}
      else if(key==='aliases'){state.aliasesManual=true;state.doc.aliases=value.split(/\r?\n/).map(v=>v.trim()).filter(Boolean);}
      else {state.doc[key]=value;if(key==='path')state.pathManual=true;}
      markChanged();syncContext();if($('usage-guidance'))$('usage-guidance').innerHTML=usageText();if($('ready-business-name')&&state.doc.source_name)$('ready-business-name').textContent=state.doc.name;if($('ready-description'))$('ready-description').textContent=state.doc.description;if(!state.doc.source_name)$('business').selectedOptions[0].textContent=state.doc.name+'（新建，尚未保存）';return;
    }
    const task=state.page.slice(5);
    if(el.dataset.wholePrompt) {state.doc.prompts[task]=el.value;markChanged();return;}
    if(el.dataset.section!==undefined) {state.doc.prompts[task]=C.replaceSection(state.doc.prompts[task],Number(el.dataset.section),el.value);markChanged();return;}
    if(el.dataset.example===undefined)return;
    const index=Number(el.dataset.example);
    if(el.dataset.resultRaw) {try {const parsed=JSON.parse(el.value);delete state.invalidRaw[task+'/'+index];updateExample(index,item=>item.result=parsed);el.removeAttribute('aria-invalid');} catch {el.setAttribute('aria-invalid','true');state.invalidRaw[task+'/'+index]={task,value:el.value};markChanged();}return;}
    updateExample(index,item=>{
      if(el.dataset.exampleField)item[el.dataset.exampleField]=el.value;
      else if(el.dataset.output) {const key=Object.keys(item.result)[0];item.result[key]=el.dataset.output==='single-point'?[el.value]:el.dataset.output==='list'?el.value.split(/\r?\n/).filter(v=>v.trim()):el.value;}
      else if(el.dataset.pairRow!==undefined) {const keys=Object.keys(item.result),row=Number(el.dataset.pairRow),column=Number(el.dataset.pairColumn);if(column===0)item.result[keys[0]][row]=el.value;else {const old=item.result[keys[1]][row],n=task==='factor_pair'?(item.result[keys[0]][row].match(/<\*>/g)||[]).length:Math.max(Array.isArray(old)?old.length:1,el.value.split('\n').length);item.result[keys[1]][row]=n===0?null:C.slotValue(el.value,n);}}
      else if(el.dataset.relationRow!==undefined)item.result[Object.keys(item.result)[0]][Number(el.dataset.relationRow)][el.dataset.relationKey]=el.value;
    });
  });
  $('editor').addEventListener('change',event=>{
    const el=event.target;
    if(el.dataset.fieldChoice) {const key=el.dataset.fieldChoice, fields=state.doc.selection['提取内容'];state.doc.selection['提取内容']=el.checked?[...fields,key]:fields.filter(k=>k!==key);markChanged();render();document.querySelector('[data-field-choice="'+key+'"]').focus({preventScroll:true});}
    if(el.dataset.relation) {const visible=[...$('editor').querySelectorAll('[data-relation]')],names=visible.map(e=>e.dataset.relation),previous=state.doc.selection['关系类型']??state.template.business.relations.map(r=>r.name);state.doc.selection['关系类型']=[...previous.filter(k=>!names.includes(k)),...visible.filter(e=>e.checked).map(e=>e.dataset.relation)];markChanged();render();}
    if(el.dataset.empty!==undefined) {
      const index=Number(el.dataset.empty),task=state.page.slice(5);
      updateExample(index,item=>{const keys=Object.keys(item.result);if(el.checked)keys.forEach(k=>item.result[k]=task==='root_cause'?'':[]);else {const m=C.splitPrompt(state.template.prompts[task]),p=m.parts[C.exampleIndex(state.template.prompts[task])],fallback=C.parseExamples(p.body).items.find(e=>Array.isArray(Object.values(e.result)[0])?Object.values(e.result)[0].length:Object.values(e.result)[0]);item.result=C.clone(fallback?.result||Object.fromEntries(keys.map(k=>[k,['验证目标']])));}});render();document.querySelector('[data-example-card="'+index+'"]').open=true;
    }
  });
  $('editor').addEventListener('click',async event=>{
    const b=event.target.closest('button');if(!b)return;
    if(b.dataset.upgradeTemplate){
      if(!await confirmAction('使用新版默认规则整理？','<p>将替换此业务的提取范围、规则和示例，保留业务信息。原配置会在覆盖保存时备份；现在只生成待检查的草稿。</p>','整理为新版','保留旧设置'))return;
      state.doc.prompts=Object.fromEntries(Object.entries(state.template.prompts).map(([task,raw])=>[task,C.bindBusinessName(raw,state.template.business.name,state.doc.name)]));state.doc.prompt_base_business=state.doc.name;state.doc.selection=C.clone(state.template.selection);state.compatibility=[];state.page='setup';state.tab='rules';state.invalidRaw={};markChanged();render();notice('已整理为新版草稿。请检查规则和示例，再保存生效。',true);return;
    }
    const task=state.page.slice(5);
    if(b.dataset.tab) {state.tab=b.dataset.tab;render();}
    if(b.dataset.deleteExample!==undefined) {
      const index=Number(b.dataset.deleteExample);if(!await confirmAction('删除这个示例？','<p>只删除当前业务中的这一例，其他规则与示例保留。</p>','删除示例','保留'))return;
      state.doc.prompts[task]=C.editExample(state.doc.prompts[task],index,(data,i)=>data.items.splice(i,1));
      const kept={};for(const [key,value]of Object.entries(state.invalidRaw)){if(!key.startsWith(task+'/'))kept[key]=value;else {const i=Number(key.slice(task.length+1));if(i!==index)kept[task+'/'+(i>index?i-1:i)]=value;}}state.invalidRaw=kept;
      markChanged();render();
    }
    if(b.dataset.addExample||b.dataset.duplicateExample!==undefined) {
      const index=Number(b.dataset.duplicateExample||0);
      state.doc.prompts[task]=C.editExample(state.doc.prompts[task],index,(data,i)=>{let source=data.items[i];if(!source){const m=C.splitPrompt(state.template.prompts[task]);source=C.parseExamples(m.parts[C.exampleIndex(state.template.prompts[task])].body).items[0];}const example=C.clone(source);example.title='新增示例：'+source.title;example.changed=true;data.items.push(example);});markChanged();render();const cards=[...document.querySelectorAll('.example-card')];cards.forEach(e=>e.open=false);cards.at(-1).open=true;cards.at(-1).scrollIntoView({block:'start'});
    }
    if(b.dataset.removeStep!==undefined||b.dataset.addStep!==undefined||b.dataset.removeEdge!==undefined||b.dataset.addEdge!==undefined) {
      const index=Number(b.dataset.removeStep??b.dataset.addStep??b.dataset.removeEdge??b.dataset.addEdge);
      updateExample(index,item=>{
        const keys=Object.keys(item.result);
        if(b.dataset.removeStep!==undefined)keys.forEach(k=>item.result[k].splice(Number(b.dataset.row),1));
        if(b.dataset.addStep!==undefined){item.result[keys[0]].push(task==='factor_pair'?'执行验证':'验证操作');item.result[keys[1]].push(null);}
        if(b.dataset.removeEdge!==undefined)item.result[keys[0]].splice(Number(b.dataset.row),1);
        if(b.dataset.addEdge!==undefined)item.result[keys[0]].push(C.clone(item.result[keys[0]][0]||{头实体:'已有头实体',关系:relationTypes(task)[0].name,尾实体:'已有尾实体'}));
      });render();document.querySelector('[data-example-card="'+index+'"]').open=true;
    }
    if(b.id==='check-config') {clearErrors();setBusy(true);try {const result=await api('/api/check',{document:state.doc});notice('检查通过：'+result.fields.length+'个输出字段，'+result.relations.length+'种有效关系。'+(result.warnings.join(' ')||'可以保存并生效。'));}catch(e){setBusy(false);error(e.message,e.data?.field,e.data?.task);}finally{setBusy(false);}}
  });
  document.addEventListener('click',event=>{const b=event.target.closest('[data-page]');if(b&&!state.busy){state.page=b.dataset.page;state.tab='rules';clearErrors();render(true);}});
  $('save').addEventListener('click',()=>saveDocument());
  async function startNewBusiness(){try{if(await guard()){state.returnBusiness=state.doc.source_name;setBusy(true);await newBusiness();}}catch(e){error(e.message);}finally{setBusy(false);}}
  $('home-new-business').addEventListener('click',startNewBusiness);
  $('back-business').addEventListener('click',async()=>{try{if(await guard()){const name=modeInfo().businesses.find(b=>b.name===state.returnBusiness)?.name||modeInfo().businesses[0]?.name;if(name){setBusy(true);await loadDocument(state.doc.mode,name);}}}catch(e){error(e.message);}finally{setBusy(false);}});
  $('business').addEventListener('change',async event=>{const name=event.target.value;syncSelects();if(name==='__new__'||name===state.doc.source_name)return;try{if(await guard()) {setBusy(true);await loadDocument(state.doc.mode,name);}}catch(e){error(e.message);}finally{setBusy(false);}});
  $('mode').addEventListener('change',async event=>{const mode=event.target.value;syncSelects();try{if(await guard()){setBusy(true);const first=state.boot.modes.find(m=>m.id===mode).businesses[0];if(first)await loadDocument(mode,first.name);else await newBusiness(mode);}}catch(e){error(e.message);}finally{setBusy(false);}});
  $('template').addEventListener('change',async event=>{
    const key=event.target.value;$('template').value=state.doc.template;
    try {
      if(state.doc.source_name||key===state.doc.template||!await guard())return;
      setBusy(true);
      await newBusiness(state.doc.mode,key);
    } catch(e){error(e.message);}finally{setBusy(false);}
  });
  $('reset-task').addEventListener('click',async()=>{if(!await confirmAction('恢复本项模板？','<p>仅替换当前任务的规则和示例。其他提取项保持不变。</p>','恢复本项'))return;const task=state.page.slice(5);state.doc.prompts[task]=C.bindBusinessName(state.template.prompts[task],state.template.business.name,state.doc.name);for(const key of Object.keys(state.invalidRaw))if(key.startsWith(task+'/'))delete state.invalidRaw[key];markChanged();render();});
  function previewContent() { $('preview-content').textContent=state.doc.prompts[$('preview-task').value]; }
  $('preview').addEventListener('click',()=>{const task=state.page.startsWith('task/')?state.page.slice(5):'object';$('preview-task').innerHTML=Object.keys(state.doc.prompts).map(t=>'<option value="'+t+'">'+taskTitle(t)+'</option>').join('');$('preview-task').value=task;previewContent();$('preview-dialog').showModal();});
  $('preview-task').addEventListener('change',previewContent);$('close-preview').addEventListener('click',()=>$('preview-dialog').close());
  window.addEventListener('beforeunload',event=>{if(state.modified){event.preventDefault();event.returnValue='';}});
  async function init() {
    try {
      if(location.protocol==='file:')throw Error('请双击Skill目录里的“打开业务配置.vbs”。它会自动打开本机工作台，保存时直接写入Skill；直接双击HTML只能浏览，不能写入文件。');
      state.boot=await api('/api/bootstrap');if(!state.boot.build_id||state.boot.service_current!==true)throw Error('保存服务版本与当前页面不一致，请重新打开Skill中的业务配置入口，不要继续使用此旧页面。');const requested=new URLSearchParams(location.search).get('mode'),mode=state.boot.modes.find(m=>m.id===requested)||state.boot.modes[0],first=mode.businesses[0];if(first)await loadDocument(mode.id,first.name);else {state.doc={mode:mode.id};await newBusiness(mode.id);}
      setBusy(false);
      let stored=null;try{stored=JSON.parse(localStorage.getItem(storageKey()));}catch{}
      if(stored?.doc&&stored.modified){
        const template=await loadTemplate(mode.id,stored.doc.template),issues=C.compatibilityIssues(stored.doc,template);let latest=null;
        if(stored.doc.source_name){try{latest=await api('/api/document?mode='+mode.id+'&name='+encodeURIComponent(stored.doc.source_name));}catch{issues.push('草稿对应的已保存业务无法读取。');}}
        if(latest&&stored.doc.revision!==latest.revision)issues.push('草稿对应的已保存配置已经更新。');
        if(issues.length){const kept=preserveLegacyDraft(stored);if(latest)await loadDocument(mode.id,latest.source_name);notice(kept?'旧草稿与当前设置不一致，已保留副本，未自动恢复旧字段。当前显示已保存设置。':'旧草稿与当前设置不一致，仍保留原草稿；本机空间不足，新的修改将无法暂存。当前显示已保存设置。',true);return;}
        const restore=await confirmAction('发现尚未生效的草稿','<p>上次对“'+esc(stored.doc.name)+'”的修改还在本机。是否恢复并继续编辑？</p>','恢复草稿','使用已生效配置');
        if(restore){state.doc=stored.doc;state.template=template;state.compatibility=[];const page=stored.page||'setup';state.page=['setup','scope','rules','review'].includes(page)||page.startsWith('task/')&&state.doc.prompts[page.slice(5)]?page:'setup';state.invalidRaw=stored.invalidRaw||{};state.sourcePath=stored.sourcePath||state.doc.path;state.sourceAliases=stored.sourceAliases||C.clone(state.doc.aliases);state.pathManual=!!stored.pathManual;state.aliasesManual=!!stored.aliasesManual;state.draftStored=true;state.dirty=true;state.modified=true;render();notice('已恢复本机草稿，修改尚未生效，请检查后保存。',true);}
      }
    } catch(e){const connected=!!state.boot;$('page-title').textContent=connected?'无法读取业务设置':'打开本机配置工作台';$('page-description').textContent=connected?'请检查提示中的业务文件或重新载入页面。':'为直接保存到Skill，请通过双击入口启动。';$('editor').innerHTML='<div class="panel"><h2>'+(connected?'保存服务已连接，业务设置读取失败':'还没有连接保存服务')+'</h2><p>'+esc(e.message)+'</p><p class="help">页面不会下载ZIP，也不会要求手动复制配置。</p></div>';$('save-state').textContent=connected?'设置读取失败':'尚未连接';}
  }
  init();
})();
