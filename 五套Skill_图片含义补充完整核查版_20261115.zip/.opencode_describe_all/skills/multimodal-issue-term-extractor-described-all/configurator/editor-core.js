(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.PromptEditor = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const clone = value => JSON.parse(JSON.stringify(value));
  function bindBusinessName(raw, from, to) {
    return raw.replace(/(^### 角色\n)([\s\S]*?)(?=^### |$(?![\s\S]))/m,(_all,head,body)=>head+body.split('熟悉'+from+'业务').join('熟悉'+to+'业务'));
  }
  function outsideLines(raw) {
    const lines=[];let fence=null,offset=0;
    for(const line of raw.split(/(?<=\n)/)){
      const boundary=line.match(/^\s*(`{3,}|~{3,})([^\r\n]*)/);
      if(boundary){
        if(!fence)fence={char:boundary[1][0],length:boundary[1].length};
        else if(fence.char===boundary[1][0]&&boundary[1].length>=fence.length&&!boundary[2].trim())fence=null;
      }else if(!fence)lines.push({line,start:offset,end:offset+line.length});
      offset+=line.length;
    }
    return lines;
  }
  function unwrapFence(text,language) {
    const opening=text.match(new RegExp('^(`{3,}|~{3,})'+language+'[ \\t]*\\r?\\n'));
    if(!opening)return text;
    const closing=new RegExp('\\n'+opening[1]+'[ \\t]*$');
    return closing.test(text)?text.slice(opening[0].length).replace(closing,'').trim():text;
  }
  function splitPrompt(raw) {
    const matches = outsideLines(raw).flatMap(({line,start,end})=>{const m=line.match(/^### ([^\n]+)\n$/);return m?[{heading:m[1].trim(),start,end}]:[];});
    return {preamble:matches.length?raw.slice(0,matches[0].start):raw, parts:matches.map((m,i) => ({heading:m.heading,body:raw.slice(m.end,matches[i+1]?.start ?? raw.length)}))};
  }
  function joinPrompt(model) { return model.preamble + model.parts.map(p => '### ' + p.heading + '\n' + p.body).join(''); }
  function replaceSection(raw, index, value) {
    const model = splitPrompt(raw);let body=value.trim();
    for(const {line,start} of outsideLines(body).reverse())if(line.startsWith('### '))body=body.slice(0,start)+'#'+body.slice(start);
    model.parts[index].body = '\n' + body + '\n\n'; return joinPrompt(model);
  }
  function isLocked(heading) { return heading.includes('输入') || heading.includes('输出格式') || heading === '执行边界'; }
  function compatibilityIssues(doc, template) {
    const issues=[], expected=Object.keys(template.prompts).sort(), actual=Object.keys(doc.prompts??{}).sort();
    if(JSON.stringify(expected)!==JSON.stringify(actual))issues.push('提取任务已更新，旧版任务目录不能直接保存。');
    const fields=new Set(Object.values(template.business.prompts).flatMap(s=>s.output_keys));
    if(!Array.isArray(doc.selection?.['提取内容'])||doc.selection['提取内容'].some(k=>k!=='问题单号'&&!fields.has(k)))issues.push('旧设置包含当前模板未提供的输出字段。');
    const names=new Set(template.business.relations.map(r=>r.name)), chosen=doc.selection?.['关系类型'];
    if(chosen!==undefined&&(!Array.isArray(chosen)||chosen.some(k=>!names.has(k))))issues.push('关系范围已更新，需要按新版类型重新选择。');
    for(const task of expected) {
      if(typeof doc.prompts?.[task]!=='string')continue;
      const before=splitPrompt(template.prompts[task]).parts, after=splitPrompt(doc.prompts[task]).parts;
      if(JSON.stringify(before.map(p=>p.heading))!==JSON.stringify(after.map(p=>p.heading))||before.some((p,i)=>isLocked(p.heading)&&p.body.trim()!==after[i]?.body.trim())) {
        issues.push('部分提示词的输入、输出或章节约定已更新。');break;
      }
    }
    return [...new Set(issues)];
  }
  function exampleIndex(raw) { return splitPrompt(raw).parts.findIndex(p => ['Examples','Example'].includes(p.heading)); }
  function parseExamples(body) {
    const heads = outsideLines(body).flatMap(({line,start,end})=>{const m=line.match(/^#### Example\s+\d+[：:][ \t]*([^\n]*)\n$/);return m?[{title:m[1],start,end}]:[];});
    const intro = heads.length ? body.slice(0,heads[0].start) : body;
    const items = heads.map((h,i) => {
      const content = body.slice(h.end,heads[i+1]?.start ?? body.length), at = outsideLines(content).filter(({line})=>/^输出：[ \t]*(?:\r?\n|$)/.test(line)).at(-1)?.start ?? -1;
      let before = at < 0 ? content : content.slice(0,at), result = null;
      if (at >= 0) { try { result = JSON.parse(content.slice(at+3).trim().replace(/^```(?:json)?\s*|\s*```$/g,'')); } catch {} }
      const reasonAt = before.lastIndexOf('判断要点：');
      const reason = reasonAt >= 0 ? before.slice(reasonAt+5).trim() : '依据当前任务定义和本单原始证据判断，不补造缺失信息。';
      before = reasonAt >= 0 ? before.slice(0,reasonAt) : before;
      let context = before.trim().replace(/^问题单文本：\s*/, '');
      context=unwrapFence(context,'markdown');
      return {title:h.title.trim(),context,reason,result,original:content,changed:false};
    });
    return {intro,items};
  }
  function renderExamples(model) {
    return model.intro + model.items.map((e,i) => {
      const fence='`'.repeat(Math.max(3,...[...e.context.matchAll(/`{3,}/g)].map(m=>m[0].length+1)));
      const context = /^### |^#### Example\s/m.test(e.context) ? fence+'markdown\n'+e.context+'\n'+fence : e.context;
      const content = e.changed ? '\n问题单文本：\n\n' + context.trim() + '\n\n判断要点：' + e.reason.trim() + '\n\n输出：\n\n' + JSON.stringify(e.result,null,2) + '\n\n' : e.original;
      return '#### Example ' + (i+1) + '：' + e.title + '\n' + content;
    }).join('');
  }
  function editExample(raw,index,mutate) {
    const model = splitPrompt(raw), partIndex = exampleIndex(raw), section = model.parts[partIndex];
    if (!section) throw Error('当前任务没有可编辑示例区。');
    const data = parseExamples(section.body); mutate(data,index); section.body = renderExamples(data); return joinPrompt(model);
  }
  function plan(doc, business) {
    const fields = doc.selection['提取内容'], chosen = doc.selection['关系类型'] ?? business.relations.map(r=>r.name);
    const relationsByTask = Object.fromEntries(Object.entries(business.prompts).filter(([task,s])=>(s.task_kind==='relation'||task==='relation')&&s.output_keys.some(k=>fields.includes(k))).map(([task,s])=>[task,business.relations.filter(r=>(s.relation_types??business.relations.map(r=>r.name)).includes(r.name)&&chosen.includes(r.name)&&fields.includes(r.head)&&fields.includes(r.tail))]));
    const relations = business.relations.filter(r=>Object.values(relationsByTask).some(values=>values.includes(r)));
    const owners = Object.fromEntries(Object.entries(business.prompts).flatMap(([task,s])=>s.output_keys.map(k=>[k,task]))), tasks = new Set();
    function add(task) { if (!task || tasks.has(task)) return; tasks.add(task); const spec=business.prompts[task], deps = spec.task_kind==='relation'||task==='relation' ? (relationsByTask[task]??[]).flatMap(r=>[r.head,r.tail]) : spec.dependencies; deps.forEach(k=>add(owners[k])); }
    fields.forEach(k=>add(owners[k]));
    return {fields:['问题单号',...fields.filter(f=>f!=='问题单号')],tasks:[...tasks],relations,relationsByTask,internal:[...new Set([...tasks].flatMap(t=>business.prompts[t].output_keys).filter(k=>!fields.includes(k)))]};
  }
  function fromTemplate(template, mode, name='新业务') {
    const descriptions={terminal:'面向终端软工问题单，重点提取核心测试对象、业务操作和直接验证目标。',gts:'面向GTS问题单，提取对象、简洁测试点、完整因子与逐步预期；对象间关系和因子间关系分别提取。',default:'面向常规软件问题单，提取测试对象、动作、条件、因子和关联关系。'};
    return {mode,name,description:descriptions[template.key],aliases:[name],path:'businesses/'+name,tree_path:'',template:template.key,selection:clone(template.selection),prompts:Object.fromEntries(Object.entries(template.prompts).map(([task,raw])=>[task,bindBusinessName(raw,template.business.name,name)])),prompt_base_business:name,source_name:null,revision:null};
  }
  function outputSummary(result) {
    if (!result) return '请检查期望输出';
    const value = Object.values(result)[0];
    if (Array.isArray(value)) return value.length ? (typeof value[0] === 'string' ? value[0] : value.length + '项结果') : '不提取内容（空结果）';
    return value || '证据不足，保留空结果';
  }
  function slotText(value) { return Array.isArray(value) ? value.map(v=>v??'').join('\n') : value??''; }
  function slotValue(text, n=1) { if(n>1) return text.split('\n').map(v=>v.trim()?v:null); return text.trim()?text:null; }
  return {clone,bindBusinessName,splitPrompt,joinPrompt,replaceSection,isLocked,compatibilityIssues,exampleIndex,parseExamples,renderExamples,editExample,plan,fromTemplate,outputSummary,slotText,slotValue};
});
