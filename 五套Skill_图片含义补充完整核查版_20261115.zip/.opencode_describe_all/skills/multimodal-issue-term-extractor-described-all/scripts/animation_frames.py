"""Decode GIF evidence into ordered frames. Pillow is required only for GIF inputs."""
from pathlib import Path
import hashlib


def prepare_animations(images, folder, max_frames=24):
    if max_frames < 2:
        raise ValueError("GIF抽帧数量至少为2")
    records = []
    for index, raw in enumerate(images):
        source = Path(raw)
        with source.open('rb') as stream:
            header = stream.read(6)
        if header not in (b'GIF87a', b'GIF89a') and source.suffix.lower() != '.gif':
            continue
        try:
            from PIL import Image
        except ImportError as error:
            raise ValueError('GIF_DECODER_UNAVAILABLE：处理GIF需要当前Python安装Pillow，不能仅看首帧') from error
        fingerprint = hashlib.sha256(source.read_bytes()).hexdigest()
        target = Path(folder) / ('gif_' + str(index) + '_' + fingerprint[:16])
        target.mkdir(parents=True, exist_ok=True)
        try:
            with Image.open(source) as gif:
                if gif.format != 'GIF':
                    raise ValueError('文件扩展名为GIF但实际格式不符')
                total = getattr(gif, 'n_frames', 1)
                chosen = sorted({round(i * (total - 1) / (max_frames - 1)) for i in range(max_frames)}) if total > max_frames else list(range(total))
                frames, timestamp = [], 0
                for frame_index in range(total):
                    gif.seek(frame_index)
                    duration = gif.info.get('duration', 0)
                    duration = duration if isinstance(duration, (int, float)) and duration >= 0 else 0
                    if frame_index in chosen:
                        path = target / ('frame_' + str(frame_index).zfill(6) + '.png')
                        # Pillow seek composites disposal/partial updates before RGB export.
                        gif.convert('RGB').save(path)
                        frames.append({'frame_index': frame_index, 'timestamp_ms': timestamp,
                                       'duration_ms': duration, 'path': str(path.resolve())})
                    timestamp += duration
                records.append({'image_index': index, 'source_path': str(source.resolve()),
                                'source_sha256': fingerprint, 'frame_count': total,
                                'duration_ms': timestamp, 'sampled': len(chosen) < total, 'frames': frames})
        except (OSError, EOFError) as error:
            raise ValueError('GIF_READ_FAILED：' + str(source)) from error
    return records


if __name__ == '__main__':
    import argparse, json
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--gif', required=True)
    parser.add_argument('--output-dir', required=True)
    parser.add_argument('--max-frames', type=int, default=24)
    args = parser.parse_args()
    print(json.dumps(prepare_animations([args.gif], Path(args.output_dir).resolve(), args.max_frames), ensure_ascii=False))
