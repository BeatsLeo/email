"""Validate actual model outputs before downstream use. Python standard library only."""
import argparse
import json
import re
import sys
from pathlib import Path


class ResultError(ValueError):
    pass


def require(ok, message):
    if not ok:
        raise ResultError(message)


def text(value):
    return isinstance(value, str) and bool(value.strip())


def pair(value):
    require(isinstance(value, dict), "上游因子必须为JSON对象")
    actions, data = value.get("测试动作因子"), value.get("测试数据因子")
    require(isinstance(actions, list) and isinstance(data, list) and len(actions) == len(data), "因子外层数组必须等长")
    for i, (action, slot) in enumerate(zip(actions, data)):
        require(text(action), f"动作槽{i}须为非空文本")
        n = action.count("<*>")
        if n == 0:
            require(slot is None, f"数据槽{i}无参数，必须为null")
        elif n == 1:
            require(slot is None or text(slot), f"数据槽{i}须为字符串/null")
        else:
            require(isinstance(slot, list) and len(slot) == n and all(v is None or text(v) for v in slot), f"数据槽{i}须为长度{n}的参数子数组，未知参数保留null")
    return actions, data


def step_expectations(values, factors):
    """Keep sparse per-step expectations explicitly bound to their source factor."""
    actions, _data = pair(factors or {})
    require(isinstance(values, list) and len(values) <= len(actions), "预期结果条数不能超过动作因子条数")
    previous = 0
    for value in values:
        require(text(value), "每条预期须为非空文本")
        match = re.fullmatch(r"步骤([1-9]\d*)：\s*(\S[\s\S]*)", value)
        require(match is not None, "逐步预期须使用‘步骤N：明确的正确结果’格式")
        index = int(match[1])
        require(previous < index <= len(actions), "预期步骤号须递增、不重复，且不能超出动作因子范围")
        previous = index
    return values


def tree_nodes(raw):
    nodes, stack, ids = {}, [], set()
    for line in raw.splitlines():
        match = re.match(r"^([ \t]*)[-*+]\s+(.+?)\s+\[(category|object)\]\s+(\S+)\s*$", line)
        if not match:
            continue
        indent, name, kind, identity = len(match[1].expandtabs(4)), match[2].strip().strip("*"), match[3], match[4]
        while stack and stack[-1][0] >= indent:
            stack.pop()
        path = (stack[-1][1] if stack else "root") + "->" + name
        require(path not in nodes and identity not in ids and "->" not in name, "对象树路径或ID重复/节点名含分隔符")
        nodes[path] = (kind, identity)
        ids.add(identity)
        stack.append((indent, path))
    require(bool(nodes), "对象树没有有效节点")
    return nodes


def validate_result(task, spec, result, context=None):
    context = context or {}
    keys = spec["output_keys"]
    require(isinstance(result, dict) and set(result) == set(keys), "结果必须恰好包含指定字段；错误对象、顶层null或额外字段不合法")
    if task == "root_cause":
        require(isinstance(result[keys[0]], str), "根因须为字符串")
        return result
    require(all(isinstance(result[k], list) for k in keys), "结果字段须为数组")
    if task == "test_point":
        require(len(result[keys[0]]) == 1 and text(result[keys[0]][0]), "测试点必须且只能有一个非空测试点描述")
    elif task == "expectation" and spec.get("expectation_alignment") == "factor_steps":
        step_expectations(result[keys[0]], context.get("extracted_test_factors"))
    elif task == "factor_pair":
        pair(result)
    elif task == "factor_names":
        actions, data = pair(context.get("extracted_test_factors"))
        a, b = result["动作因子名称"], result["数据因子名称"]
        require(len(a) == len(b) == len(actions), "名称与上游因子必须等长")
        for i, (action, values, aname, names) in enumerate(zip(actions, data, a, b)):
            require(text(aname) and "<*>" not in aname, f"动作名称{i}须为无占位符的非空文本")
            n = action.count("<*>")
            if n == 0:
                require(names is None, f"无参数槽{i}的数据名称必须为null")
                continue
            if n == 1:
                values, names = [values], [names]
            require(isinstance(names, list) and len(names) == n, f"名称槽{i}的参数数量不符")
            for v, name in zip(values, names):
                require(name is None or text(name) and "<*>" not in name, f"数据名称槽{i}格式错误")
                require(v is None or name is not None, f"已知数据槽{i}缺少名称")
    elif task == "relation" or spec.get("task_kind") == "relation":
        nodes = dict(context.get("extracted_factors", {}))
        factors = context.get("extracted_test_factors")
        if factors is not None:
            pair(factors)
            nodes.update(factors)
        allowed = {r["name"]: r for r in spec.get("allowed_relations", [])}
        if "测试点" in nodes or any("测试点" in (r["head"], r["tail"]) for r in allowed.values()):
            require(isinstance(nodes.get("测试点"), list) and len(nodes["测试点"]) == 1 and text(nodes["测试点"][0]), "关系上游测试点必须为唯一非空测试点描述")
        for r in allowed.values():
            for category in (r["head"], r["tail"]):
                require(isinstance(nodes.get(category), list) and all(text(v) for v in nodes[category]), "缺少关系依赖的已校验上游：" + category)
        seen = set()
        for edge in result[keys[0]]:
            require(isinstance(edge, dict) and set(edge) == {"头实体", "关系", "尾实体"} and all(text(v) for v in edge.values()), "关系结构错误")
            r = allowed.get(edge["关系"])
            require(r is not None, "关系类型不在本次允许范围内")
            h, t = edge["头实体"], edge["尾实体"]
            require(h in nodes[r["head"]] and t in nodes[r["tail"]], "关系端点不属于对应类别的上游")
            require(r["head"] != r["tail"] or h != t, "同类节点不能自环")
            signature = (edge["关系"], *sorted((h, t))) if edge["关系"] == "因子并列因子" else (edge["关系"], h, t)
            require(signature not in seen, "重复关系或并列反向重复")
            seen.add(signature)
    elif task == "image_type":
        paths = context.get("image_paths")
        require(isinstance(paths, list) and len(result[keys[0]]) == len(paths), "图片类型须与实际输入图片等长")
        require(all(v in ("UI界面截图", "录屏动画", "调试工具截图", "代码变更截图") for v in result[keys[0]]), "非法图片类型")
    elif task == "object_tree":
        objects = context.get("extracted_test_objects")
        require(isinstance(objects, list) and all(text(v) for v in objects) and len(objects) == len(result[keys[0]]), "归属与上游对象必须等长")
        if objects:
            raw = context.get("object_tree_text")
            if raw is None and context.get("object_tree_path"):
                raw = Path(context["object_tree_path"]).read_text(encoding="utf-8-sig")
            require(isinstance(raw, str), "缺少实际对象树快照")
            nodes = tree_nodes(raw)
        for obj, item in zip(objects, result[keys[0]]):
            require(isinstance(item, dict) and set(item) == {"测试对象", "归类方式", "归属路径", "目标节点类型", "目标节点ID", "新节点"}, "归属结构错误")
            require(item["测试对象"] == obj and text(item["归属路径"]), "归属对象名称、顺序或路径错误")
            if item["归类方式"] == "existing":
                require(nodes.get(item["归属路径"]) == (item["目标节点类型"], item["目标节点ID"]) and item["新节点"] is None, "已有节点路径、类型或ID与实际树不符")
            else:
                require(item["归类方式"] == "new" and item["目标节点类型"] == "category" and item["目标节点ID"] is None, "新节点方式、类型或ID错误")
                new = item["新节点"]
                require(isinstance(new, dict) and set(new) == {"父节点路径", "节点名称", "节点类型"}, "新节点结构错误")
                parent, name = new["父节点路径"], new["节点名称"]
                require(text(parent) and parent in nodes and nodes[parent][0] == "category" and text(name) and "->" not in name and new["节点类型"] == "category", "新节点父分类或名称错误")
                require(item["归属路径"] == parent + "->" + name and item["归属路径"] not in nodes, "新节点路径不符或节点已存在")
    else:
        require(all(text(v) for v in result[keys[0]]), "基础要素须为非空字符串数组")
    return result


def read_json(path):
    def unique(pairs):
        value = {}
        for k, v in pairs:
            require(k not in value, "JSON包含重复字段：" + k)
            value[k] = v
        return value
    return json.loads(Path(path).read_text(encoding="utf-8-sig"), object_pairs_hook=unique)


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--plan", required=True)
    parser.add_argument("--task", required=True)
    parser.add_argument("--result", required=True)
    parser.add_argument("--context", help="实际图片列表/上游结果/对象树快照的JSON文件")
    args = parser.parse_args()
    try:
        plan = read_json(args.plan)
        validate_result(args.task, plan["tasks"][args.task], read_json(args.result), read_json(args.context) if args.context else {})
        print(json.dumps({"valid": True, "task": args.task}, ensure_ascii=False))
    except (ValueError, KeyError, TypeError, OSError, AttributeError) as error:
        print(json.dumps({"__error__": "TASK_RESULT_INVALID", "task": args.task, "message": str(error)}, ensure_ascii=False))
        raise SystemExit(1)


if __name__ == "__main__":
    main()
