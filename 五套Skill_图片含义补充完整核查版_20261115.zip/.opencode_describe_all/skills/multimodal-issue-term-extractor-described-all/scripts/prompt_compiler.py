"""Merge readable Markdown sections into a complete prompt. Standard library only."""
import hashlib
import json
import os
import re
import tempfile
from pathlib import Path

FORMAT = "markdown_sections_v1"
GROUPS = ("角色设置", "任务说明", "输入与证据", "要素定义", "判断与对齐规则", "输出前检查", "结果格式", "提取示例", "复核要求")


def digest(data):
    return hashlib.sha256(data).hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def source_path(spec):
    """Explicit source key for new bundles; legacy complete-prompt bundles still load."""
    if "source_path" in spec and "path" in spec:
        raise ValueError("提示词同时包含source_path和旧path，无法确定来源")
    return spec.get("source_path", spec.get("path"))


def paragraphs(text):
    return re.split(r"\n[ \t]*\n+", text.replace("\r\n", "\n").strip()) if text.strip() else []


def normalize(text):
    return "\n\n".join(paragraphs(text)) + "\n"


def outside_lines(text):
    fence, offset = None, 0
    for line in text.splitlines(keepends=True):
        boundary = re.match(r"\s*(`{3,}|~{3,})([^\r\n]*)", line)
        if boundary:
            if not fence:
                fence = (boundary[1][0], len(boundary[1]))
            elif fence[0] == boundary[1][0] and len(boundary[1]) >= fence[1] and not boundary[2].strip():
                fence = None
        elif not fence:
            yield line, offset, offset + len(line)
        offset += len(line)


def role_variables(text, names):
    """Only the first role section binds a variable; example input stays literal."""
    heads = [(line[4:].strip(), start, end) for line, start, end in outside_lines(text) if line.startswith("### ")]
    for i, (heading, start, end) in enumerate(heads):
        if heading == "角色":
            stop = heads[i + 1][1] if i + 1 < len(heads) else len(text)
            body = text[end:stop]
            for name in names:
                if name:
                    body = body.replace("熟悉" + name + "业务", "熟悉{{business_name}}业务")
            return text[:end] + body + text[stop:]
    return text


def bind_role(text, business_name):
    heads = [(line[4:].strip(), start, end) for line, start, end in outside_lines(text) if line.startswith("### ")]
    for i, (heading, start, end) in enumerate(heads):
        if heading == "角色":
            stop = heads[i + 1][1] if i + 1 < len(heads) else len(text)
            return text[:end] + text[end:stop].replace("{{business_name}}", business_name) + text[stop:]
    return text


def split_prompt(text):
    """Keep whole logical sections, including their original model-facing headings."""
    text = normalize(text)
    heads = [(line[4:].strip(), start, end) for line, start, end in outside_lines(text) if line.startswith("### ")]
    if not heads or not any(h[0] == "输出格式" for h in heads):
        return {"复核要求": text.strip()}
    if text[:heads[0][1]].strip():
        raise ValueError("完整Prompt在角色章节前含未归属正文")
    groups, previous = {}, -1
    for i, (heading, start, _end) in enumerate(heads):
        if heading == "角色": group = "角色设置"
        elif heading == "任务": group = "任务说明"
        elif heading in ("多模态输入说明", "输入说明", "输入与证据", "输入约束", "本次允许的关系范围", "上游输入"): group = "输入与证据"
        elif heading.startswith("定义") or heading in ("图片类型", "允许的关系类型"): group = "要素定义"
        elif heading == "内部检查": group = "输出前检查"
        elif heading == "输出格式": group = "结果格式"
        elif heading in ("Examples", "Example"): group = "提取示例"
        else: group = "判断与对齐规则"
        position = GROUPS.index(group)
        if position < previous:
            raise ValueError("Prompt章节顺序不合法或示例中的三级标题未放入代码块：" + heading)
        previous = position
        stop = heads[i + 1][1] if i + 1 < len(heads) else len(text)
        groups[group] = (groups.get(group, "") + "\n\n" + text[start:stop].strip()).strip()
    return groups


def parse_document(text):
    """Only explicitly named wrapper headings are structural, not ordinary Markdown."""
    text = text.replace("\r\n", "\n")
    heads = []
    for line, start, end in outside_lines(text):
        match = re.fullmatch(r"## 片段：([^\n]+)\n?", line)
        if match:
            key = match[1].strip()
            if key not in GROUPS or any(h[0] == key for h in heads):
                raise ValueError("Markdown片段名无效或重复：" + key)
            heads.append((key, start, end))
    result = {}
    for i, (key, _start, end) in enumerate(heads):
        stop = heads[i + 1][1] if i + 1 < len(heads) else len(text)
        body = text[end:stop].strip()
        if not body:
            raise ValueError("Markdown片段不能为空：" + key)
        result[key] = body
    prefix = text[:heads[0][1]] if heads else text
    for line, _start, _end in outside_lines(prefix):
        if line.strip() and not line.startswith("# ") and not re.fullmatch(r"<!--.*-->\s*", line):
            raise ValueError("Markdown正文缺少“## 片段：名称”标题")
    return result


def document(sections, title):
    text = "# " + title + "\n\n<!-- 片段标题只用于合并，不会提供给提取模型。 -->\n"
    for key, body in sections.items():
        text += "\n## 片段：" + key + "\n\n" + body.strip() + "\n"
    return text


def library(skill_root, task):
    root = Path(skill_root).resolve() / "prompt_templates"
    index = read_json(root / "index.json")
    if index.get("format_version") != FORMAT or task not in index.get("tasks", {}):
        raise ValueError("未登记公共Markdown模板：" + task)
    spec = index["tasks"][task]
    path = (root / spec["path"]).resolve()
    if not path.is_relative_to(root) or path.suffix != ".md" or digest(path.read_bytes()) != spec.get("sha256"):
        raise ValueError("公共模板路径或校验不一致：" + task)
    sections = parse_document(path.read_text(encoding="utf-8-sig"))
    if not sections:
        raise ValueError("公共Markdown模板没有章节：" + task)
    for key, body in sections.items():
        if re.fullmatch(r"\{\{业务\.[^\n]+\}\}", body) and body != slot(key):
            raise ValueError("公共模板的业务占位符与片段名不一致：" + key)
    return sections, {"template_sha256": spec["sha256"], "template_version": index["version"]}


def slot(key):
    return "{{业务." + key + "}}"


def render_fragment(source, template, business_name):
    differences = parse_document(source)
    if set(differences) - set(template):
        raise ValueError("业务片段不属于本任务模板：" + "、".join(sorted(set(differences) - set(template))))
    result = []
    for key, default in template.items():
        value = differences.get(key, default)
        if value == slot(key):
            raise ValueError("缺少业务Markdown片段：" + key)
        result.append(bind_role(value, business_name) if key == "角色设置" else value)
    return normalize("\n\n".join(result))


def pack_fragment(text, template, business_name, source_name=None):
    sections = split_prompt(role_variables(text, [business_name, source_name]))
    if list(sections) != list(template):
        raise ValueError("完整Prompt的逻辑章节与公共模板不一致")
    differences = {key: body for key, body in sections.items() if normalize(body) != normalize(template[key])}
    return document(differences, business_name + " · 业务专属提示词")


def read_prompt(bundle, spec, business_name):
    bundle = Path(bundle).resolve()
    path = (bundle / source_path(spec)).resolve()
    if not path.is_relative_to(bundle):
        raise ValueError("业务提示词路径越界")
    data = path.read_bytes()
    if digest(data) != spec.get("sha256"):
        raise ValueError("业务提示词与配置校验不一致")
    if "template_ref" not in spec:
        return data.decode("utf-8-sig"), {"source_sha256": digest(data)}
    template, signature = library(Path(__file__).resolve().parent.parent, spec["template_ref"])
    text = render_fragment(data.decode("utf-8-sig"), template, business_name)
    return text, {**signature, "source_sha256": digest(data), "compiled_sha256": digest(text.encode("utf-8"))}


def materialize(text, output_dir, task):
    if output_dir is None:
        return None
    folder = Path(output_dir).resolve()
    folder.mkdir(parents=True, exist_ok=True)
    if not re.fullmatch(r"[A-Za-z0-9_-]+", task):
        raise ValueError("不合法的提示词任务名称")
    path = folder / (task + "_" + digest(text.encode("utf-8")) + ".md")
    if not path.exists():
        with tempfile.NamedTemporaryFile(dir=folder, prefix=".prompt-", delete=False) as stream:
            temporary = Path(stream.name)
            stream.write(text.encode("utf-8"))
        try:
            os.replace(temporary, path)
        finally:
            if temporary.exists():
                temporary.unlink()
    elif path.read_bytes() != text.encode("utf-8"):
        raise ValueError("已有提示词快照内容与校验值不一致")
    return str(path)
