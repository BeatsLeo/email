"""Resolve business field selection into a deterministic extraction plan. Python stdlib only."""
import argparse
import hashlib
import importlib.util
import json
import re
import sys
from pathlib import Path


class PlanError(ValueError):
    pass


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def local_path(bundle, relative):
    if not isinstance(relative, str) or not relative or Path(relative).is_absolute():
        raise PlanError("包内路径必须为有效相对路径")
    result = (bundle / relative).resolve()
    if not result.is_relative_to(bundle):
        raise PlanError("包内路径不能越界")
    return result


def empty_trigger(task, spec):
    kind = spec.get("task_kind")
    if task == "root_cause" or kind == "root_cause":
        return "empty_string"
    if task == "test_point" or kind in ("factor_names", "image_type", "object_tree") or task == "object_tree":
        return None
    if kind in ("factor", "factor_pair", "relation") or task in ("object", "action", "condition", "expectation", "factor_pair", "relation"):
        return "all_output_arrays_empty"
    return None


def prompt_tools():
    path = Path(__file__).with_name("prompt_compiler.py")
    spec = importlib.util.spec_from_file_location("business_prompt_compiler", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def build_plan(bundle, selection=None, prompt_output_dir=None):
    bundle = Path(bundle).resolve()
    business_path = bundle / "business.json"
    manifest = read_json(business_path)
    if not isinstance(manifest, dict) or manifest.get("format_version") != "3.0":
        raise PlanError("业务配置须为3.0单文件格式")
    if not isinstance(manifest.get("name"), str) or not manifest["name"].strip() or not isinstance(manifest.get("version"), str) or not manifest["version"].strip():
        raise PlanError("业务名称或版本缺失")
    selection_path = Path(selection).resolve() if selection else business_path
    config = read_json(selection_path) if selection else manifest.get("selection")
    if not isinstance(config, dict) or set(config) - {"配置版本", "提取内容", "关系类型"}:
        raise PlanError("任务配置只允许配置版本、提取内容和可选的关系类型")
    if config.get("配置版本") != "1.0":
        raise PlanError("不支持的任务配置版本")
    fields = config.get("提取内容")
    if not isinstance(fields, list) or not fields or any(not isinstance(x, str) for x in fields) or len(fields) != len(set(fields)):
        raise PlanError("提取内容须为非空、不重复的字段名数组")
    fields = ["问题单号"] + [x for x in fields if x != "问题单号"]
    catalog = manifest.get("prompts", {})
    compiler = prompt_tools()
    library_index = Path(__file__).resolve().parent.parent / "prompt_templates" / "index.json"
    library_hash = hashlib.sha256(library_index.read_bytes()).hexdigest() if library_index.is_file() else None
    owners = {}
    for task, spec in catalog.items():
        local_path(bundle, compiler.source_path(spec))
        for key in spec.get("output_keys", []):
            if key in owners:
                raise PlanError("重复字段生产任务：" + key)
            owners[key] = task
    for field in fields[1:]:
        if field not in owners:
            raise PlanError("业务包未注册字段：" + field)
    allowed = manifest.get("relations", [])
    names = [r["name"] for r in allowed]
    chosen = config.get("关系类型", names)
    if not isinstance(chosen, list) or any(not isinstance(x, str) for x in chosen) or len(chosen) != len(set(chosen)) or any(x not in names for x in chosen):
        raise PlanError("关系类型须为业务包允许类型的不重复子集")
    relation_catalog = {task: spec for task, spec in catalog.items() if spec.get("task_kind") == "relation" or task == "relation"}
    relation_scopes = {}
    for task, spec in relation_catalog.items():
        scope = spec.get("relation_types", names)
        if not isinstance(scope, list) or any(not isinstance(x, str) or x not in names for x in scope) or len(scope) != len(set(scope)):
            raise PlanError("关系任务范围须为业务允许类型的不重复子集：" + task)
        if len(spec.get("output_keys", [])) != 1:
            raise PlanError("每个独立关系任务须输出一个字段：" + task)
        relation_scopes[task] = scope
    active_relations = [task for task, spec in relation_catalog.items() if any(k in fields for k in spec["output_keys"])]
    by_task = {task: [r for r in allowed if r["name"] in relation_scopes[task] and r["name"] in chosen and r["head"] in fields and r["tail"] in fields] for task in active_relations}
    scoped_names = {name for task in active_relations for name in relation_scopes[task]}
    effective = [r for r in allowed if any(r in values for values in by_task.values())]
    omitted = [r["name"] for r in allowed if r["name"] in scoped_names and r["name"] in chosen and r not in effective]
    tasks, visiting = {}, set()

    def add(task):
        if task in tasks:
            return
        if task in visiting:
            raise PlanError("任务依赖成环：" + task)
        visiting.add(task)
        spec = catalog[task]
        deps = list(spec.get("dependencies", []))
        alignment = spec.get("expectation_alignment")
        if alignment is not None:
            if task != "expectation" or alignment != "factor_steps" or not {"测试动作因子", "测试数据因子"}.issubset(deps):
                raise PlanError("逐步预期必须依赖完整动作/数据因子对")
        task_relations = by_task.get(task, [])
        if task in relation_catalog:
            deps = list(dict.fromkeys(k for r in task_relations for k in (r["head"], r["tail"])))
        for field in deps:
            if field not in owners:
                raise PlanError("未注册依赖字段：" + field)
            add(owners[field])
        prompt = local_path(bundle, compiler.source_path(spec))
        if not prompt.is_file():
            raise PlanError("已启用任务Prompt缺失：" + task)
        expected_sha = spec.get("sha256")
        if not isinstance(expected_sha, str) or not re.fullmatch(r"[0-9a-f]{64}", expected_sha):
            raise PlanError("已启用任务缺少有效Prompt校验值：" + task)
        if hashlib.sha256(prompt.read_bytes()).hexdigest() != expected_sha:
            raise PlanError("Prompt与业务清单校验不一致：" + task)
        text, signature = compiler.read_prompt(bundle, spec, manifest["name"])
        compiled = compiler.materialize(text, prompt_output_dir, task) if "template_ref" in spec else str(prompt)
        contract = {k: v for k, v in spec.items() if k not in ("path", "source_path", "sha256", "template_ref")}
        tasks[task] = {**contract, "prompt_path": compiled, "prompt_sha256": hashlib.sha256(text.encode("utf-8")).hexdigest(), "prompt_signature": signature, "dependencies": deps,
                       "dependency_tasks": list(dict.fromkeys(owners[k] for k in deps)),
                       "export_fields": [k for k in spec["output_keys"] if k in fields],
                       "stage": "post_batch" if task == "object_tree" else "dependent" if deps else "parallel"}
        if compiled is None:
            tasks[task]["prompt_text"] = text
        if task in relation_catalog:
            tasks[task]["allowed_relations"] = task_relations
            tasks[task]["constant_empty"] = not task_relations
        visiting.remove(task)

    for field in fields[1:]:
        add(owners[field])
    review = manifest.get("recheck", {})
    review_path = local_path(bundle, compiler.source_path(review))
    if not review_path.is_file():
        raise PlanError("空结果复核Prompt缺失")
    if hashlib.sha256(review_path.read_bytes()).hexdigest() != review.get("sha256"):
        raise PlanError("空结果复核Prompt与清单校验不一致")
    review_text, review_signature = compiler.read_prompt(bundle, review, manifest["name"])
    expanded_review = compiler.materialize(review_text, prompt_output_dir, "empty_recheck") if "template_ref" in review else str(review_path)
    if library_hash is not None and hashlib.sha256(library_index.read_bytes()).hexdigest() != library_hash:
        raise PlanError("生成计划时公共模板发生变化，请使用稳定版本重试")
    for task, spec in tasks.items():
        trigger = empty_trigger(task, spec)
        spec["empty_check"] = {"eligible": trigger is not None, "trigger": trigger, "max_reviews": 1}
    config_bytes = json.dumps(config, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return {"plan_version": "2.0", "business": manifest["name"], "bundle_dir": str(bundle),
            "profile_version": manifest["version"], "selection_path": str(selection_path),
            "business_path": str(business_path), "business_sha256": hashlib.sha256(business_path.read_bytes()).hexdigest(),
            "object_tree_path": manifest.get("object_tree_path"),
            "selection_sha256": hashlib.sha256(config_bytes).hexdigest(), "output_fields": fields,
            "tasks": tasks, "effective_relations": effective, "effective_relations_by_task": by_task, "omitted_relations": omitted,
            "recheck": {"prompt_path": expanded_review, "prompt_sha256": hashlib.sha256(review_text.encode("utf-8")).hexdigest(), "prompt_text": review_text if expanded_review is None else None, "prompt_signature": review_signature},
            "prompt_library_sha256": library_hash,
            "prompts_materialized": all(s.get("prompt_path") for s in tasks.values()) and expanded_review is not None,
            "empty_check": {"required": True, "max_reviews": 1, "review_prompt_path": expanded_review,
                            "command": "python scripts/plan_extraction.py --empty-check --plan <plan.json> --results <task_results.json> --reviews <empty_reviews.json>"},
            "object_tree_enabled": "object_tree" in tasks,
            "internal_fields": list(dict.fromkeys(k for spec in tasks.values() for k in spec["output_keys"] if k not in fields))}


def verify_prompt_files(plan):
    """Execution gate: previews, source fragments and changed snapshots cannot dispatch."""
    if plan.get("prompts_materialized") is not True:
        raise PlanError("PROMPTS_NOT_MATERIALIZED：这是预览计划，须用正式CLI生成完整文件")
    tasks = plan.get("tasks")
    if not isinstance(tasks, dict) or not tasks:
        raise PlanError("执行计划缺少任务")
    checked = {}
    for task, spec in {**tasks, "empty_recheck": plan.get("recheck", {})}.items():
        if any(k in spec for k in ("path", "source_path", "prompt_source_path", "template_ref")):
            raise PlanError("AMBIGUOUS_PROMPT_PATH：请重新生成计划：" + task)
        value, expected = spec.get("prompt_path"), spec.get("prompt_sha256")
        if not isinstance(value, str) or not Path(value).is_absolute() or not Path(value).is_file():
            raise PlanError("完整Prompt文件不存在：" + task)
        if not isinstance(expected, str) or hashlib.sha256(Path(value).read_bytes()).hexdigest() != expected:
            raise PlanError("完整Prompt文件校验失败：" + task)
        checked[task] = {"prompt_path": value, "prompt_sha256": expected}
    if plan.get("empty_check", {}).get("review_prompt_path") != plan["recheck"]["prompt_path"]:
        raise PlanError("复核入口未指向同一完整Prompt")
    return {"ready": True, "prompts": checked}


def validate_task_result(plan, task, result, task_results, context=None):
    """Validate real returns, including internal fields, using actual upstream values."""
    context = dict(context or {})
    spec = plan["tasks"][task]
    nodes = {}
    for dep in spec.get("dependency_tasks", []):
        upstream = task_results.get(dep)
        if not isinstance(upstream, dict):
            raise ValueError("必需上游未成功：" + dep)
        nodes.update(upstream)
    if task in ("factor_names", "relation") or spec.get("task_kind") == "relation" or spec.get("expectation_alignment") == "factor_steps":
        # Actual completed upstream results take precedence over caller-supplied copies.
        context["extracted_test_factors"] = {k: nodes[k] for k in ("测试动作因子", "测试数据因子") if k in nodes} or None
        context["extracted_factors"] = nodes
    if task == "object_tree":
        context["extracted_test_objects"] = nodes.get("测试对象")
    path = Path(__file__).with_name("validate_result.py")
    module_spec = importlib.util.spec_from_file_location("actual_result_validator", path)
    validator = importlib.util.module_from_spec(module_spec)
    module_spec.loader.exec_module(validator)
    return validator.validate_result(task, spec, result, context)


def _is_empty(spec, trigger, result):
    if trigger == "empty_string":
        return all(isinstance(result[k], str) and not result[k].strip() for k in spec["output_keys"])
    return trigger == "all_output_arrays_empty" and all(result[k] == [] for k in spec["output_keys"])


def _empty_skip_reason(plan, task, results):
    spec = plan["tasks"][task]
    if spec.get("constant_empty"):
        return "no_allowed_relations"
    if task == "root_cause" and "图片类型" in spec.get("dependencies", []):
        classifications = [results[d].get("图片类型") for d in spec["dependency_tasks"] if isinstance(results.get(d), dict) and "图片类型" in results[d]]
        if classifications and not any("代码变更截图" in values for values in classifications):
            return "no_code_image"
    if spec.get("expectation_alignment") == "factor_steps":
        for dep in spec["dependency_tasks"]:
            upstream = results.get(dep)
            if isinstance(upstream, dict) and upstream.get("测试动作因子") == [] and upstream.get("测试数据因子") == []:
                return "empty_upstream_factor_pair"
    if spec.get("task_kind") == "relation" or task == "relation":
        nodes = {k: v for dep in spec["dependency_tasks"] if isinstance(results.get(dep), dict) for k, v in results[dep].items()}
        # With no distinct endpoints, a non-self relation cannot exist.
        possible = any((len(set(nodes.get(r["head"], []))) >= 2 if r["head"] == r["tail"] else bool(nodes.get(r["head"])) and bool(nodes.get(r["tail"]))) for r in spec.get("allowed_relations", []))
        if not possible:
            return "not_enough_endpoints"
    return None


def check_empty_results(plan, task_results, empty_reviews=None, task_contexts=None):
    """Decide real review calls and refuse to treat unreviewed empty outputs as final."""
    if not isinstance(task_results, dict) or empty_reviews is not None and not isinstance(empty_reviews, dict):
        raise ValueError("任务返回及复核记录须按任务ID组织为JSON对象")
    if task_contexts is not None and not isinstance(task_contexts, dict):
        raise ValueError("任务上下文须按任务ID组织为JSON对象")
    reviews, contexts = empty_reviews or {}, task_contexts or {}
    if set(reviews) - set(plan["tasks"]):
        raise ValueError("复核记录包含不属于本次计划的任务")
    results, states, pending, unfinished, blocked = dict(task_results), {}, [], [], []
    for task, spec in plan["tasks"].items():
        waiting = [dep for dep in spec["dependency_tasks"] if states.get(dep, {}).get("status") in ("pending_recheck", "not_finished", "blocked_by_upstream")]
        if task not in results:
            states[task] = {"status": "not_finished"}
            unfinished.append(task)
            continue
        if waiting:
            states[task] = {"status": "blocked_by_upstream", "dependencies": waiting}
            blocked.append(task)
            continue
        result, record = results[task], reviews.get(task)
        if result is None:
            if record is not None:
                raise ValueError("技术失败null不能冒充已复核空结果：" + task)
            states[task] = {"status": "failed_not_rechecked"}
            continue
        context = contexts.get(task)
        validate_task_result(plan, task, result, results, context)
        trigger, skip = empty_trigger(task, spec), _empty_skip_reason(plan, task, results)
        if record is not None:
            if not isinstance(record, dict) or "initial_result" not in record:
                raise ValueError("复核记录须保留真实首次返回initial_result：" + task)
            initial = record["initial_result"]
            validate_task_result(plan, task, initial, results, context)
            if not _is_empty(spec, trigger, initial) or skip:
                raise ValueError("此首次返回不符合空值复核触发条件：" + task)
            error = record.get("review_error")
            if error is not None:
                if not ((isinstance(error, str) and error.strip()) or isinstance(error, dict) and error) or record.get("review_result") is not None:
                    raise ValueError("失败复核须保留真实错误，不能同时填成功返回：" + task)
                chosen, status = initial, "recheck_failed_kept_initial"
            else:
                if "review_result" not in record:
                    raise ValueError("复核记录缺少实际返回review_result：" + task)
                chosen = record["review_result"]
                validate_task_result(plan, task, chosen, results, context)
                status = "confirmed_empty" if _is_empty(spec, trigger, chosen) else "recovered"
            if result != initial and result != chosen:
                raise ValueError("最终返回与首次/复核返回均不一致：" + task)
            results[task] = chosen
            states[task] = {"status": status, "event": "EMPTY_RESULT_RECHECK"}
        elif not _is_empty(spec, trigger, result):
            states[task] = {"status": "not_empty" if trigger else "not_applicable"}
        elif skip:
            states[task] = {"status": "skipped_constant_empty", "reason": skip}
        else:
            states[task] = {"status": "pending_recheck"}
            request = {"task_id": task, "task_kind": spec["task_kind"], "output_keys": spec["output_keys"],
                       "prompt_path": spec["prompt_path"], "review_mode": "empty_result_recheck",
                       "review_prompt_path": plan["recheck"]["prompt_path"], "previous_empty_result": result}
            if spec.get("task_kind") == "relation":
                request["allowed_relations"] = spec.get("allowed_relations", [])
                nodes = {k: v for dep in spec["dependency_tasks"] for k, v in results[dep].items()}
                request["extracted_factors"] = {k: nodes[k] for k in spec["dependencies"] if k in nodes}
                if "测试动作因子" in nodes:
                    request["extracted_test_factors"] = {k: nodes[k] for k in ("测试动作因子", "测试数据因子")}
            elif spec.get("expectation_alignment") == "factor_steps":
                nodes = {k: v for dep in spec["dependency_tasks"] for k, v in results[dep].items()}
                request["extracted_test_factors"] = {k: nodes[k] for k in ("测试动作因子", "测试数据因子")}
            pending.append(request)
    pre_batch_ready = all(states[task]["status"] not in ("pending_recheck", "not_finished", "blocked_by_upstream") for task, spec in plan["tasks"].items() if spec["stage"] != "post_batch")
    return {"empty_check": "complete" if not pending and not unfinished and not blocked else "pending", "ready": not pending and not unfinished and not blocked, "ready_for_post_batch": pre_batch_ready,
            "pending_rechecks": pending, "unfinished_tasks": unfinished, "blocked_tasks": blocked, "states": states, "task_results": results}


def assemble_result(plan, issue_id, task_results, task_contexts=None, empty_reviews=None):
    """Require empty-check completion before projecting final output fields."""
    task_contexts = task_contexts or {}
    report = check_empty_results(plan, task_results, empty_reviews, task_contexts)
    if not report["ready"]:
        pending = [r["task_id"] for r in report["pending_rechecks"]]
        raise ValueError("EMPTY_CHECK_PENDING：禁止汇总，待复核=" + ",".join(pending) + "；未完成=" + ",".join(report["unfinished_tasks"]) + "；上游待定=" + ",".join(report["blocked_tasks"]))
    task_results = report["task_results"]
    values = {"问题单号": issue_id}
    for task, spec in plan["tasks"].items():
        result = task_results.get(task)
        for field in spec["export_fields"]:
            values[field] = result.get(field) if isinstance(result, dict) else None
    return {field: values[field] for field in plan["output_fields"]}


def excel_columns(plans):
    return list(dict.fromkeys(field for plan in plans for field in plan["output_fields"]))


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--bundle")
    parser.add_argument("--selection", help="仅本次使用的完整任务选择配置；不改业务默认")
    parser.add_argument("--prompt-output", help="合并后的完整Prompt快照目录，建议放在本次运行目录中")
    parser.add_argument("--empty-check", action="store_true", help="检查实际返回，列出必须再次调用模型的空结果")
    parser.add_argument("--verify-prompts", action="store_true", help="派发前检查完整Prompt文件及哈希，拒绝片段和预览计划")
    parser.add_argument("--plan")
    parser.add_argument("--results", help="按任务ID保存的实际返回JSON，确定失败为null，未完成不填")
    parser.add_argument("--reviews", help="按任务ID保存的真实首次及复核返回/错误")
    parser.add_argument("--contexts", help="按任务ID保存的真实上游/图片/树上下文")
    args = parser.parse_args()
    try:
        if args.verify_prompts:
            if args.empty_check or not args.plan:
                raise PlanError("verify-prompts需要--plan，不能同时运行empty-check")
            print(json.dumps(verify_prompt_files(read_json(args.plan)), ensure_ascii=False, indent=2))
        elif args.empty_check:
            if not args.plan or not args.results:
                raise PlanError("empty_check需要--plan和--results")
            report = check_empty_results(read_json(args.plan), read_json(args.results), read_json(args.reviews) if args.reviews else {}, read_json(args.contexts) if args.contexts else {})
            print(json.dumps(report, ensure_ascii=False, indent=2))
            if not report["ready"]:
                raise SystemExit(2)
        else:
            if not args.bundle:
                raise PlanError("生成执行计划需要--bundle")
            destination = args.prompt_output or str(Path.cwd() / ".opencode_prompt_cache")
            plan = build_plan(args.bundle, args.selection, destination)
            verify_prompt_files(plan)
            print(json.dumps(plan, ensure_ascii=False, indent=2))
    except (PlanError, OSError, ValueError, TypeError, KeyError) as error:
        print(json.dumps({"__error__": "EMPTY_CHECK_INVALID" if args.empty_check else "EXTRACTION_PLAN_INVALID", "message": str(error)}, ensure_ascii=False))
        raise SystemExit(1)


if __name__ == "__main__":
    main()
