Option Explicit
Dim shell, fs, folder, server, paths, item, candidate, interpreter, q, ok, modeArgs
Set shell = CreateObject("WScript.Shell")
Set fs = CreateObject("Scripting.FileSystemObject")
q = Chr(34)
folder = fs.GetParentFolderName(WScript.ScriptFullName)
server = fs.BuildPath(folder, "configurator\server.py")
shell.CurrentDirectory = folder
interpreter = ""
paths = Split(shell.ExpandEnvironmentStrings("%PATH%"), ";")
For Each item In paths
  item = Replace(Trim(item), q, "")
  If Len(item) > 0 And InStr(LCase(item), "windowsapps") = 0 Then
    candidate = fs.BuildPath(item, "python.exe")
    If fs.FileExists(candidate) Then
      On Error Resume Next
      ok = shell.Run(q & candidate & q & " -c " & q & "import sys; sys.exit(0 if sys.version_info >= (3,9) else 1)" & q, 0, True)
      If Err.Number = 0 And ok = 0 Then interpreter = q & candidate & q
      Err.Clear
      On Error GoTo 0
      If Len(interpreter) > 0 Then Exit For
    End If
  End If
Next
If Len(interpreter) = 0 Then
  On Error Resume Next
  ok = shell.Run("py -3 -c " & q & "import sys; sys.exit(0 if sys.version_info >= (3,9) else 1)" & q, 0, True)
  If Err.Number = 0 And ok = 0 Then interpreter = "py -3"
  Err.Clear
  On Error GoTo 0
End If
If Len(interpreter) = 0 Then
  MsgBox "Python 3.9+ is required. Please ask your deployment maintainer to install Python, then reopen this file.", 48, "Business configuration"
  WScript.Quit 1
End If
modeArgs = ""
If WScript.Arguments.Count > 0 Then
  If WScript.Arguments(0) = "text" Then modeArgs = " --mode text"
End If
shell.Run interpreter & " " & q & server & q & modeArgs, 0, False
