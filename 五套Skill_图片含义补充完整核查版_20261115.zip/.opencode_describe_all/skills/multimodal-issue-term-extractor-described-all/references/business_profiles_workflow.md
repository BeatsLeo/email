# 用户指定业务与即用包路由

## 用户业务确认

业务由用户明确提供；没有提供必须向用户反问，不能根据输入内容或产品名自动识别。此处“判断业务”仅指理解用户提供的名称并匹配注册表。

允许使用用户已明确适用于当前任务的前文业务信息，不重复询问；此前仅讨论过两个业务不能视为已选定。本次混合批次须由用户给出目录或问题单映射，未指定部分先反问。业务确认前不启动任何提取、图片分类、根因、复核或对象树调用，也不写失败结果。

## 注册表

读取config/business_registry.json，所有相对路径以Skill目录解析。注册表businesses按规范业务名索引，aliases用于用户显式名称的等价匹配。仅做去首尾空格和英文大小写归一，不用模糊匹配、关键词推断或产品知识改选业务。

1. 用户名匹配唯一业务名或已登记别名：使用该项bundle_dir。
2. 用户已给出明确新业务名但无注册项：直接使用businesses/default，记录actual_business为用户名称，bundle_business为通用默认，fallback_reason为no_business_bundle；不要求用户重新编写配置才能提取。
3. 同一别名匹配多个业务或用户给出矛盾信息：反问明确，不自行选版本。
4. 注册业务的包缺失或损坏：配置错误，不能用businesses/default掩盖。
5. 默认包也缺失：配置错误，不能现场生成。

全局配置和别名映射是确定性的。示例：“GTS业务”映射GTS；仅说“问答问题单”不等于用户提供了GTS业务。

## 直接读取文件

所有bundle_dir相对Skill目录解析。每包包含一份business.json及prompts/业务差异片段；公共Markdown模板位于本技能prompt_templates/。默认包在businesses/default，专属包在businesses/terminal和businesses/gts。

检查business.json的format_version为3.0，name与注册业务名一致；通用回退包保留其自身name，同时记录用户的实际业务。version用于固定批次快照。selection决定提取内容和关系子集；prompts和recheck登记业务片段路径、模板引用与源文件校验值，relations定义可用关系，object_tree_path提供可选对象树路径。公共内容只保留在模板中，业务片段只保留差异；编译器合并为完整Prompt，不另存语义摘要。

Prompt路径相对包目录解析，只能留在该包内，不能绝对路径、跨目录或指向未登记文件。通过scripts/plan_extraction.py解析任务清单、生成依赖闭包，并校验业务身份、版本、配置与已启用Prompt的哈希；只检查本次需要的任务文件及复核文件。business.json中的prompts是可用目录，不能按目录项数全部调用。主Agent调用计划脚本并指定--prompt-output <本次运行目录>/prompts，由Python确定性合并公共模板与业务片段，生成完整快照。主Agent不自行拼接、概括或重写；不需要Node.js或模型参与编译。

同批同业务固定只读包版本。记录实际业务、所用包、版本和路径；没有请求时不要读取其他业务的整套配置或Prompt。

## 任务契约

- object/action/condition/expectation/test_point：task_kind=factor，各一个指定字段。
- factor_pair：同时输出测试动作因子、测试数据因子。
- factor_names：同时输出动作因子名称、数据因子名称，等待第一阶段。
- task_kind=relation：支持独立关系任务，不能只按旧ID relation识别。计划先按本任务relation_types、提取内容和可选关系类型筛选，只保留两端已选的类型；由各自端点生成dependencies。每次allowed_relations传tasks[任务ID].allowed_relations，不传总effective_relations并集。
- image_type：仅图片类型被选或问题根因需要时启用，有图时逐图分类；未被选的图片类型仅作内部依赖。
- root_cause：代码类图片触发，读取本单全文和全部图片及code_change_image_indices。
- object_tree：仅清单选择测试对象树归属时启用，整批Qwen完成后交GLM归类，不传图片。关闭时不读取或校验树文件，不调用、不输出该字段。

终端软工维持原字段及六种基础关系。GTS仅提供对象、简洁测试点、完整动作/数据因子、逐步预期、测试对象与测试对象关系、测试动作因子之间关系；不提供基础动作、条件、名称、根因、图片分类或对象树任务。其expectation配置expectation_alignment为factor_steps，必须等待完整因子对，输出按原步骤号绑定的稀疏预期，每步最多一条，条数不超过步骤数；通过extracted_test_factors传入和校验。GTS的object_relation只等待对象，factor_relation只等待因子对，两次独立调用、分别复核与输出；不等待测试点或逐步预期，不建立跨类别关系。其他业务仅选择名称时仍自动生成内部因子对，不导出未选列。

清单中字段拼写须与output_keys一致。问题单号自动第一列；空清单、未知字段、重复字段或未知关系类型视为配置错误，不让模型猜测修正。用户本次提供完整清单文件时用--selection覆盖业务默认，不回写；未提供则自动使用对应业务包清单。关系类型省略时按业务允许全集及端点选择筛选，显式空数组则关系直接成功[]。没有有效关系类型时无需调用关系模型。

Qwen任务消息包含prompt_mode: business_profile、用户确认business_type、当前任务合并快照、原始材料和必要上游结果。类型与字段严格按business.json中的任务契约传递。一次只处理一个问题单的一个原子任务，不向模型发送整批其他问题单或其他业务定义。

issue_text_path始终指向包含本单全部原始字段的完整.md，不由主Agent摘取熟悉字段、删除未知字段或改写为固定输入结构。当前任务只输出一个或两个字段，不代表只能读取同名输入字段。用户放入.md的原始内容均保留；独立的GT或历史结果文件不自行拼入。字段名称和数量不需要在业务配置中逐一登记。

## 复核与一致性

计划中的empty_check为必经检查点。每次成功返回及每单汇总前，按SKILL中的--empty-check命令检查真实任务返回；recheck路径存在不等于已复核。pending_rechecks必须真实调用提取Agent并保留首次/复核返回或实际错误；assemble_result没有完成记录时拒绝汇总。不要将该检查当作输出字段或一个无条件额外模型任务。

business.json中的recheck指定已生成的复核Prompt，任务Prompt不变，已选测试条件须纳入默认空值复核；测试点必须恰好一个非空字符串，空值或多项按结构错误重试，不确认成合法空值；只复核计划实际运行且在名单内的任务。上游复核结束后才启动依赖。

关系端点逐字复制相应上游数组；有因子关系时额外传extracted_test_factors。同名重复步骤无实例ID，不生成需要区分次数才能成立的关系。对象包含、依赖、链路先后及因子时序/并列按各自定义，不能把对象列表自动串成时序链。

仅启用对象树时，树路径优先本次用户输入、其次business.json的object_tree_path；均缺失时只记录归类分支错误。缺树只影响后处理归类，不阻止基础提取。新节点只作为候选，不并发改写共享树。

已有业务包的自然语言矛盾返回PROFILE_RULE_CONFLICT，回到内置工作台调整对应正文并保存；模型不能静默折中。业务身份、业务配置错误和输入读取失败分别记录，不能归为“确实没有要素”。注册表路径由工作台保存同步，新增业务无须部署人员手工登记；缺少登记时仍按用户确认业务和通用回退规则处理，不自行猜路径。

## 最终结果

逐单JSON仅包含计划output_fields，必要内部字段单独保存在运行审计中。全部JSON落盘后汇总一个Excel；同业务按清单列顺序，混合业务取有序并集。不适用列空白，成功空数组为[]，技术失败为文本null。保留每单实际清单及版本，不能把未选择误判为模型漏提。

## 模板合并快照

模型只读计划中的prompt_path，不把business.json中指向的业务差异Markdown单独作为完整Prompt。prompts[*].template_ref登记任务模板，公共模板哈希由prompt_templates/index.json统一登记；业务片段自身哈希仍在business.json。每个计划记录公共库哈希、源片段哈希及合并后哈希。空结果复核也走同一模板机制并固定在本次快照中。


## 正式派发前的完整Prompt检查

source_path仅登记业务源文件；不得用于模型调用。执行计划只暴露完整prompt_path及其校验值。每次派发前按照SKILL.md运行--verify-prompts；未落盘预览计划、旧版歧义计划、文件缺失或被改动时停止。模型任务沿用3.4.2输入字段，不传配置、公共模板或源片段。
