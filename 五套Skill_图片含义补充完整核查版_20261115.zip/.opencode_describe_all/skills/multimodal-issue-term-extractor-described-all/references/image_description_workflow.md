# 图片内容补充流程

主Agent负责文件备份、请求生成、结果保存及脚本校验；图片分类和逐图问题分析必须实际调用qwen-vl-factor-extractor，不能由主Agent替代，也不能用文件名或OCR文本冒充读图。

本Skill的INCLUDED_TYPES已经固定，不通过临时参数切换；它只决定哪些说明写入新问题单，不改变逐图说明的生成规则。读取本节完整流程后执行。

## 各阶段实际传什么

| 阶段 | 问题单文本 | 图像输入 | 其他图片的分析 |
| --- | --- | --- | --- |
| 分类 | 原始备份全文 | 全部原图及全部已提供GIF帧 | 不传 |
| 分析一张图片 | 原始备份全文 | 当前一张原图；若是GIF，只传它的帧 | 不传 |
| 要素提取、依赖任务、空值复核 | 含本Skill所选图片分析的完整副本 | 全部原图及全部已提供GIF帧 | 仅通过副本读取所选类别分析，不另传完整冻结文件 |
| 按需对象树归类 | 同一完整副本 | 不传图片，仍用GLM | 不另传；按原流程提供最终对象与对象树 |

准备阶段始终分析全部图片，不能因本Skill只补入一类就少分析其他图片。待全部图片分析完成并冻结后，再由脚本按类别选择、按原图索引顺序集中写入副本。集中写入不表示已经生成跨图因果结论；后续模型仍须核对关联。

主Agent不得重新摘要分析、凭空新增解释、删掉依据或不确定项。图像类别只用于本阶段选择说明；不额外加入按类型定制的要素提取规则。传给要素模型的材料不含未选类别分析，也不提供包含全部分析的准备目录路径。

## 1. 准备原始证据

确认用户业务并生成基础提取计划后，按原始Markdown引用固定全部图片顺序。包括GIF，未引用图片按原约定追加。准备目录与补充副本目录必须位于原始问题单文件夹之外，且使用新的、尚不存在的目录；不要把运行目录混进后续输入发现。

```text
python scripts/image_description.py --prepare --plan <基础计划.json> --issue <原始问题单.md> --images <有序全部图片.json> --output-dir <本单准备目录>
```

脚本复制原始Markdown和全部图片为source_snapshot，保留通常的相对图片结构；外部引用图片复制到独立映射位置。原始文件不写入。图片清单、原文与图片哈希、原始路径及备份映射保存在source.json。GIF实际抽帧，默认最多24帧且含首尾；Python需要Pillow。主Agent将prepare真实返回及路径写入run_manifest。

如果用户提供本批已冻结的准备目录，可在核对对应问题单后跳到第4步，脚本会检查业务、原始输入哈希、分类/转写Prompt版本和基础提取Prompt一致性。复用后不能重新生成分类或说明。不同问题单不能共用一份准备目录。

## 2. 分类并生成逐图请求

call_required=true时，把classification_request.json的完整消息交给同一个Qwen-VL subagent。使用reference中的统一四类分类Prompt，实际读全部备份图片与GIF帧，真实返回保存为image_types.json。无图时prepare自动保存成功空分类，不调用。

```text
python scripts/image_description.py --describe --prepared <本单准备目录> --types <本单准备目录>/image_types.json
```

分类失败时最多技术重试2次，仍失败则停止该单内容补充分支，明确记录失败，不用基础输入继续冒充补充成功。分类用于选择要补入的文本，不给提取任务额外发送整批类别提示。

## 3. 逐图分析并冻结

逐个读取describe返回的request_paths，真实调用同一个Qwen-VL subagent，task_kind=image_description。不同图片的说明调用可并行：每次只读原始问题单和一张图片，GIF读取该图全部提供帧，不读其他图片说明。original_image_index为原始索引；单张请求的image_paths局部只有一项，派生帧局部image_index=0。

所有图片均使用同一个describe_image.md，完整读取正文并结合当前图分析它对本单反映的问题、关键矛盾和机制线索，保留图像/正文依据，不仅列画面或OCR。先将全部图片分析完成；不可只描述当前要补入的那一类，也不可按不同业务生成不同问题分析。真实结果按请求result_path保存为descriptions/<原始索引>.json。其字段是问题解读、核心问题、关键依据、机制判断及不确定信息，不是业务提取schema，不纳入最终业务JSON/Excel。

```text
python scripts/image_description.py --freeze --prepared <本单准备目录>
```

freeze验证逐图说明、索引、类型及GIF帧绑定后保存frozen.json。读取/格式错误最多重试2次，不能伪造空说明。IMAGE_DESCRIPTION_NEEDS_FRAMES时，用新的准备目录和更大的--max-frames重新准备该单，不改已有冻结材料。重试后仍失败时该单记为预处理失败，业务字段按原失败契约处理，不静默当正常结果。预处理不走业务empty_check；empty_check仍对后续实际业务任务必经执行。

## 4. 生成补充副本

```text
python scripts/image_description.py --assemble --plan <基础计划.json> --prepared <已冻结准备目录> --issue <本次原始问题单.md> --images <本次有序全部图片.json> --output-dir <本单补充运行目录>
```

脚本先校验本次原始问题单路径、内容及图片顺序确实对应这份冻结材料，避免复用错单。再复制备份为新的issue目录，在原Markdown字节之后追加“图片问题含义补充”，保留原始字段和顺序；只写入本Skill固定类别的说明。记录selected_image_indices、selected_count、coverage_status、原文/副本/冻结证据哈希。不存在目标类别时正常标记no_matching_images，不编说明；仍保留完整原文和全部图片。

以enriched_plan.json为本单唯一提取计划：

- 所有首次提取、依赖任务及empty_check复核使用image_description.issue_text_path，不能仍传原始Markdown或只传补充摘要。
- 每次提供image_description.image_paths中的全部备份图片和animation_frames，不按补充类别删图。副本的外部图片引用按source.json映射和实际image_paths读取，不从失效相对路径猜位置。
- 每次调用仍完整执行原业务Prompt。脚本只统一增加补充证据读取说明，不追加按类别定制的提取规则；不向提取者发送未选图片的说明、description_requests、完整frozen.json或整批分类结果。
- image_description.precompleted_tasks.image_type存在时复用为已成功业务图片类型结果，task_contexts登记同一备份图片清单；不重复分类。仅按配置启用根因及对象树；GTS不增加图片说明、根因或图片类型输出列。
- 对象树归类若启用，也使用补充副本全文；仍等待整批Qwen-VL全部工作结束。

随后执行原有业务依赖、结构校验、empty_check、单问题单JSON和批次Excel流程。业务输出字段完全由原配置决定。图像说明、覆盖状态、原始返回、调用次数及耗时只存运行审计，不混入业务列。

冻结证据用于保证复用时同一张图的说明一致，运行中不修改；如确需重新生成说明，使用全新目录，记录新的来源哈希。主Agent不得自行改写、合并或摘要图片说明。

集中后的分析构成同一份全局图片语义上下文，后续各任务完整读取，而不是每读一张图就丢失其余图片含义。逐图分析调用不猜未见图片、不读其他图片分析；单类Skill的业务提取调用仅从副本读取该类分析，不读取其他类别分析文件。准备阶段仍按上文分析全部图片。此阶段不额外调用模型跨图推断，也不由主Agent重新概括。跨图联系由后续模型在完整补充文本和全部原图上核对，不能把相邻分析的可能原因拼成确定根因。

旧版仅画面转写的准备目录不兼容，须用当前Prompt重新分析；不得将旧字段改名冒充已完成问题分析。

复用要求当前分类Prompt、图片分析Prompt、业务提取Prompt和输入哈希完全匹配。发现版本不同就新建准备目录重新生成，不改字段名、替换校验值或沿用旧分析。准备材料变更后，依赖它的补充副本也须重新创建；同一批需要使用一致来源的各次任务不要混用新旧冻结版本。
