"""Separate concise evidence-based explanations from business results."""
import argparse, hashlib, importlib.util, json
from pathlib import Path

ROOT=Path(__file__).resolve().parent.parent

def read(path):
    def unique(pairs):
        out={}
        for key,value in pairs:
            if key in out:raise ValueError('JSON含重复键：'+key)
            out[key]=value
        return out
    return json.loads(Path(path).read_text(encoding='utf-8-sig'),object_pairs_hook=unique)

def write(path,value):
    Path(path).write_bytes((json.dumps(value,ensure_ascii=False,indent=2)+'\n').encode('utf-8'))

def nonempty(value):return isinstance(value,str) and bool(value.strip())

def contract(keys):
    return '''\n\n### 本次派发：额外记录提取依据\n
完成原任务的语义提取，并为实际返回项给出简短、可核查的判断说明。记录证据与规则适用理由，不输出完整内部思考、逐步推演、候选搜索过程或长篇自我对话；不要为了容易解释而改动提取范围。

本段仅改变本次返回的外层包装：前文和复核Prompt中“仅返回原字段”的要求均应用于内层提取结果，其语义定义、字段、槽位与关系约束不变。只返回一个JSON对象，外层恰好为提取结果、提取依据两项。提取结果是原协议的完整JSON，不增加业务字段。当前内层字段为：'''+json.dumps(keys,ensure_ascii=False)+'''。

提取依据是数组，每项恰好包含字段、索引、依据、判断说明。例如虚构对象提取的返回：
{"提取结果":{"测试对象":["查询结果列表"]},"提取依据":[{"字段":"测试对象","索引":0,"依据":[{"来源":"原文","位置":"问题描述","内容":"问题明确检查当前查询的结果列表。"}],"判断说明":"该列表是本单直接验证的目标，按当前业务对象范围纳入。"}]}

示例不是当前答案，字段与实体必须使用当前任务实际值。规则：
- 每个内层数组元素都有一项说明，索引为该数组的0基位置；即使值相同也按各位置记录。因子对按两数组各槽分别说明，包括数据null槽；多参数子数组可在该槽说明中按占位符顺序一并解释。
- 标量字段和空数组用索引null，分别说明该值的依据或为什么无法提取。每个字段都须覆盖，不为填空发明内容。
- 依据为数组，每项恰好含来源、位置、内容。来源只用原文、图片、补充文本、上游结果、同次因子对。位置写可核对的标题/段落、原图编号及区域/帧、上游字段/槽位；内容为必要短摘录或可确认事实。正向提取项至少一条依据；空结果可以无摘录，但判断说明须简述已检查的材料与关键缺口。
- 判断说明通常1—2句：为什么按本业务定义纳入，粒度/抽象方式为何合适；关系说明端点证据、类型及方向，不能仅因顺序相邻建关系；数据槽说明对应哪个<*>，无参数时说明为什么为null；逐步预期说明对应哪个最终因子步骤及正确行为依据。
- 补充文本只是辅助解释：若取值依赖它，要指出相应原文/原图依据或未确认边界，不把推测变成事实。示例、GT和未提供的文件不能作为本单依据。
- 空值复核同样返回该外层包装，依据说明本次复核后的实际结果；不要复制首次解释冒充重新检查。
- 真正读取/业务错误仍直接返回原__error__对象，不套成功包装。
'''

def slots(result):
    return {(key,i) for key,values in result.items() for i in (range(len(values)) if isinstance(values,list) and values else [None])}

def validate_notes(result,notes):
    if not isinstance(notes,list):raise ValueError('提取依据须为数组')
    expected=slots(result);seen=set()
    for note in notes:
        if not isinstance(note,dict) or set(note)!={'字段','索引','依据','判断说明'}:raise ValueError('依据项字段错误')
        key,index=note['字段'],note['索引']
        if not isinstance(key,str) or (index is not None and type(index) is not int):raise ValueError('依据字段/索引类型错误')
        token=(key,index)
        if token not in expected or token in seen:raise ValueError('依据引用越界、重复或缺失字段')
        seen.add(token)
        if not nonempty(note['判断说明']) or not isinstance(note['依据'],list):raise ValueError('缺少判断说明或依据数组')
        value=result[key][index] if index is not None else result[key]
        if value not in ([], '', None) and not note['依据']:raise ValueError('非空项缺少证据')
        for source in note['依据']:
            if not isinstance(source,dict) or set(source)!={'来源','位置','内容'}:raise ValueError('证据字段错误')
            if source['来源'] not in ['原文','图片','补充文本','上游结果','同次因子对'] or not nonempty(source['位置']) or not nonempty(source['内容']):raise ValueError('证据来源/位置/内容错误')
    if seen!=expected:raise ValueError('部分结果没有提取依据')
    return notes

def split(plan,task,raw_path,context,output,stage='initial'):
    spec=plan['tasks'][task]
    if task not in plan.get('extraction_audit',{}).get('tasks',[]):raise ValueError('当前任务不使用提取依据包装')
    raw=read(raw_path)
    if not isinstance(raw,dict) or set(raw)!={'提取结果','提取依据'}:raise ValueError('不是成功的提取结果/依据包装；保留原始返回并按业务错误处理')
    module=importlib.util.spec_from_file_location('audit_business_validator',ROOT/'scripts/validate_result.py');validator=importlib.util.module_from_spec(module);module.loader.exec_module(validator)
    result=validator.validate_result(task,spec,raw['提取结果'],context)
    error=None
    try:validate_notes(result,raw['提取依据'])
    except (ValueError,TypeError,KeyError) as exc:error=str(exc)
    folder=Path(output).resolve()
    if folder.exists():raise ValueError('审计目录已存在，不覆盖首次/复核/重试记录')
    folder.mkdir(parents=True)
    (folder/'raw_response.json').write_bytes(Path(raw_path).read_bytes())
    write(folder/'result.json',result)
    audit={'task_id':task,'stage':stage,'status':'incomplete' if error else 'complete','error':error,'result':result,'items':raw['提取依据'],'prompt_sha256':spec['prompt_sha256'],'raw_sha256':hashlib.sha256(Path(raw_path).read_bytes()).hexdigest()}
    write(folder/'rationale.json',audit)
    return {'business_valid':True,'rationale_complete':error is None,'result_path':str(folder/'result.json'),'audit_path':str(folder/'rationale.json'),'error':error}

def summarize(plan,results,index,issue_id,output,reviews=None):
    records=[];complete=True
    for task in plan.get('extraction_audit',{}).get('tasks',[]):
        if task not in results:raise ValueError('最终任务尚未完成：'+task)
        result=results[task]
        if result is None:
            records.append({'任务':task,'记录类型':'调用失败','说明':'无成功模型提取结果，实际错误见运行记录。'});continue
        source=index.get(task)
        if not isinstance(source,dict):raise ValueError('缺少最终依据索引：'+task)
        if source.get('kind')=='flow':
            if any(v not in ([], '') for v in result.values()) or not nonempty(source.get('reason')):raise ValueError('流程空值说明不能代替非空模型解释')
            records.append({'任务':task,'记录类型':'流程判定','结果':result,'说明':source['reason']});continue
        audit=read(source['audit_path'])
        if audit['task_id']!=task or audit['result']!=result or audit['prompt_sha256']!=plan['tasks'][task]['prompt_sha256']:raise ValueError('依据与最终采用的结果/Prompt不一致：'+task)
        if reviews is not None:
            entry=reviews.get(task,{})
            expected_stage='recheck' if isinstance(entry,dict) and entry.get('review_result') is not None else 'initial'
            if audit['stage']!=expected_stage:raise ValueError('依据未指向最终首次/复核阶段：'+task)
        if audit['status']=='complete':validate_notes(result,audit['items'])
        else:complete=False
        for note in audit['items'] if isinstance(audit['items'],list) else []:
            if isinstance(note,dict) and note.get('字段') in plan['output_fields']:
                records.append({'任务':task,'记录类型':'模型依据摘要','阶段':audit['stage'],'状态':audit['status'],**note})
        if audit['status']!='complete':records.append({'任务':task,'记录类型':'依据记录不完整','说明':audit['error']})
    target=Path(output)
    if target.exists():raise ValueError('最终依据文件已存在，不覆盖')
    target.parent.mkdir(parents=True,exist_ok=True)
    write(target,{'问题单号':issue_id,'依据记录完整':complete,'说明':'简要证据与判断说明，不是模型完整内部思考过程。','记录':records})
    return {'ready':True,'rationale_complete':complete,'output_path':str(target.resolve())}

def main():
    p=argparse.ArgumentParser(description=__doc__);mode=p.add_mutually_exclusive_group(required=True);mode.add_argument('--split',action='store_true');mode.add_argument('--summarize',action='store_true')
    for arg in ['plan','task','raw','context','output-dir','results','index','issue-id','output','reviews']:p.add_argument('--'+arg)
    p.add_argument('--stage',choices=['initial','recheck'],default='initial');a=p.parse_args()
    try:
        plan=read(a.plan)
        if a.split:
            if not all([a.task,a.raw,a.output_dir]):raise ValueError('split需要task/raw/output-dir')
            result=split(plan,a.task,a.raw,read(a.context) if a.context else {},a.output_dir,a.stage)
        else:
            if not all([a.results,a.index,a.issue_id,a.output]):raise ValueError('summarize需要results/index/issue-id/output')
            if not a.reviews:raise ValueError('汇总需要实际empty_reviews.json，即使内容为{}')
            result=summarize(plan,read(a.results),read(a.index),a.issue_id,a.output,read(a.reviews))
        print(json.dumps(result,ensure_ascii=False))
        if not result.get('rationale_complete',True):raise SystemExit(2)
    except (OSError,ValueError,TypeError,KeyError) as error:
        print(json.dumps({'__error__':'EXTRACTION_AUDIT_INVALID','message':str(error)},ensure_ascii=False));raise SystemExit(1)
if __name__=='__main__':main()
