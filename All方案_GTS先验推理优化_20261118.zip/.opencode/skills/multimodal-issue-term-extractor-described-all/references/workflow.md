# 主Agent工作流程

仅主Agent读取本文件，不把它传给Qwen-VL或GLM。模型只读取当前任务的独立Prompt。SKILL.md保留业务提取、复核及导出规则；本文件集中业务路由补充细节与图像预处理命令。

## 一、业务包的选择与补充检查

业务确认门槛按SKILL.md第二节执行。确认后读取config/business_registry.json；以下路径均相对当前Skill，业务包不能越出允许目录。

### 选择业务包
注册表businesses以规范业务名索引，aliases登记等价名称。只去首尾空格并归一英文大小写，不用关键词、模糊匹配或产品知识推断业务。

1. 明确名称或别名唯一匹配：读取该项bundle_dir。
2. 用户明确给出新业务，但无登记项：读取businesses/default，记录actual_business为实际名称、bundle_business为通用包名称、fallback_reason为no_business_bundle。不要求用户先写配置。
3. 同一别名匹配多项或用户信息矛盾：反问，不自行选版本。
4. 已登记包缺失/损坏，或默认包也缺失：配置错误，停止受影响批次；不改用其他包掩盖，也不现场生成。

例如“GTS业务”可按已登记别名映射；只说“问答问题单”不能推断为GTS。工作台保存会同步注册表；未登记业务仍按以上通用回退，不猜路径。同批同业务固定只读包版本，记录实际业务、包、版本及路径，不额外读取其他业务全套定义。

### 预检与派发的补充约定
- 按SKILL.md第四节生成基础计划。business.json的name应匹配注册业务；通用回退包保留自身name，另记实际业务。Prompt源路径只在对应包内解析，不允许绝对路径、跨目录或未登记文件。
- 任务目录不代表全启用；selection及允许关系决定实际任务。字段须与output_keys一致；空清单、未知/重复字段或未知关系视为配置错误。用户完整清单通过--selection覆盖本次默认，不回写业务包；关系类型显式空数组表示该关系成功[]且不调用模型。
- 计划只给模型已合并的prompt_path，source_path只是业务源片段。按SKILL末尾的--verify-prompts门禁派发，含技术重试和空值复核；模型不读配置来合并Prompt。当前实际输入路径按下文图片流程决定，不能始终传原始Markdown。
- 业务image_type任务仅在清单或根因依赖需要时启用；下文公共分类始终在有图时先执行，两者不同。可复用的业务图片类型结果按下文登记，不重复调用。
- 其余任务依赖、GTS逐步预期、关系子集、empty_check、按需对象树及JSON/Excel，分别按SKILL第六至十节执行，不在此重复定义。
- 关系端点逐字来自最终上游；同名重复步骤没有实例ID，不能生成依赖于次数区分的关系，也不把对象列表自动串成时序链。
- 自然语言业务规则无法协调时返回PROFILE_RULE_CONFLICT，回工作台修改对应正文并保存；不静默折中。业务身份错误、配置错误与输入读取失败分开记录，不能当作“没有要素”。

## 二、图片证据与整体解释

主Agent只编排、保存真实返回和校验，不替模型看图或改写结论。分类、逐图读取和整体解释用同一个Qwen-VL定义，各次调用独立。INCLUDED_TYPES固定，决定本组逐图读取的专项检查和整体分析可读类别，不通过参数切换。各套describe_image.md和synthesize_images.md分别写明本组重点，不用统一的泛化要求代替。原文全字段读取；准备与运行目录在原始问题单文件夹外，使用新目录不覆盖。

### 1. 备份与分类
生成基础业务计划并固定全部图片顺序，包括GIF。执行：
```text
python scripts/image_description.py --prepare --plan <基础计划.json> --issue <原始问题单.md> --images <全部有序图片.json> --output-dir <本单准备目录>
```
脚本备份原文和全部图片，保留相对结构/外部引用映射、输入哈希及Prompt哈希；GIF实际解码，默认最多24帧含首尾，Python须有Pillow。call_required=true时，将classification_request.json的完整消息交Qwen-VL实际分类，返回保存为image_types.json；无图时脚本自动保存空分类。

### 2. 先逐图读完，只存内部证据
```text
python scripts/image_description.py --describe --prepared <本单准备目录> --types <image_types.json>
```
按返回request_paths实际调用Qwen-VL。每次只读原始全文和当前一张原图，GIF只给本图帧，不传其他图片记录；不同图片可并行。记录的六字段由references/describe_image.md规定，真实返回存请求result_path。所有图片先读完，不因只补一类就少读。目标类型按当前Prompt的专项步骤保留关键比较、代码条件或过程；非目标类型仅记基本相关事实。不要逐图猜原因、堆面板指标或生成要素答案。
```text
python scripts/image_description.py --freeze --prepared <本单准备目录>
```
freeze必须核对全部图片记录、类型、索引与帧后才生成frozen.json。不能把尚未完成的记录当空。准备格式现为4.0；旧3.0准备材料及逐图分析报告不兼容，不能只改字段名冒充证据读取。同一套Skill内，原始输入、全部Prompt与业务计划均相同时可复用本版冻结证据。五套的专项读图及整体分析Prompt不同，逐图记录与冻结目录不能跨套复用；旧版统一读图记录也须重新准备。分类Prompt仍统一；已有分类只有在原文、有序原图、GIF帧及分类Prompt哈希全部相同时才可沿用类型数组，各套仍独立准备并重新逐图读取，不复制其他组记录。

### 3. 再整体分析，不直接拼逐图报告
```text
python scripts/image_description.py --synthesize --plan <基础计划.json> --prepared <冻结准备目录> --issue <原始问题单.md> --images <全部有序图片.json> --output-dir <本单整体分析目录>
```
脚本生成只包含本Skill允许类别的selected_evidence.json和synthesis_request.json。call_required=true时，按请求实际调用同一Qwen-VL，task_kind=image_synthesis；输入为原始全文、所选辅助笔记和本组全部原图/GIF帧。同一次调用可逐张读取，全部读完后再统一分析根因，不仅依赖旧笔记；不传完整冻结文件、其他类别图片/记录或历史结果。按original_image_indices映射原图编号，GIF局部索引及原始编号按请求解释。无所选图片时脚本生成常量空补充，不调用。

按当前套references/synthesize_images.md的类型专项方法分析具体处理缺陷、触发条件、导致现象的过程及关键依据，减少表面复述；All在一次综合调用中围绕同一故障直接交叉比对不同类型的原图/帧、调试和代码，不分别产出四类结论后汇总；四类检查仅作取证导航。数据必须对齐对象、时点和含义；不同记录不能互相外推。原因可由多张图与正文共同支持，不要求单张图直接写出根因；各个关键联系都须有据，未确认假设不作为补充事实。现场记录须核对同次操作，代码/设计或修复前后参照允许明确角色的跨版本比较，不强求同一时点。原文已经说清的内容不重写，允许补充文本为空。主Agent不得为增加内容替模型改写。

真实四字段返回保存到请求result_path。问题主线、图片联系、根因判断只留内部审计；只将补充文本写入问题单。单类Skill在此阶段实际读完该类全部图片/帧及辅助记录与正文，All才读全部类别；不先读全部类别推理后再删引用，以免隐藏泄漏。

### 4. 新副本与业务提取
```text
python scripts/image_description.py --assemble --plan <基础计划.json> --prepared <冻结准备目录> --issue <原始问题单.md> --images <全部有序图片.json> --synthesis-request <整体分析目录>/synthesis_request.json --synthesis-result <整体分析目录>/synthesis_result.json --output-dir <本单补充运行目录>
```
脚本校验冻结来源、当前范围、所选证据、请求与返回路径及索引。不得绕过整体分析直接拼接逐图报告。有补充则在原Markdown字节后追加一段自然语言；无增量则副本文本与原文相同。记录no_matching_images、no_increment或augmented、所选索引、补充字数和来源哈希。所有原图仍复制保留。

后续唯一计划为enriched_plan.json。首次、依赖、empty_check复核都传image_description.issue_text_path完整副本、全部image_paths和全部animation_frames。不要把逐图记录、整体分析JSON、准备目录或全部计划发给业务提取者。既定业务Prompt、因子/预期依赖、两类关系、空值复核、单问题单JSON到整批Excel保持；不增加图像分析列。image_description.precompleted_tasks.image_type存在时复用分类为业务图片类型结果，登记同一备份图片上下文，不重复分类。GTS不增加根因等未启用字段。

对象树仍仅在启用时由GLM于整批Qwen完成后归类，使用同一副本全文与最终对象及树，不传图片。补充只帮助理解原图，不扩大业务对象范围，不凭新名词创建要素、流程、阈值或关系。

### 失败与审计
分类、逐图读取、整体分析的读取/结构失败最多技术重试2次，记录真实错误；仍失败则明确记预处理失败，不静默按无补充结果继续。没有增量是合法空补充，不能为了填满调用重试或猜内容。预处理不走业务empty_check，后续业务检查照常必经。

IMAGE_DESCRIPTION_NEEDS_FRAMES时，用新准备目录提高--max-frames重读，不修改旧冻结证据；随后重新整体分析和生成副本。整体阶段缺帧也按此规则重新准备、综合，不复用旧结论。记录真实请求、返回、冻结哈希、所选索引、补充字数、失败重试、调用次数及耗时。流程和审计记录不混入业务JSON/Excel。不同对象、时点、实际/预期或旧/新代码未对齐时保留未知，不把并列记录拼成因果。

业务提取阶段的简短依据记录按SKILL“提取依据单独保存”执行；必须拆分模型包装后再走业务校验及empty_check，不把原始包装直接当业务结果。图像综合仍使用原四字段协议，不加入提取依据包装。
