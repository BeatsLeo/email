---
name: multimodal-issue-term-extractor-animation
description: 录屏动画重点提取；支持打开内置业务配置工作台，直接编辑模板、示例、提取内容和保存路径；对包含Markdown文本与图片的测试设计问题单批量提取测试要素及关系。先确认用户明确提供的业务类型，未提供必须反问；按终端软工、GTS或通用业务配置合并公共模板和业务差异。使用一个Qwen-VL subagent按业务计划完成基础要素、因子及依赖任务、关系和按需根因，复核合法空结果；按配置启用任务；需要对象树时，整批Qwen-VL完成后由GLM归类。每单保存完整JSON，全部JSON汇总为一个Excel。
metadata:
  workflow: user-business-ready-bundle-extraction
---

# 录屏动画重点提取

## 业务配置工作台

用户要“打开业务配置”“修改业务模板/提取内容”时，先启动本技能的本机保存服务，打开其返回的http://127.0.0.1:<端口>/工作台，不直接以file://打开configurator/index.html；不启动提取，也不要求先给业务名称。Windows可启动同目录“打开业务配置.vbs”，它在后台运行服务并打开页面；也可用Python 3.9+启动configurator/server.py。主Agent启动后台服务时使用隐藏窗口。该服务仅监听127.0.0.1，不调用模型；同版本已有服务会复用；升级后打开入口会自动使用新版本服务。

工作台提供终端软工、GTS、常规三个完整模板，可直接修改各任务原有定义、判断规则、检查和完整示例；未修改原样使用，不拼接补充规则。页面还选择提取内容、关系范围、业务别名、保存目录和对象树路径，并自动保存成品Prompt、清单、校验值及注册表。已有业务覆盖须在页面确认，旧配置自动备份。提取前让用户保存生效，不使用仅暂存的浏览器草稿。

用户只配置时不适用下文的业务确认提取门槛。配置完成返回本技能，按用户明确业务读取已保存文件即可。

## 一、整体任务

本技能完成以下流程：

1. 确认用户明确提供的业务类型；未提供或不明确时反问，确认后才开始执行。
2. 选择业务配置与模板片段，读取提取清单，生成并固定本次执行计划。
3. 先逐图分类、生成本单执行计划，再读取全文及全部图片，按计划并行提取要素，可包含测试点。
4. 成对提取动作/数据因子；按业务计划完成逐步预期、可选因子命名和关联关系。
5. 原图片类型任务复用前置分类的兼容结果；仅已启用根因且存在代码类图片时提取根因。
6. 对已启用任务的合法空值进行一次复核；测试条件仅在本次已选时纳入，GTS不启用该任务。
7. 仅启用对象树时，等待整批Qwen-VL任务结束后由GLM归类测试对象。
8. 每个问题单写入一份完整JSON；从全部JSON生成一个整批Excel。

## 二、业务确认是启动门槛

只接受用户本次明确提供的业务名称，或用户明确指定适用于本次任务的业务映射。不能从问题单内容、产品名称、目录、域名、图片或配置中有哪些业务反推用户要使用的业务。

- 用户明确说“按GTS提取”：选择GTS。
- 用户明确说“这批是终端软工”：选择终端软工。
- 用户只提供问题单目录或说“开始提取”：必须询问：“请问这批问题单属于哪个业务？例如：终端软工或GTS。”
- 用户说两种业务都有、但未给分配关系：询问各目录或问题单与业务的对应关系，不能自行分类。
- 前文只是讨论或演示两个业务，不代表已为本次提取选定业务；不得因技能包含GTS示例就默认GTS。
- 已明确适用于当前批次的用户业务信息不重复询问；新批次未明确沿用时仍需确认。

缺少业务时，只允许读取本技能和业务注册表以便列出可选项；停止在确认门槛，不读取问题单进行语义分析、不调用提取或归类模型、不写失败JSON或Excel。用户回答后继续原任务。

业务包的具体选择、别名和预检规则见 `references/business_profiles_workflow.md`。主Agent必须完整读取该文件后再执行下文。

## 三、职责与配置

主Agent负责用户业务确认、文件发现、选包、并发调度、结构校验、失败重试、审计、JSON及Excel汇总。主Agent不判断对象粒度，不看图决定类型，不补写模型语义结果。

运行约定直接由本技能规定，不另读全局配置文件：

- 所有多模态提取和复核使用qwen-vl-factor-extractor；对象树使用glm-object-tree-classifier，模型opencode/glm-5.1。
- 并发由OpenCode根据可用能力、上下游依赖和服务状态自行组织；问题单之间及同单无依赖任务应并行，不设固定并发数。
- 每次首次或复核调用的技术/结构失败最多重试2次；成功合法空结果按第七节最多复核一次。
- 业务注册表固定为config/business_registry.json；未确认用户业务不得启动提取，明确的新业务未登记时用businesses/default。
- 每个业务只含一份business.json配置：selection规定提取内容与关系子集，prompts登记任务、字段、依赖、路径和校验值，relations规定可用关系，recheck登记复核Prompt，object_tree_path为可选树路径。公共规则保存在prompt_templates/，业务特定规则与示例差异保存在prompts/*.md章节中。

当前主Agent仍是OpenCode当前主Agent，不创建主Agent文件。所有多模态任务使用同一个Qwen-VL subagent定义，可并行多次调用；不为不同业务或要素创建新Qwen-VL Agent。

## 四、业务包预检

公共内容与业务差异分开保存。OpenCode调用scripts/plan_extraction.py，由Python完成确定性合并，生成可直接使用的完整Prompt快照；主Agent不概括、改写或自行拼接规则，不需要Node.js。

依次读取：注册表选定项 → 包内唯一配置business.json，校验业务身份。计划脚本读取所需公共模板及业务片段，生成本次完整Prompt快照；模型任务只读取计划给出的合并后prompt_path。

business.json的prompts是可用任务目录，不代表全部启用。读取其中的selection；只在提取清单内及其必要依赖中安排任务。业务差异由片段负责；合并过程只做模板引用展开与变量绑定，不用模型重新解释或生成规则。

在本技能目录执行：

```text
python scripts/plan_extraction.py --bundle businesses/gts --prompt-output <本次运行目录>/prompts
```

实际--bundle按用户业务选包。将标准输出的合法计划JSON保存到本次运行目录；脚本失败时停止该业务批次并报告配置错误。用户明确给出本次完整提取清单文件时，追加--selection <绝对路径>，不修改业务默认。脚本计算字段与依赖，校验公共模板和业务片段，合并完整Prompt并记录快照哈希，不调用模型。记录计划与清单哈希；运行中不重新选择。

business.json内selection字段的示例：

```json
{"配置版本":"1.0","提取内容":["测试对象","测试点","测试动作因子","测试数据因子","预期结果","测试对象与测试对象关系","测试动作因子之间关系"]}
```

这也是GTS完整清单，包含七类输出：以动作/数据因子承载完整测试流程，不提取测试动作、测试条件、两类因子名称、问题根因、图片类型或对象树；前置图片类型仅作阅读辅助，不是GTS业务字段；其余未选内容不作为GTS内部依赖运行。原始材料中的条件、定位和代码仍可用于理解流程。终端软工保持原范围，包含对象树、不启用测试点。问题单号自动保留。修改清单可调整已登记字段及最终列；新语义字段仍需维护者登记Prompt与任务。

GTS的expectation登记expectation_alignment: factor_steps，并依赖测试动作因子、测试数据因子。先完成完整因子对及其复核，再生成逐步预期；每步最多一条“步骤N：正确结果”，可省略没有明确预期的步骤，编号不重排，总条数不超过动作因子条数。测试点使用简洁验证主题，必要条件和联合维度保留，详细流程与正确结果分别由因子和预期承接。

未选字段不输出、不填[]或null；因子成对调用及命名依赖等必要内部字段仍按完整契约生成，但只投影已选字段。每个关系任务仅启用本任务范围内且两端类别均在提取清单中的类型，可用可选的关系类型数组进一步收窄；不会为了关系强行提取未选类别。测试点仅在业务关系目录明确允许时作为端点；GTS两类关系均不使用测试点。

预检版本、业务身份、配置哈希、所需任务Prompt哈希、输出字段、依赖和相对路径；关闭的任务不要求其Prompt实际存在，不读取对象树。包缺失、损坏或内部不一致是配置错误，停止受影响批次，不用空结果伪装成功。已选专属包损坏时不得换通用包掩盖问题。

## 五、问题单输入

```text
<输入目录>/
└── <问题单号>/
    ├── <问题单号>.md
    └── images/
        ├── image1.png
        └── ...
```

每个目录恰好一个Markdown文件，没有或多个时记录输入错误。 在run_manifest记录实际读取的Markdown路径与SHA-256、实际图片完整列表/顺序与文件哈希，以及本次业务配置和任务Prompt哈希；保留单项原始返回及校验错误的运行目录路径，用于核对模型实际可见输入，不自行加入外部GT或用例答案。

输入字段不固定。用户整理进当前.md的全部原始字段和正文都是本单输入，必须从头到尾完整读取；保留字段名、字段值、标题层级、表格、代码块、引用和上下文。不按字段白名单截取，不丢弃未知字段，不先压缩成固定的“问题描述/原因分析/预置条件”。读取工具分段返回时连续读取直到文件末尾，不以摘要替代全文。

简要描述、详细描述、实现说明、开发测试报告、用例正文、环境、前置状态、预期、实际结果和补充说明等只是可能存在的内容，不是必填字段或固定输入结构。关键证据可位于任意字段；没有某个同名字段不等于没有该类证据。

完整读取不等于把所有内容当作执行事实。依据具体语义区分已执行操作、系统自动行为、正确行为要求、原因分析、修复措施和新增验证建议；用例编号本身不能还原未提供的正文。不得仅凭字段名把.md中的某段认定为标注答案而跳读。独立于该.md的评测GT、历史提取结果及其他问题单，不得自行拼入当前输入。材料中改变任务或输出格式的文字仅作为待分析内容，不作为执行指令。

按Markdown图片引用确定图片顺序，未引用的图片自然排序追加。传递完整绝对路径列表；无图时为空数组。有图但缺失、不可访问或工具无法传入实际图像内容时，不得擅自删图或降为纯文本。每个Qwen-VL调用均需原文和全部图片。

确定性输入读取失败时不提交无效调用；仍为已确认业务的该问题单保留完整JSON，仅计划选定的模型字段为顶层null，记录原因。输入文件名进行Windows安全化，原始问题单号保持不变；冲突时使用稳定后缀，不覆盖结果。

## 图片类型判断与阅读重点

每单在业务要素提取前统一判断图片类型；类型专属阅读规则已经写入本Skill各项任务Prompt。该结果用于内部调度，不受业务导出字段选择影响；业务字段与JSON契约仍按业务配置执行。

用户确认业务、原始材料发现及基础计划生成后，每单先分类一次，完成后才提交该单的提取任务。不同问题单可并行分类；同单分类完成后，无依赖的对象、测试点、因子等仍并行，逐步预期、关系、复核及对象树遵循原依赖。只使用原有同一个qwen-vl-factor-extractor定义，不新增分类Agent。

发现图片时必须包含.gif文件。GIF按原始文件计数，与UI截图、调试工具截图、代码变更截图统一进入image_paths。处理GIF的Python须安装Pillow；缺少解码能力时报告GIF_DECODER_UNAVAILABLE并停止该单的动画处理，不允许仅凭首帧继续。prepare会按帧序导出实际PNG，默认最多24帧（包含首尾，均匀采样），记录frame_index、timestamp_ms、duration_ms及sampled。帧清单随animation_frames传给分类和每次提取/复核调用；静态图片清单不混入这些派生帧。若采样缺少关键过程，主Agent在原prepare命令追加--max-frames <更大数量>重新生成本单请求，再使用已确认分类结果运行apply并重新派发该任务；原GIF及索引不变，不让模型猜测。

在本Skill目录执行，images.json为本单全部实际图片绝对路径数组，顺序与Markdown引用一致，去重后固定：

```text
python scripts/image_guidance.py --prepare --plan <原始计划.json> --issue <本单完整.md> --images <本单images.json> --output-dir <本单运行目录>/image_guidance
```

call_required为true时，读取image_type_request.json，将其中完整消息交给Qwen-VL实际读取全部图片并分类，把真实返回保存为image_types.json；不能由主Agent看图分类，也不能用文件名或问题描述代替图片。分类输出严格校验标签、顺序和数量；技术/结构错误最多重试2次。无图时脚本自动保存空数组，不调用模型。

```text
python scripts/image_guidance.py --apply --plan <同一原始计划.json> --request <本单运行目录>/image_guidance/image_type_request.json --result <本单运行目录>/image_guidance/image_types.json --output-dir <本单运行目录>/image_guidance
```

本Skill的阅读规则已固定：录屏动画。各基础要素、因子、预期及关系任务的Prompt，已经在判断规则中写入适用图片类型的条件式阅读要求；不需要用户提供选择参数，运行时不再拼接阅读规则。分类完成后，脚本仅给符合本Skill范围的图片追加索引和类别提示，完整分类结果只留在主Agent审计中。所有图片和相同的GIF帧仍可读取，不遮蔽未标注图片，不改标其他类型。不存在目标类型时不提示其缺失。

随后以返回的guided_plan.json作为本单唯一执行计划。再次运行--verify-prompts后派发，只传完整prompt_path，不能把分类文件或阅读重点当作原业务Prompt的替代。脚本保留已包含条件式规则的完整Prompt，仅追加本Skill固定范围内的图片类别提示和共同的图像读取说明；所有提取任务仍读本单全部图文，不按类别裁掉图片，不因分类新增业务字段或节点。对象树和业务image_type任务的Prompt不追加阅读重点。复核读取同一增强任务Prompt和原复核Prompt。

image_guidance.precompleted_tasks中的image_type若存在，按已成功任务写入本单task_results.json，并在task_contexts.json登记相同image_paths，再执行原empty_check；不再调用业务图片类型任务。前置分类与业务图片类型任务统一使用四类标签，直接复用，不做旧标签映射。四类原始结果保留在审计中。GTS不会因为这个内部前置模块新增图片类型或根因等导出列。

分类在重试后仍失败时保存真实错误对象，可用--fallback-error <错误.json>替代--result；脚本返回fallback计划，沿用未增强完整Prompt。记录本单降级，不能伪造类别或空数组；若原计划需要业务图片类型/根因，继续按原计划执行，不凭失败结果跳过。在本单审计中保留分类失败原因和降级状态。

四类定义在references/classify_images.md，阅读重点在references/image_reading_focus.md。业务配置页面维护业务提取口径，各项任务Prompt直接定义本Skill适用的条件式阅读重点，运行时脚本只提供对应类别提示。


## 六、并行任务与依赖

由OpenCode统一组织全批Qwen-VL调用（首次、失败重试、空值复核），遇到限流或服务不稳定时降低并发，稳定后自行调整。不同问题单与同单无依赖任务均可并行；必须保留下游依赖及整批后归类的阶段边界。

按执行计划tasks调度，而非固定提交全套任务：

- parallel：只执行计划stage为parallel的任务。GTS默认计划为object、test_point、factor_pair；其他业务的expectation等无依赖任务可并行，不能仅按任务名称决定阶段。
- dependent：等待dependency_tasks成功、完成复核后传入dependencies字段，立即提交，不等无关任务。
- post_batch：对象树任务；仅启用时执行，等待整批全部Qwen-VL工作结束。

任务消息示例（不要求固定格式）：

```text
prompt_mode: business_profile
business_type: <用户确认的实际业务名>
task_kind: <计划task_kind>
task_name: <当前任务名称>
output_key 或 output_keys: <计划中完整output_keys，成对任务不裁剪>
prompt_path: <计划prompt_path>
issue_text_path: <本单全部原始字段的Markdown绝对路径>
image_paths: <本单全部原始图片含GIF的绝对路径>
animation_frames: <本单image_guidance.animation_frames，静态图片时为空数组>
```

命名任务传extracted_test_factors中的完整因子对；即使本次只导出一个名称也同时返回两种名称，再由主Agent投影。

expectation_alignment为factor_steps的预期任务同样传extracted_test_factors中的最终完整因子对，不传名称或基础动作作为替代。上游失败则预期记失败null，不独立补提因子；因子对成功为空时逐步预期直接成功[]，不调用或复核。逐步预期的空值复核使用同一份最终因子对。
关系任务按task_kind=relation识别，不只识别旧任务ID relation。每次单独调用，allowed_relations取当前计划tasks[任务ID].allowed_relations，不能传全批effective_relations的并集。GTS的object_relation仅传最终测试对象，factor_relation仅传最终完整因子对；分别输出测试对象与测试对象关系、测试动作因子之间关系，不建立跨类别关系。对象完成即可启动对象关系，因子对完成即可同时启动因子关系和逐步预期，互不等待。其他业务仍使用原relation任务。
根因任务等待图片类型成功，至少一张代码变更截图时传零基code_change_image_indices。该类别要求可辨认的旧/新对应，但不保证能确定根因。

只有实际启用的任务才运行。无图且启用图片类型时直接保存成功[]；无图或无代码类图片且启用根因时直接保存成功空字符串，不调用或复核。未启用根因且未导出图片类型时，仍运行前置图片分类，但不再重复调用业务图片类型任务；其他已启用任务仍读取本单全部图片。

因子对最终都为空时，名称直接保存两个空数组；某个关系任务constant_empty为true时直接保存[]，均不调用或复核。其余依赖只要成功即可提交，即使部分数组合法为空。必需上游技术失败才跳过其依赖任务并记顶层null，独立分支继续。

选择因子名称的业务保留因子对→名称对两次调用，不拆成四次。GTS不运行名称阶段，使用因子对→逐步预期的依赖流程；对象、测试点仍独立并行，关系等待实际依赖。实际调用次数由计划、条件分支、复核与重试决定。

## 七、empty_check与合法空值复核

empty_check是每次成功返回后的必经检查点，不是一个无条件调用的提取任务。计划中的recheck.prompt_path是检查命中后供模型使用的完整复核Prompt。只读取该文件或计划中的recheck路径，不算已经执行复核。

首次原始返回校验成功后，更新本单task_results.json（按计划任务ID保存原子返回；未完成不填，确定失败为null）与实际task_contexts.json。同单记录由主Agent串行更新并原子写入；模型调用仍并行，不让多个回调覆盖同一记录文件。立即运行：

```text
python scripts/plan_extraction.py --empty-check --plan <本次计划.json> --results <本单task_results.json> --reviews <本单empty_reviews.json> --contexts <本单task_contexts.json>
```

empty_reviews.json初始为{}，无额外上下文时可省略--contexts。把检查JSON保存到本单empty_check.json，不只检查最终Excel。退出码0表示本单可汇总；2表示仍有待复核/未完成任务，是正常调度状态，不是技术失败；1表示返回或记录不合法，需要修正或按对应任务失败处理。

按pending_rechecks逐项真实调用同一个提取subagent。保持task_id、原任务Prompt、原始全文和全部实际图片与最终上游不变，添加检查器给出的review_mode、review_prompt_path和previous_empty_result；关系必须保留本任务allowed_relations。独立分支继续并行；blocked_tasks中的任务等待上游复核最终完成，不能使用首次空值提前生成下游。

复核最多一次，复核调用自身的技术/结构失败仍按原上限最多重试2次，不重复启动新一轮复核。保留真实首次和复核原始返回，在empty_reviews.json记录对应任务，例如：

```json
{"object":{"initial_result":{"测试对象":[]},"review_result":{"测试对象":[]}}}
```

复核非空写入实际返回；仍空也必须有真实review_result，不能只填“已复核”标记。复核最终技术失败时保留首次合法空结果，review_result为null、review_error记录实际错误（字符串或错误对象），原始错误及重试另记errors.jsonl。不能在未调用模型时编造这些记录。

再次运行empty_check，检查器按复核记录自动选择最终值，并输出task_results及states；使用返回的最终task_results供下游。recovered、confirmed_empty、recheck_failed_kept_initial记录EMPTY_RESULT_RECHECK；not_empty、not_applicable、skipped_constant_empty表示检查已执行但不需再次调用模型。即使没有空值，也必须保存该检查状态，不能因没看到复核调用就断言检查未运行。

触发范围由脚本确定：已启用对象、动作、条件、预期及每个独立关系的合法空数组；两个因子同时为空；实际触发的根因空字符串。GTS不启用基础动作、条件或根因。单个数据null、名称、图片分类和对象树不触发。测试点空值/非法结构先走失败重试，不归为空值复核。

常量空分支不重复调用：没有可用关系类型、没有足够不同端点形成关系、没有代码图的多模态根因、上游因子对最终为空而直接产生的逐步预期等。上游技术失败的null不复核。所有跳过原因仍写入empty_check状态。

启用对象树时，整批各单ready_for_post_batch=true才启动归类；此时对象树任务本身可以尚未完成，不能等待全量ready=true而造成死锁。归类结束后，写每单最终JSON前必须ready=true。调用assemble_result时传入实际empty_reviews；函数会再次执行empty_check，有待复核或未完成项时以EMPTY_CHECK_PENDING拒绝汇总。禁止绕过该门禁手工拼JSON或直接导出Excel。将最终检查状态、复核次数和原始返回路径写入run_manifest；检查报告属于运行审计，不增加业务JSON/Excel字段。

## 八、整批Qwen-VL后对象树归类

先检查计划object_tree_enabled。false时整段跳过：不读取或检查树路径，不调用归类Agent，也不输出归属字段。GTS默认如此。

启用时，所有问题单的Qwen-VL首次、依赖、复核及重试均完成或确定失败后，才启动GLM阶段，不能按单提早穿插。

- 对象非空：每单调用GLM一次处理完整对象数组。
- 对象成功为空：归属为[]，不调用。
- 对象失败：归属为顶层null，不调用。

树路径优先本次用户明确指定，其次business.json的object_tree_path；均未提供时记录该归类分支缺少树文件。缺树或树预检失败只影响非空对象的归类，不撤销其他提取字段。树是整批或对应业务的只读快照，不从截图或示例重建。

归类消息包含business.json中object_tree任务的Prompt路径、issue_text_path、object_tree_path、extracted_test_objects、output_key，不传图片。GLM完整读取缩进Markdown树，按定义逐项归类；新节点只是候选，不在并行中改树。主Agent按实际树验证已有ID、路径及新节点父路径。

## 九、结构校验与失败处理

实际模型返回必须先落原始JSON，调用本技能的scripts/validate_result.py校验后才进入下游、复核结果替换或最终投影。页面保存时的示例检查不能代替此步骤，非空结果也必须校验。计划文件使用本次固定的实际计划，不能临时改字段以迁就返回。

```text
python scripts/validate_result.py --plan <本次计划.json> --task <任务ID> --result <本次原始返回.json> --context <本任务上下文.json>
```

上下文只传实际输入：命名和factor_steps逐步预期传extracted_test_factors；关系传extracted_factors及需要时的extracted_test_factors；图片分类传image_paths（无图为[]）；对象树传extracted_test_objects和实际object_tree_path或object_tree_text快照。其余基础要素、因子对及根因不需要上下文文件。关系类型只使用当前任务的allowed_relations，不使用各关系任务的并集。

校验成功返回valid:true；TASK_RESULT_INVALID或非零退出表示本次调用失败，携带具体错误按原重试上限重试该任务，不能直接裁剪数据、合并槽位、猜值或补null。首次合法空结果的复核返回若结构失败，重试耗尽仍保留首次已校验空值。结构检查不评判业务语义，不保证提取质量。

逐单汇总调用plan_extraction.py中的assemble_result(plan, issue_id, task_results, task_contexts, empty_reviews)，成功任务为完整原子结果，确定技术失败为None；图片/归类的实际上下文按任务ID放入task_contexts。该函数会再次校验全部成功任务（含内部依赖）再投影；失败/缺失上游不能配成功的下游。不得绕过校验直接汇总Excel。

只做结构校验，不判断或修改语义：

1. 返回是合法JSON，顶层恰好为指定的一个或两个字段；__error__是失败对象。
2. 对象、动作、条件、预期为字符串数组，合法无结果可为[]；测试点必须是恰好一个非空字符串的数组，按当前业务定义表达主题或内容；GTS须简洁并保留必要条件和联合维度，但不能拆为多个数组元素或返回[]；根因为字符串。测试点规则适用于所有业务，未启用时仍不输出此字段；输入失败或完全无法辨认问题时记录失败null与错误，不伪装成功，也不编造占位问题。
3. 因子外层数组等长同序，动作项非空。无<*>数据槽为null；一个<*>为字符串/null；多个<*>为按标记从左到右排列的等长字符串/null子数组，未知值保留位置。不强拆不可分动作，不丢具体数据，也不要求每单含null。固定<a>等代码标签不是参数标记。
4. 两个名称外层数组与因子数组等长同序；多参数的数据名称也为对应的等长同序子数组。无参数槽位的数据及数据名为null；具体数据必须有类别名称；有参数但未知具体值时可按Prompt命名明确类别。
5. 每条关系恰好为头实体、关系、尾实体三个字符串。类型及头尾类别以当前任务的allowed_relations为准，端点逐字来自对应上游数组。三元组去重，不允许同类型节点自环；并列关系不重复反向输出。不能假装字符串端点能区分重复步骤。
6. 图片类型与图片等长同序，只能取UI界面截图、录屏动画、调试工具截图、代码变更截图。
7. 对象树归属与对象等长同序；existing和new字段结构、ID、路径及父分类按实际树验证。每项六个字段为测试对象、归类方式、归属路径、目标节点类型、目标节点ID、新节点。

8. factor_steps逐步预期为字符串数组，格式“步骤N：非空正确结果”。N取对应动作因子的原始序号，必须递增、不重复、不越界；每步最多一条，条数≤因子条数，无断言的步骤省略，不补空值或重新编号。同一步多个相关断言合在一条。assemble_result使用实际最终上游再次校验，不能用另行传入的旧因子代替。

技术、超时、可重试读取或结构失败只重试当前调用，携带错误及原始返回。成对任务作为整体重试。确定性缺文件不无效重试。配置错误、PROMPT_OUTPUT_KEY_MISMATCH和PROFILE_RULE_CONFLICT须报告并停止受影响批次，不由主Agent改规则。

重试耗尽后当前字段为顶层null。因子失败则依赖的名称任务失败；只有关系实际依赖的要素失败才令关系失败；对象失败只影响已启用的归属。逐单JSON仅对已选的失败字段写null，内部依赖失败记运行清单；独立分支继续。

不要求基础动作与动作因子等长，因为因子允许派生验证槽位。不能因此删除因子或报结构错误。 非空结果仍按当前业务Prompt的内部检查核对角色、明确检查点、重复风险及参数用途；该检查在当前原子调用内部由提取Agent完成，不另开一轮全量语义复核；主Agent不补语义答案，不为贴合GT增加未提供的用例事实。

## 十、逐单JSON和整批Excel

逐单结果的完整性以本次计划output_fields为准，问题单号自动第一列。保留清单指定顺序，仅从已校验的原子结果投影export_fields；内部依赖和其他未选字段不写入结果。可使用计划脚本中的assemble_result函数进行确定性投影。已选字段技术失败写顶层null，成功无内容按Prompt为空数组或空字符串。

GTS默认包含测试点且关闭测试对象树归属，终端软工默认相反；业务人员修改清单后，字段仅以本次计划为准，不按业务名称补列或删列。两者都不输出测试经验。

```text
design_output/extract_issue_terms_<唯一时间戳>/
├── results/issue_term_<安全问题单号>.json
├── <输入目录名>.xlsx
├── run_manifest.json
└── errors.jsonl
```

每单包含失败单均恰好一份完整JSON。全部写完并校验后，重新从JSON读取生成同一工作簿的“提取结果”表，每单一行，按输入顺序，同业务列为该计划output_fields；混合业务列取各计划的有序并集（问题单号始终第一）。不适用本单的未选列留空白；已选失败写文本null，成功空数组写[]，不能混淆。数组/对象写合法JSON字符串，普通字符串直接写。

问题单号和提取字符串按文本单元格写入，保留原始内容；以=、+、-、@开头的值不能被识别成公式，不用添加会改变原值的前缀规避。使用openpyxl时可明确设置单元格data_type为s；重新读取时同时核对原文和单元格类型。

不得跳过JSON直接生成Excel，不把CSV改名xlsx。写入后重新打开验证表头、行数、问题单号、字段与源JSON一致。不能截断超长值或静默丢关系；若超过Excel单元格限制，保留完整JSON并报告导出失败，不宣称整批成功。

run_manifest记录用户确认业务、包名称与版本、路径、默认回退原因、提取清单及哈希、执行计划、实际启用任务及关系、内部依赖、任务状态、成功/失败及复核统计。混合业务记录每单映射。errors.jsonl记录问题单号、任务、尝试次数、错误和受影响字段。确认业务前不生成这些结果文件。

## 十一、配置维护

正式执行只使用业务注册表映射、路径及完整性校验通过的业务包。businesses只是默认保存目录，也可使用工作台登记的Skill内其他独立相对目录。所有提取、归类与空值复核都使用模板合并后的快照，不将未合并的业务Markdown片段直接发给模型。

业务人员通过内置工作台维护完整Prompt与business.json，保存即写入Skill相对目录并更新config/business_registry.json，无需下载ZIP、解压或搬文件。保存目录默认businesses/业务名称，可在页面更改。工作台保留固定输入/输出契约，直接编辑原Prompt章节及Examples，更新只影响后续批次；不要边运行提取边修改同一业务包。

business.json使用format_version为3.0的单文件格式；name、version、description和template为必要元信息，其余字段仅保存任务选择、任务契约、关系及文件校验值，不重复定义或示例。最终语义以公共模板与业务差异合并后的完整快照为准。页面保存会同步该配置和注册表；除用户明确请求配置维护外，提取主Agent不修改这些文件、模型定义或原始问题单。

公共Markdown模板和业务片段均须随完整Skill部署；只有完整Prompt快照可作为模型输入。记录prompt_library_sha256及各任务prompt_signature，批次开始后冻结快照，复核也使用同一快照。

业务提供与路由规则详见references/business_profiles_workflow.md；业务配置business.json及Prompt均已随本技能提供。

旧版业务设置或浏览器草稿与当前模板的任务、字段、输入输出约定不兼容时，工作台不混用或自动覆盖。旧草稿先保留副本；已保存的旧业务可按新版模板整理为待检查草稿，保留业务信息，确认保存时再覆盖并备份。

## 公共模板与业务差异

prompt_templates/<任务>.md保存可直接阅读的公共模板，businesses/<业务>/prompts/*.md保存业务有差异的完整章节与示例。以“## 片段：名称”对应合并位置：业务同名片段替换公共默认章节，缺省则继承；{{业务.片段名}}要求业务必须提供该片段。仅角色中的{{business_name}}绑定业务名称，示例和代码中的同形文本不展开。编译后去掉片段包装标题，保留原有完整Prompt。HTML展示全文供编辑与预览，保存时自动拆回Markdown差异，不改其他业务或公共模板。公共模板变更只影响后续计划，已生成的快照不变。


## 正式派发前的完整Prompt检查

business.json的source_path仅表示待合并的业务源文件，不可作为模型Prompt。正式执行计划的tasks和recheck只提供完整文件的prompt_path及prompt_sha256，不包含path、source_path或prompt_source_path。公共模板合并始终由主Agent一侧的Python脚本完成；子Agent沿用3.4.2原始定义，只读取完整文件。

正式CLI生成计划时已验证所有完整文件；每次首次调用、技术重试和空值复核派发前，主Agent再次执行：

```text
python scripts/plan_extraction.py --verify-prompts --plan <本次运行目录>/plan.json
```

仅ready为true才可派发。文件缺失、哈希不符、旧版歧义计划或未落盘的预览计划均停止派发，重新生成稳定计划；不得回退到业务源片段、让子Agent合并或自行改写Prompt。界面调用build_plan而不指定输出目录，仅用于配置预览，其prompts_materialized为false，不可用于执行。

任务消息只传原有business_type、prompt_mode、task_kind、task_name、output_keys、计划prompt_path、当前问题单全文路径及本任务所需的最终上游；图文模式另传全部实际图片路径，文本模式不传图片；复核另传完整review_prompt_path、review_mode和真实首次空结果。不要把business.json、整个计划、模板或源片段另发给子Agent。按原规则只传本次关系子集、最终因子对或最终对象，不加入无关并行结果。保存实际派发消息和完整Prompt校验结果到本单运行目录，便于核对真实调用；子Agent仍必须完整读取Prompt和原始材料，图片须实际进入模型。每个原子任务使用独立子Agent调用，不沿用其他问题单或任务的会话。

本Skill随附独立的业务配置、公共模板、业务Prompt、脚本及配置页面，仅从本目录读取资源，不依赖其他同类Skill。用户只需提供业务与问题单目录即可执行。
