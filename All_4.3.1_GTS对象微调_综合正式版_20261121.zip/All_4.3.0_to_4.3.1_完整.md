# All 4.3.0 → 4.3.1 正式版完整差异

以2026-11-20发布的4.3.0正式包为基准，包含全部6个文件变化。当前工作区的用户Prompt原文在本次正式化过程中未改写。终端软工保持综合版状态。

- `README.md`
- `skills/multimodal-issue-term-extractor-described-all/SKILL.md`
- `skills/multimodal-issue-term-extractor-described-all/businesses/gts/business.json`
- `skills/multimodal-issue-term-extractor-described-all/businesses/gts/prompts/object.md`
- `skills/multimodal-issue-term-extractor-described-all/configurator/templates/multimodal-gts.json`
- `skills/multimodal-issue-term-extractor-described-all/configurator/templates/multimodal-gts/prompts/object.md`

````diff
diff --git a/.opencode/README.md b/.opencode/README.md
--- a/.opencode/README.md
+++ b/.opencode/README.md
@@ -12,9 +12,9 @@
 
 业务语义提取同时返回简短证据及判断说明，每单另存extraction_rationale.json，首次/复核记录独立保留；业务JSON与Excel列不增加。
 
-## 当前综合版本4.3.0
+## 当前综合正式版本4.3.1
 
-- GTS：测试对象恢复为4.2.5对象Prompt；当前动作/数据因子、预期、测试点、关系、复核等其余内容保留。
+- GTS 4.3.1：采用用户确认的对象微调规则，先判断直接被测范围，再使用图文证据，区分业务界面与观测工具；当前动作/数据因子、预期、测试点、关系、复核等其余内容保留。
 - 终端软工：保留4.2.9动作补全及空值复核口径，支持根据本单故障补必要具体复现/检查；其他任务保持原样。
 - 两个业务的HTML内置模板、版本及SHA-256均已同步。通用业务、模型、公共模板、脚本和All联合读图流程保持原样。
 
diff --git a/.opencode/skills/multimodal-issue-term-extractor-described-all/SKILL.md b/.opencode/skills/multimodal-issue-term-extractor-described-all/SKILL.md
--- a/.opencode/skills/multimodal-issue-term-extractor-described-all/SKILL.md
+++ b/.opencode/skills/multimodal-issue-term-extractor-described-all/SKILL.md
@@ -308,4 +308,4 @@
 
 ## GTS先验维护
 
-GTS 4.3.0优先原有业务目标与流程。有限先验只补缺失的工具结果到答案衔接职责、明确授权的白盒/内部资源生命周期检查、验收不可缺少的调试观测前提；不能以代码或F12可见触发新增项。其他业务不应用。因子修正后重新生成预期和关系，依据记录引用实际授权事实。工厂模板与业务包同步维护。
+GTS 4.3.1优先原有业务目标与流程。有限先验只补缺失的工具结果到答案衔接职责、明确授权的白盒/内部资源生命周期检查、验收不可缺少的调试观测前提；不能以代码或F12可见触发新增项。其他业务不应用。因子修正后重新生成预期和关系，依据记录引用实际授权事实。工厂模板与业务包同步维护。
diff --git a/.opencode/skills/multimodal-issue-term-extractor-described-all/businesses/gts/business.json b/.opencode/skills/multimodal-issue-term-extractor-described-all/businesses/gts/business.json
--- a/.opencode/skills/multimodal-issue-term-extractor-described-all/businesses/gts/business.json
+++ b/.opencode/skills/multimodal-issue-term-extractor-described-all/businesses/gts/business.json
@@ -1,8 +1,8 @@
 {
   "format_version": "3.0",
   "name": "GTS",
-  "version": "4.3.0",
-  "description": "综合版：测试对象恢复4.2.5规则；保留当前因子、预期及其他GTS提取内容。",
+  "version": "4.3.1",
+  "description": "正式版：保留当前确认的GTS对象图文证据、业务界面及观测工具边界；其他GTS任务保持综合版内容。",
   "template": "gts",
   "object_tree_path": null,
   "selection": {
@@ -24,7 +24,7 @@
         "测试对象"
       ],
       "dependencies": [],
-      "sha256": "ce37d9f8e33a648160807213c654f4f5a91c961e22c744fcc22f3a83e9ce2ec1",
+      "sha256": "d6751d2f2949de369f0b47aa2560df25c297e299909bd188340506da85943137",
       "template_ref": "object",
       "source_path": "prompts/object.md"
     },
diff --git a/.opencode/skills/multimodal-issue-term-extractor-described-all/businesses/gts/prompts/object.md b/.opencode/skills/multimodal-issue-term-extractor-described-all/businesses/gts/prompts/object.md
--- a/.opencode/skills/multimodal-issue-term-extractor-described-all/businesses/gts/prompts/object.md
+++ b/.opencode/skills/multimodal-issue-term-extractor-described-all/businesses/gts/prompts/object.md
@@ -11,7 +11,7 @@
 
 可能附有按顺序排列的图片，展示界面、控件、页面标题、错误提示及操作前后状态；没有图片时依据完整文本判断。
 
-- 文本和图片一致时，使用能够被两者共同支持的具体名称。
+- 先按下述规则确认是否属于本单直接被测范围，再判断证据来源。符合范围的对象可由文本或图片提供明确依据，不要求同时出现；缺图不等于排除，文本出现名称也不等于入选。
 - 文本使用“按钮”“页面”等泛称，而图片清晰显示具体名称时，可以用图片补全名称。
 - 图片中的相关页面、控件和检查内容可按本业务范围分别纳入；仅可见但与当前测试目标无关的背景元素不纳入。
 - 图片模糊、文字不可辨认或只能显示结果状态时，不得猜测对象名称。
@@ -47,9 +47,9 @@
 
 #### 2. 对象层级与辨识粒度
 先保留业务对象，再条件性纳入扩展对象：
-- 界面功能、布局、可用性或控件比较问题：覆盖原文明确比较的控件，以及承载该检查的相关页面；不遍历所有可见控件。
+- 界面功能、布局、可用性或控件比较问题：保留直接受检的界面和控件。控件的承载界面仅限原文明确将该控件问题发生或核对在其上的业务界面；同一问题明确覆盖两处时，不因截图只覆盖一处而漏另一处。可依据明确的界面交互语境补全界面名称，不因文档名、所属系统或入口关系推测新界面；不向上扩展应用和平台；不遍历所有可见控件。
 - 接口字段、资源指标或业务机制本身有明确检查目标/约束时：保留对应实体；存在独立意义的异常字段不能缩为“响应信息”。
-- 调试面板、监控平台和测试工具只是采证手段时，不因可见或被使用就自动加入；只有原始测试清单明确把它们列为检查对象，或其自身行为被验证时才纳入。
+- 调试面板、监控平台和测试工具只是采证手段时，不因可见或被使用就自动加入；“通过平台查看服务内存”受检的是服务与内存，不是平台；出现在操作或清单中也不改变此角色。只有本单独立验证工具自身的功能或结果准确性时才纳入，不按工具名称一律排除。
 - 类、函数、配置变量、事件内部实现仅解释根因时，用来理解机制，不逐项立对象；若原始材料明确验证某处理机制，优先使用稳定机制名，不展开它涉及的所有代码符号。
 
 报告类默认以报告整体为对象，语言、数据、章节及图表作为同一测试点中的关联检查内容，不分别生成测试点。用于校对报告的接口、参数和调试工具不因此自动成为对象；只有原始材料明确另行验证这些实体自身的行为/契约时才独立纳入。该规则优先于“允许父子层级分别保留”。根因补充中出现的接口、参数或代码名称只是候选线索，不自动构成独立验证要求。逐项问“本单是否单独验证它的行为/契约”：仅为解释报告异常或取证的依赖删去，不能因能画出技术链就把链上节点全列入。
@@ -74,25 +74,26 @@
 
 以下4例均为虚构合成场景，只说明本任务的提取边界。示例的字段名、数量和排布不限制真实输入；当前.md全部原始字段均须读取。图片信息是示例说明；真实任务须读取实际图片，不得把示例当成当前问题单的事实。
 
-#### Example 1：相关父页面与比较控件完整保留
+#### Example 1：同一控件问题覆盖两处，截图只显示一处
 
 问题单文本：
 
-【简要描述】在工单审批页点击加签按钮，再点击转交按钮，发现两按钮的键盘焦点框宽度不同。
-【开发测试报告】在工单审批页点击加签按钮，再点击转交按钮，发现两按钮的键盘焦点框宽度不同。规范明确同组操作按钮的焦点框均为2px，审批页和两个控件均在本次检查范围。
+【简要描述】工单审批页和批量审批页中的加签、转交按钮存在键盘焦点框宽度不一致的问题。
+【开发测试报告】核对上述两页的加签、转交按钮，规范明确同组按钮的焦点框均为2px。
 【原因分析】同组按钮使用了不同的焦点样式。
 【运行条件】预演环境；使用审批客户端；账号持有临时审批凭证但未绑定员工身份。
 【测试用例编号】SYN-G-01
 
-图片信息：显示工单审批页、加签按钮和转交按钮，浏览器收藏栏与任务栏也可见。
-
-判断要点：保留相关父页面及两个比较控件，不只提第一个异常按钮；收藏栏和任务栏不是检查实体。
+图片信息：只显示批量审批页、加签按钮和转交按钮，浏览器收藏栏与任务栏也可见；未附工单审批页截图。
+ 
+判断要点：文本将同一按钮问题明确定位到两页，两页均有直接依据，不以截图范围缩减。审批客户端仅是运行载体，收藏栏和任务栏是背景，不因文字或图片提及而纳入。
 
 输出：
 
 {
   "测试对象": [
     "工单审批页",
+    "批量审批页",
     "加签按钮",
     "转交按钮"
   ]
diff --git a/.opencode/skills/multimodal-issue-term-extractor-described-all/configurator/templates/multimodal-gts.json b/.opencode/skills/multimodal-issue-term-extractor-described-all/configurator/templates/multimodal-gts.json
--- a/.opencode/skills/multimodal-issue-term-extractor-described-all/configurator/templates/multimodal-gts.json
+++ b/.opencode/skills/multimodal-issue-term-extractor-described-all/configurator/templates/multimodal-gts.json
@@ -4,8 +4,8 @@
   "business": {
     "format_version": "3.0",
     "name": "GTS",
-    "version": "4.3.0",
-    "description": "综合版：测试对象恢复4.2.5规则；保留当前因子、预期及其他GTS提取内容。",
+    "version": "4.3.1",
+    "description": "正式版：保留当前确认的GTS对象图文证据、业务界面及观测工具边界；其他GTS任务保持综合版内容。",
     "template": "gts",
     "object_tree_path": null,
     "selection": {
@@ -27,7 +27,7 @@
           "测试对象"
         ],
         "dependencies": [],
-        "sha256": "ce37d9f8e33a648160807213c654f4f5a91c961e22c744fcc22f3a83e9ce2ec1",
+        "sha256": "d6751d2f2949de369f0b47aa2560df25c297e299909bd188340506da85943137",
         "template_ref": "object",
         "source_path": "prompts/object.md"
       },
diff --git a/.opencode/skills/multimodal-issue-term-extractor-described-all/configurator/templates/multimodal-gts/prompts/object.md b/.opencode/skills/multimodal-issue-term-extractor-described-all/configurator/templates/multimodal-gts/prompts/object.md
--- a/.opencode/skills/multimodal-issue-term-extractor-described-all/configurator/templates/multimodal-gts/prompts/object.md
+++ b/.opencode/skills/multimodal-issue-term-extractor-described-all/configurator/templates/multimodal-gts/prompts/object.md
@@ -11,7 +11,7 @@
 
 可能附有按顺序排列的图片，展示界面、控件、页面标题、错误提示及操作前后状态；没有图片时依据完整文本判断。
 
-- 文本和图片一致时，使用能够被两者共同支持的具体名称。
+- 先按下述规则确认是否属于本单直接被测范围，再判断证据来源。符合范围的对象可由文本或图片提供明确依据，不要求同时出现；缺图不等于排除，文本出现名称也不等于入选。
 - 文本使用“按钮”“页面”等泛称，而图片清晰显示具体名称时，可以用图片补全名称。
 - 图片中的相关页面、控件和检查内容可按本业务范围分别纳入；仅可见但与当前测试目标无关的背景元素不纳入。
 - 图片模糊、文字不可辨认或只能显示结果状态时，不得猜测对象名称。
@@ -47,9 +47,9 @@
 
 #### 2. 对象层级与辨识粒度
 先保留业务对象，再条件性纳入扩展对象：
-- 界面功能、布局、可用性或控件比较问题：覆盖原文明确比较的控件，以及承载该检查的相关页面；不遍历所有可见控件。
+- 界面功能、布局、可用性或控件比较问题：保留直接受检的界面和控件。控件的承载界面仅限原文明确将该控件问题发生或核对在其上的业务界面；同一问题明确覆盖两处时，不因截图只覆盖一处而漏另一处。可依据明确的界面交互语境补全界面名称，不因文档名、所属系统或入口关系推测新界面；不向上扩展应用和平台；不遍历所有可见控件。
 - 接口字段、资源指标或业务机制本身有明确检查目标/约束时：保留对应实体；存在独立意义的异常字段不能缩为“响应信息”。
-- 调试面板、监控平台和测试工具只是采证手段时，不因可见或被使用就自动加入；只有原始测试清单明确把它们列为检查对象，或其自身行为被验证时才纳入。
+- 调试面板、监控平台和测试工具只是采证手段时，不因可见或被使用就自动加入；“通过平台查看服务内存”受检的是服务与内存，不是平台；出现在操作或清单中也不改变此角色。只有本单独立验证工具自身的功能或结果准确性时才纳入，不按工具名称一律排除。
 - 类、函数、配置变量、事件内部实现仅解释根因时，用来理解机制，不逐项立对象；若原始材料明确验证某处理机制，优先使用稳定机制名，不展开它涉及的所有代码符号。
 
 报告类默认以报告整体为对象，语言、数据、章节及图表作为同一测试点中的关联检查内容，不分别生成测试点。用于校对报告的接口、参数和调试工具不因此自动成为对象；只有原始材料明确另行验证这些实体自身的行为/契约时才独立纳入。该规则优先于“允许父子层级分别保留”。根因补充中出现的接口、参数或代码名称只是候选线索，不自动构成独立验证要求。逐项问“本单是否单独验证它的行为/契约”：仅为解释报告异常或取证的依赖删去，不能因能画出技术链就把链上节点全列入。
@@ -74,25 +74,26 @@
 
 以下4例均为虚构合成场景，只说明本任务的提取边界。示例的字段名、数量和排布不限制真实输入；当前.md全部原始字段均须读取。图片信息是示例说明；真实任务须读取实际图片，不得把示例当成当前问题单的事实。
 
-#### Example 1：相关父页面与比较控件完整保留
+#### Example 1：同一控件问题覆盖两处，截图只显示一处
 
 问题单文本：
 
-【简要描述】在工单审批页点击加签按钮，再点击转交按钮，发现两按钮的键盘焦点框宽度不同。
-【开发测试报告】在工单审批页点击加签按钮，再点击转交按钮，发现两按钮的键盘焦点框宽度不同。规范明确同组操作按钮的焦点框均为2px，审批页和两个控件均在本次检查范围。
+【简要描述】工单审批页和批量审批页中的加签、转交按钮存在键盘焦点框宽度不一致的问题。
+【开发测试报告】核对上述两页的加签、转交按钮，规范明确同组按钮的焦点框均为2px。
 【原因分析】同组按钮使用了不同的焦点样式。
 【运行条件】预演环境；使用审批客户端；账号持有临时审批凭证但未绑定员工身份。
 【测试用例编号】SYN-G-01
 
-图片信息：显示工单审批页、加签按钮和转交按钮，浏览器收藏栏与任务栏也可见。
-
-判断要点：保留相关父页面及两个比较控件，不只提第一个异常按钮；收藏栏和任务栏不是检查实体。
+图片信息：只显示批量审批页、加签按钮和转交按钮，浏览器收藏栏与任务栏也可见；未附工单审批页截图。
+ 
+判断要点：文本将同一按钮问题明确定位到两页，两页均有直接依据，不以截图范围缩减。审批客户端仅是运行载体，收藏栏和任务栏是背景，不因文字或图片提及而纳入。
 
 输出：
 
 {
   "测试对象": [
     "工单审批页",
+    "批量审批页",
     "加签按钮",
     "转交按钮"
   ]
````
